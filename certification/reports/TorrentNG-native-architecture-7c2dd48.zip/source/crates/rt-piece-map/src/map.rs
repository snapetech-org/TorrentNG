use rt_path::SafeRelPath;

use crate::error::PieceMapError;

/// BEP 3 maximum block size for request validation.
pub const MAX_BLOCK_SIZE: u32 = 16 * 1024;

/// A slice of a file that belongs to a piece.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FileRegion {
    pub file_index: u32,
    pub path: SafeRelPath,
    /// Byte offset within the file.
    pub file_offset: u64,
    /// Byte offset within the piece.
    pub piece_offset: u64,
    /// Length of this region.
    pub length: u64,
    /// BEP 47 padding is synthetic zero content and has no on-disk path.
    pub pad: bool,
}

/// File spans in the order they appear in the torrent.
#[derive(Debug, Clone)]
pub struct FileSpan {
    pub file_index: u32,
    pub path: SafeRelPath,
    /// Byte offset of the file in the concatenated content stream.
    pub content_offset: u64,
    pub length: u64,
}

/// A slice of content belonging to a specific piece within a peer request.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PieceRegion {
    pub file_index: u32,
    pub path: SafeRelPath,
    /// Offset within the file.
    pub file_offset: u64,
    /// How many bytes to read.
    pub length: u32,
    /// BEP 47 padding is synthetic zero content and has no on-disk path.
    pub pad: bool,
}

/// A validated request region borrowing immutable torrent metadata. Walking
/// a request does not allocate a region list or clone path components.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PieceRegionRef<'a> {
    /// Position in this map's immutable file list, distinct from file_index.
    pub file_ordinal: usize,
    pub file_index: u32,
    pub path: &'a SafeRelPath,
    /// Full file length, for preparing a download without another file lookup.
    pub file_length: u64,
    pub file_offset: u64,
    pub length: u32,
    pub pad: bool,
}

/// File regions of an already validated request, in content-stream order.
#[derive(Debug, Clone)]
pub struct RequestRegions<'a> {
    files: std::slice::Iter<'a, FileSpan>,
    next_file_ordinal: usize,
    padding_file_indices: &'a [u32],
    start: u64,
    end: u64,
}

impl<'a> Iterator for RequestRegions<'a> {
    type Item = PieceRegionRef<'a>;

    fn next(&mut self) -> Option<Self::Item> {
        for file in self.files.by_ref() {
            let file_ordinal = self.next_file_ordinal;
            self.next_file_ordinal += 1;
            if file.content_offset >= self.end {
                self.files = [].iter();
                return None;
            }
            // PieceMap construction checks every file end and contiguous
            // coverage. Its private file spans cannot change afterwards.
            let start = self.start.max(file.content_offset);
            let end = self.end.min(file.content_offset + file.length);
            if start < end {
                return Some(PieceRegionRef {
                    file_ordinal,
                    file_index: file.file_index,
                    path: &file.path,
                    file_length: file.length,
                    file_offset: start - file.content_offset,
                    length: (end - start) as u32,
                    pad: self
                        .padding_file_indices
                        .binary_search(&file.file_index)
                        .is_ok(),
                });
            }
        }
        None
    }
}

impl std::iter::FusedIterator for RequestRegions<'_> {}

/// Maps pieces to file regions and validates peer block requests.
#[derive(Debug, Clone)]
pub struct PieceMap {
    pub piece_length: u64,
    pub total_length: u64,
    pub piece_count: u32,
    files: Vec<FileSpan>,
    padding_file_indices: Vec<u32>,
}

impl PieceMap {
    /// Build a PieceMap from a list of files in content-stream order.
    pub fn new(piece_length: u64, files: Vec<FileSpan>) -> Result<Self, PieceMapError> {
        Self::new_with_padding(piece_length, files, std::iter::empty())
    }

    /// Build a PieceMap that treats the selected file indexes as BEP 47
    /// synthetic zero spans rather than files that must exist on disk.
    pub fn new_with_padding(
        piece_length: u64,
        files: Vec<FileSpan>,
        padding_file_indices: impl IntoIterator<Item = u32>,
    ) -> Result<Self, PieceMapError> {
        if piece_length == 0 {
            return Err(PieceMapError::ZeroPieceLength);
        }
        if piece_length > u64::from(u32::MAX) {
            return Err(PieceMapError::PieceLengthTooLarge(piece_length));
        }
        let mut expected_offset = 0u64;
        for file in &files {
            if file.content_offset != expected_offset {
                return Err(PieceMapError::NonContiguousFileSpan {
                    file_index: file.file_index,
                    expected: expected_offset,
                    actual: file.content_offset,
                });
            }
            expected_offset = expected_offset
                .checked_add(file.length)
                .ok_or(PieceMapError::IntegerOverflow("file span offset"))?;
        }
        let total_length = expected_offset;
        if total_length == 0 {
            return Err(PieceMapError::ZeroTotalLength);
        }
        let mut file_indices = files.iter().map(|file| file.file_index).collect::<Vec<_>>();
        file_indices.sort_unstable();
        if let Some(duplicate) = file_indices
            .windows(2)
            .find_map(|pair| (pair[0] == pair[1]).then_some(pair[0]))
        {
            return Err(PieceMapError::DuplicateFileIndex(duplicate));
        }
        let piece_count_u64 = (total_length / piece_length)
            .checked_add(u64::from(!total_length.is_multiple_of(piece_length)))
            .ok_or(PieceMapError::IntegerOverflow("piece count"))?;
        let piece_count = u32::try_from(piece_count_u64)
            .map_err(|_| PieceMapError::PieceCountTooLarge(piece_count_u64))?;
        let mut padding_file_indices = padding_file_indices.into_iter().collect::<Vec<_>>();
        padding_file_indices.sort_unstable();
        padding_file_indices.dedup();
        if let Some(unknown) = padding_file_indices
            .iter()
            .find(|file_index| file_indices.binary_search(*file_index).is_err())
        {
            return Err(PieceMapError::UnknownPaddingFileIndex(*unknown));
        }
        Ok(PieceMap {
            piece_length,
            total_length,
            piece_count,
            files,
            padding_file_indices,
        })
    }

    fn file_is_padding(&self, file_index: u32) -> bool {
        self.padding_file_indices.binary_search(&file_index).is_ok()
    }

    /// Resolve a region's stable position without a path clone or file scan.
    pub fn file_by_ordinal(&self, ordinal: usize) -> Option<&FileSpan> {
        self.files.get(ordinal)
    }

    /// Byte length of a specific piece (last piece may be shorter).
    pub fn piece_len(&self, piece: u32) -> Result<u32, PieceMapError> {
        if piece >= self.piece_count {
            return Err(PieceMapError::PieceOutOfRange(piece, self.piece_count));
        }
        let start = u64::from(piece)
            .checked_mul(self.piece_length)
            .ok_or(PieceMapError::IntegerOverflow("piece start"))?;
        let remaining = self.total_length - start;
        Ok(remaining.min(self.piece_length) as u32)
    }

    /// Byte range [start, end) within the content stream for a piece.
    pub fn piece_content_range(&self, piece: u32) -> Result<(u64, u64), PieceMapError> {
        if piece >= self.piece_count {
            return Err(PieceMapError::PieceOutOfRange(piece, self.piece_count));
        }
        let start = u64::from(piece)
            .checked_mul(self.piece_length)
            .ok_or(PieceMapError::IntegerOverflow("piece start"))?;
        let end = start
            .checked_add(self.piece_length)
            .ok_or(PieceMapError::IntegerOverflow("piece end"))?
            .min(self.total_length);
        Ok((start, end))
    }

    /// Index of the first file span whose exclusive end lands at or past
    /// `start`.
    ///
    /// `files` is stored in content-stream order with contiguous,
    /// non-overlapping spans (enforced in `new`), so a binary search finds
    /// the first possibly-overlapping file directly instead of scanning
    /// every file span on every call — this is the hot path for both
    /// per-piece recheck/priority-rebuild lookups and per-block peer
    /// request validation, so an O(files) scan here becomes O(files) work
    /// per piece/request across a whole torrent.
    fn first_file_at_or_after(&self, start: u64) -> usize {
        self.files
            .partition_point(|file| file.content_offset.saturating_add(file.length) <= start)
    }

    /// All file regions that a piece spans.
    pub fn piece_to_file_regions(&self, piece: u32) -> Result<Vec<FileRegion>, PieceMapError> {
        let (piece_start, piece_end) = self.piece_content_range(piece)?;
        let mut regions = Vec::new();
        let start_idx = self.first_file_at_or_after(piece_start);
        for file in &self.files[start_idx..] {
            if file.content_offset >= piece_end {
                break;
            }
            let file_end = file
                .content_offset
                .checked_add(file.length)
                .ok_or(PieceMapError::IntegerOverflow("file span end"))?;
            let overlap_start = piece_start.max(file.content_offset);
            let overlap_end = piece_end.min(file_end);
            if overlap_start >= overlap_end {
                continue;
            }
            regions.push(FileRegion {
                file_index: file.file_index,
                path: file.path.clone(),
                file_offset: overlap_start - file.content_offset,
                piece_offset: overlap_start - piece_start,
                length: overlap_end - overlap_start,
                pad: self.file_is_padding(file.file_index),
            });
        }
        Ok(regions)
    }

    /// Return the half-open piece ranges touched by the selected file indexes.
    ///
    /// `file_indices` must be sorted and deduplicated. The map scans its file
    /// spans once, so callers can invalidate many changed files without doing
    /// a file-map lookup for every changed index.
    pub fn piece_ranges_for_file_indices(
        &self,
        file_indices: &[u32],
    ) -> Result<Vec<(u32, u32)>, PieceMapError> {
        let mut ranges = Vec::new();
        for file in &self.files {
            if file_indices.binary_search(&file.file_index).is_err()
                || file.length == 0
                || self.file_is_padding(file.file_index)
            {
                continue;
            }
            let file_end = file
                .content_offset
                .checked_add(file.length)
                .ok_or(PieceMapError::IntegerOverflow("file span end"))?;
            let first = u32::try_from(file.content_offset / self.piece_length)
                .map_err(|_| PieceMapError::IntegerOverflow("file piece start"))?;
            let last = u32::try_from(
                file_end
                    .div_ceil(self.piece_length)
                    .min(u64::from(self.piece_count)),
            )
            .map_err(|_| PieceMapError::IntegerOverflow("file piece end"))?;
            if first < last {
                ranges.push((first, last));
            }
        }
        Ok(ranges)
    }

    /// Half-open piece range `[first, last)` touched by bytes `[start, end)`
    /// of one file. The byte range is clamped to the file's length. Returns
    /// `None` when the file is unknown or the clamped range is empty.
    ///
    /// Used to translate filesystem allocation gaps (holes, unwritten
    /// extents), which are reported per file, into the pieces they poison.
    pub fn piece_range_for_file_bytes(
        &self,
        file_index: u32,
        start: u64,
        end: u64,
    ) -> Option<(u32, u32)> {
        let file = self
            .files
            .get(file_index as usize)
            .filter(|file| file.file_index == file_index)
            .or_else(|| self.files.iter().find(|file| file.file_index == file_index))?;
        let end = end.min(file.length);
        if start >= end {
            return None;
        }
        let content_start = file.content_offset.checked_add(start)?;
        let content_end = file.content_offset.checked_add(end)?;
        let first = u32::try_from(content_start / self.piece_length).ok()?;
        let last = u32::try_from(
            content_end
                .div_ceil(self.piece_length)
                .min(u64::from(self.piece_count)),
        )
        .ok()?;
        (first < last).then_some((first, last))
    }

    /// Validate a peer block request (BEP 3) and return file regions to read.
    ///
    /// Rejects requests where length > 16 KiB.
    pub fn validate_request(
        &self,
        piece: u32,
        begin: u32,
        length: u32,
    ) -> Result<Vec<PieceRegion>, PieceMapError> {
        Ok(self
            .request_regions(piece, begin, length)?
            .map(|region| PieceRegion {
                file_index: region.file_index,
                path: region.path.clone(),
                file_offset: region.file_offset,
                length: region.length,
                pad: region.pad,
            })
            .collect())
    }

    /// Validate the complete request before exposing any regions. Unlike
    /// `validate_request`, this borrows paths and performs no heap allocation.
    pub fn request_regions(
        &self,
        piece: u32,
        begin: u32,
        length: u32,
    ) -> Result<RequestRegions<'_>, PieceMapError> {
        if length == 0 {
            return Err(PieceMapError::ZeroRequestLength);
        }
        if length > MAX_BLOCK_SIZE {
            return Err(PieceMapError::BlockTooLarge(length, MAX_BLOCK_SIZE));
        }
        let piece_len = self.piece_len(piece)?;
        // Compare in a wider type. `u32::saturating_add` turns a request
        // ending past `u32::MAX` into exactly `u32::MAX`, which accidentally
        // admits the boundary case when the piece itself is that large.
        if u64::from(begin) + u64::from(length) > u64::from(piece_len) {
            return Err(PieceMapError::RequestOutOfBounds {
                offset: begin,
                len: length,
                piece_len,
            });
        }

        let piece_start = u64::from(piece)
            .checked_mul(self.piece_length)
            .ok_or(PieceMapError::IntegerOverflow("piece start"))?;
        let request_start = piece_start
            .checked_add(u64::from(begin))
            .ok_or(PieceMapError::IntegerOverflow("request start"))?;
        let request_end = request_start
            .checked_add(u64::from(length))
            .ok_or(PieceMapError::IntegerOverflow("request end"))?;

        let start_idx = self.first_file_at_or_after(request_start);
        Ok(RequestRegions {
            files: self.files[start_idx..].iter(),
            next_file_ordinal: start_idx,
            padding_file_indices: &self.padding_file_indices,
            start: request_start,
            end: request_end,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_files(specs: &[(&[&str], u64)]) -> Vec<FileSpan> {
        let mut offset = 0u64;
        specs
            .iter()
            .enumerate()
            .map(|(i, (components, len))| {
                let span = FileSpan {
                    file_index: i as u32,
                    path: SafeRelPath::from_components(components, false).unwrap(),
                    content_offset: offset,
                    length: *len,
                };
                offset += len;
                span
            })
            .collect()
    }

    #[test]
    fn borrowed_requests_cover_boundaries_padding_and_nonsequential_file_ids() {
        let mut files = make_files(&[
            (&["empty"], 0),
            (&["dir", "first"], 7),
            (&["pad"], 3),
            (&["empty-middle"], 0),
            (&["last"], 19),
        ]);
        for (file, index) in files.iter_mut().zip([9, 41, 2, 70, 6]) {
            file.file_index = index;
        }
        for piece_length in 1..=31 {
            let map = PieceMap::new_with_padding(piece_length, files.clone(), [2]).unwrap();
            for piece in 0..map.piece_count {
                let piece_len = map.piece_len(piece).unwrap();
                for begin in 0..piece_len {
                    for length in 1..=piece_len - begin {
                        let mut position = u64::from(piece) * piece_length + u64::from(begin);
                        let end = position + u64::from(length);
                        let mut regions = map.request_regions(piece, begin, length).unwrap();
                        for region in regions.by_ref() {
                            let file = map
                                .files
                                .iter()
                                .find(|f| f.file_index == region.file_index)
                                .unwrap();
                            assert!(std::ptr::eq(region.path, &file.path));
                            assert!(std::ptr::eq(
                                map.file_by_ordinal(region.file_ordinal).unwrap(),
                                file
                            ));
                            assert_eq!(region.file_length, file.length);
                            assert_eq!(file.content_offset + region.file_offset, position);
                            assert!(region.length > 0);
                            assert!(region.file_offset + u64::from(region.length) <= file.length);
                            assert_eq!(region.pad, region.file_index == 2);
                            position += u64::from(region.length);
                            assert!(position <= end);
                        }
                        assert_eq!(position, end);
                        assert!(regions.next().is_none());
                    }
                }
            }
        }
    }

    #[test]
    fn borrowed_requests_reject_invalid_ranges_before_iteration() {
        let map = PieceMap::new(
            u64::from(u32::MAX),
            make_files(&[(&["large"], u64::from(u32::MAX))]),
        )
        .unwrap();
        for (piece, begin, length) in [
            (0, 0, 0),
            (0, 0, MAX_BLOCK_SIZE + 1),
            (1, 0, 1),
            (0, u32::MAX, 1),
            (0, u32::MAX - 1, 2),
        ] {
            assert!(map.request_regions(piece, begin, length).is_err());
        }
        let region = map
            .request_regions(0, u32::MAX - 1, 1)
            .unwrap()
            .next()
            .unwrap();
        assert_eq!(region.file_offset, u64::from(u32::MAX - 1));
        assert_eq!(region.length, 1);
    }

    #[test]
    fn file_byte_range_maps_to_the_pieces_it_touches() {
        // Two files: a.bin = 100 bytes, b.bin = 250 bytes; piece length 64.
        // b.bin starts at content offset 100, i.e. inside piece 1.
        let files = make_files(&[(&["a.bin"], 100), (&["b.bin"], 250)]);
        let pm = PieceMap::new(64, files).unwrap();
        assert_eq!(pm.piece_count, 6);

        // First byte of b.bin (content 100) is in piece 1.
        assert_eq!(pm.piece_range_for_file_bytes(1, 0, 1), Some((1, 2)));
        // b.bin bytes [0, 28) end exactly at content 128, the end of piece 1.
        assert_eq!(pm.piece_range_for_file_bytes(1, 0, 28), Some((1, 2)));
        // One byte further spills into piece 2.
        assert_eq!(pm.piece_range_for_file_bytes(1, 0, 29), Some((1, 3)));
        // The whole of a.bin covers pieces 0 and 1.
        assert_eq!(pm.piece_range_for_file_bytes(0, 0, 100), Some((0, 2)));
    }

    #[test]
    fn file_byte_range_is_clamped_and_rejects_empty_or_unknown() {
        let files = make_files(&[(&["a.bin"], 100)]);
        let pm = PieceMap::new(64, files).unwrap();
        assert_eq!(pm.piece_range_for_file_bytes(0, 0, u64::MAX), Some((0, 2)));
        assert_eq!(pm.piece_range_for_file_bytes(0, 50, 50), None);
        assert_eq!(pm.piece_range_for_file_bytes(0, 100, 200), None);
        assert_eq!(pm.piece_range_for_file_bytes(7, 0, 10), None);
    }

    #[test]
    fn single_file_piece_count() {
        let files = make_files(&[(&["a.bin"], 1024 * 1024)]);
        let pm = PieceMap::new(256 * 1024, files).unwrap();
        assert_eq!(pm.piece_count, 4);
    }

    #[test]
    fn last_piece_shorter() {
        let files = make_files(&[(&["a.bin"], 300)]);
        let pm = PieceMap::new(256, files).unwrap();
        assert_eq!(pm.piece_count, 2);
        assert_eq!(pm.piece_len(0).unwrap(), 256);
        assert_eq!(pm.piece_len(1).unwrap(), 44);
    }

    #[test]
    fn single_file_region() {
        let files = make_files(&[(&["a.bin"], 1024)]);
        let pm = PieceMap::new(512, files).unwrap();
        let regions = pm.piece_to_file_regions(0).unwrap();
        assert_eq!(regions.len(), 1);
        assert_eq!(regions[0].file_offset, 0);
        assert_eq!(regions[0].length, 512);
    }

    #[test]
    fn piece_spanning_two_files() {
        // piece_length=512, file A=300 bytes, file B=300 bytes
        // piece 0: bytes 0..512 → A[0..300] + B[0..212]
        let files = make_files(&[(&["a.bin"], 300), (&["b.bin"], 300)]);
        let pm = PieceMap::new(512, files).unwrap();
        let regions = pm.piece_to_file_regions(0).unwrap();
        assert_eq!(regions.len(), 2);
        assert_eq!(regions[0].file_index, 0);
        assert_eq!(regions[0].file_offset, 0);
        assert_eq!(regions[0].length, 300);
        assert_eq!(regions[1].file_index, 1);
        assert_eq!(regions[1].file_offset, 0);
        assert_eq!(regions[1].length, 212);
    }

    #[test]
    fn zero_length_file_skipped() {
        let files = make_files(&[(&["empty.txt"], 0), (&["data.bin"], 512)]);
        let pm = PieceMap::new(512, files).unwrap();
        let regions = pm.piece_to_file_regions(0).unwrap();
        // empty file contributes no bytes
        assert_eq!(regions.len(), 1);
        assert_eq!(regions[0].file_index, 1);
    }

    #[test]
    fn file_piece_ranges_cover_only_selected_file_bytes() {
        let pm = PieceMap::new(512, make_files(&[(&["a.bin"], 300), (&["b.bin"], 300)])).unwrap();

        assert_eq!(
            pm.piece_ranges_for_file_indices(&[1]).unwrap(),
            vec![(0, 2)]
        );
        assert_eq!(
            pm.piece_ranges_for_file_indices(&[0]).unwrap(),
            vec![(0, 1)]
        );
        assert!(pm.piece_ranges_for_file_indices(&[2]).unwrap().is_empty());
    }

    #[test]
    fn piece_out_of_range() {
        let files = make_files(&[(&["a.bin"], 512)]);
        let pm = PieceMap::new(512, files).unwrap();
        assert!(matches!(
            pm.piece_len(1),
            Err(PieceMapError::PieceOutOfRange(1, 1))
        ));
    }

    #[test]
    fn request_too_large() {
        let files = make_files(&[(&["a.bin"], 1024 * 1024)]);
        let pm = PieceMap::new(256 * 1024, files).unwrap();
        assert!(matches!(
            pm.validate_request(0, 0, 16 * 1024 + 1),
            Err(PieceMapError::BlockTooLarge(_, _))
        ));
    }

    #[test]
    fn zero_length_request_rejected() {
        let files = make_files(&[(&["a.bin"], 1024)]);
        let pm = PieceMap::new(512, files).unwrap();
        assert!(matches!(
            pm.validate_request(0, 0, 0),
            Err(PieceMapError::ZeroRequestLength)
        ));
    }

    #[test]
    fn request_out_of_bounds() {
        let files = make_files(&[(&["a.bin"], 100)]);
        let pm = PieceMap::new(256 * 1024, files).unwrap();
        // piece 0 is only 100 bytes
        assert!(matches!(
            pm.validate_request(0, 90, 20),
            Err(PieceMapError::RequestOutOfBounds { .. })
        ));
    }

    #[test]
    fn valid_request_resolves_file_region() {
        let files = make_files(&[(&["a.bin"], 1024 * 1024)]);
        let pm = PieceMap::new(256 * 1024, files).unwrap();
        let regions = pm.validate_request(1, 0, 16 * 1024).unwrap();
        assert_eq!(regions.len(), 1);
        assert_eq!(regions[0].file_offset, 256 * 1024); // piece 1 starts at byte 256K
        assert_eq!(regions[0].length, 16 * 1024);
    }

    #[test]
    fn request_past_max_u32_piece_boundary_is_rejected() {
        let files = make_files(&[(&["huge.bin"], u64::from(u32::MAX))]);
        let pm = PieceMap::new(u64::from(u32::MAX), files).unwrap();

        assert!(matches!(
            pm.validate_request(0, u32::MAX - 1, 2),
            Err(PieceMapError::RequestOutOfBounds { .. })
        ));
    }

    #[test]
    fn valid_request_can_span_many_files() {
        let specs: Vec<_> = (0..64)
            .map(|idx| (vec![format!("{idx}.bin")], 256u64))
            .collect();
        let files = specs
            .iter()
            .map(|(components, len)| {
                (
                    components.iter().map(String::as_str).collect::<Vec<_>>(),
                    *len,
                )
            })
            .collect::<Vec<_>>();
        let file_refs = files
            .iter()
            .map(|(components, len)| (components.as_slice(), *len))
            .collect::<Vec<_>>();
        let pm = PieceMap::new(16 * 1024, make_files(&file_refs)).unwrap();

        let regions = pm.validate_request(0, 0, 16 * 1024).unwrap();

        assert_eq!(regions.len(), 64);
        assert_eq!(
            regions.iter().map(|region| region.length).sum::<u32>(),
            16 * 1024
        );
    }

    #[test]
    fn padding_regions_are_synthetic_and_do_not_invalidate_file_pieces() {
        let files = vec![
            FileSpan {
                file_index: 0,
                path: SafeRelPath::from_components(&["bundle", "a.bin"], false).unwrap(),
                content_offset: 0,
                length: 3,
            },
            FileSpan {
                file_index: 1,
                path: SafeRelPath::from_components(&["bundle", ".pad", "13"], false).unwrap(),
                content_offset: 3,
                length: 13,
            },
            FileSpan {
                file_index: 2,
                path: SafeRelPath::from_components(&["bundle", "b.bin"], false).unwrap(),
                content_offset: 16,
                length: 4,
            },
        ];
        let map = PieceMap::new_with_padding(16, files, [1]).unwrap();

        let regions = map.piece_to_file_regions(0).unwrap();
        assert_eq!(regions.len(), 2);
        assert!(!regions[0].pad);
        assert!(regions[1].pad);
        assert!(map.piece_ranges_for_file_indices(&[1]).unwrap().is_empty());

        let request = map.validate_request(0, 3, 13).unwrap();
        assert_eq!(request.len(), 1);
        assert!(request[0].pad);
    }

    #[test]
    fn rejects_duplicate_file_indexes() {
        let mut files = make_files(&[(&["a.bin"], 8), (&["b.bin"], 8)]);
        files[1].file_index = files[0].file_index;

        assert_eq!(
            PieceMap::new(16, files).unwrap_err(),
            PieceMapError::DuplicateFileIndex(0)
        );
    }

    #[test]
    fn rejects_padding_indexes_without_a_file_span() {
        assert_eq!(
            PieceMap::new_with_padding(16, make_files(&[(&["a.bin"], 16)]), [7]).unwrap_err(),
            PieceMapError::UnknownPaddingFileIndex(7)
        );
    }

    #[test]
    fn content_range_last_piece() {
        let files = make_files(&[(&["a.bin"], 300)]);
        let pm = PieceMap::new(256, files).unwrap();
        let (start, end) = pm.piece_content_range(1).unwrap();
        assert_eq!(start, 256);
        assert_eq!(end, 300);
    }

    #[test]
    fn rejects_piece_count_overflow() {
        let files = vec![FileSpan {
            file_index: 0,
            path: SafeRelPath::from_name("huge.bin", false).unwrap(),
            content_offset: 0,
            length: u64::from(u32::MAX) + 1,
        }];

        assert!(matches!(
            PieceMap::new(1, files),
            Err(PieceMapError::PieceCountTooLarge(_))
        ));
    }

    #[test]
    fn rejects_non_contiguous_file_spans() {
        let files = vec![
            FileSpan {
                file_index: 0,
                path: SafeRelPath::from_name("a.bin", false).unwrap(),
                content_offset: 0,
                length: 10,
            },
            FileSpan {
                file_index: 1,
                path: SafeRelPath::from_name("b.bin", false).unwrap(),
                content_offset: 12,
                length: 10,
            },
        ];

        assert!(matches!(
            PieceMap::new(10, files),
            Err(PieceMapError::NonContiguousFileSpan {
                file_index: 1,
                expected: 10,
                actual: 12,
            })
        ));
    }

    #[cfg(test)]
    mod property {
        use super::*;
        use proptest::prelude::*;

        proptest! {
            #[test]
            fn all_bytes_covered(
                total in 1u64..=(10 * 1024 * 1024u64),
                piece_length in 1u64..=262144u64,
            ) {
                let files = vec![FileSpan {
                    file_index: 0,
                    path: SafeRelPath::from_name("a.bin", false).unwrap(),
                    content_offset: 0,
                    length: total,
                }];
                let pm = PieceMap::new(piece_length, files).unwrap();
                let mut covered = 0u64;
                for p in 0..pm.piece_count {
                    let regions = pm.piece_to_file_regions(p).unwrap();
                    for r in regions {
                        covered += r.length;
                    }
                }
                prop_assert_eq!(covered, total);
            }

            #[test]
            fn piece_lengths_sum_to_total(
                total in 1u64..=(4 * 1024 * 1024u64),
                piece_length in 1u64..=65536u64,
            ) {
                let files = vec![FileSpan {
                    file_index: 0,
                    path: SafeRelPath::from_name("a.bin", false).unwrap(),
                    content_offset: 0,
                    length: total,
                }];
                let pm = PieceMap::new(piece_length, files).unwrap();
                let sum: u64 = (0..pm.piece_count)
                    .map(|p| pm.piece_len(p).unwrap() as u64)
                    .sum();
                prop_assert_eq!(sum, total);
            }
        }
    }
}
