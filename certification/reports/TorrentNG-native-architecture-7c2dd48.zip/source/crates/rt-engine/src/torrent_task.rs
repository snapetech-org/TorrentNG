/// Per-torrent async task.
///
/// One tokio task per torrent owns: tracker announce loop, peer connection
/// management, piece picker, and storage writes.
use std::collections::{HashMap, HashSet};
use std::hash::{Hash, Hasher};
use std::io::IoSlice;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr, SocketAddrV4, SocketAddrV6};
use std::path::PathBuf;
use std::pin::Pin;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Mutex, MutexGuard};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use bytes::BytesMut;
use futures::{FutureExt, SinkExt, StreamExt};
use reqwest::header::{CONTENT_RANGE, RANGE};
use reqwest::StatusCode;
use rt_bencode::{BValue, Decoder};
use rusqlite::Connection;
#[cfg(test)]
use tokio::net::TcpListener;
use tokio::net::TcpStream;
use tokio::sync::{mpsc, oneshot, Notify, OwnedSemaphorePermit, RwLock};
use tokio::task::JoinHandle;
use tokio::time::{interval, sleep, timeout, Instant as TokioInstant, Sleep};
use tokio_util::codec::Framed;
use tracing::{debug, info, warn};
use url::Url;

use std::sync::Arc;

use rt_fastresume::{
    decide_recovery, should_audit_allocation, FastresumeState, FastresumeStore, FileHint,
    ImportPolicy, PartialPieceState, PieceState, RecheckReason, RecoveryAction, RecoveryInputs,
    MAX_FASTRESUME_BLOCKS_PER_PARTIAL_PIECE,
};
use rt_hash::V2_BLOCK_SIZE;
#[cfg(test)]
use rt_metainfo::{torrent_info_bytes, TorrentMeta};
use rt_metainfo::{
    torrent_info_bytes_with_allocation_reservation, TorrentFileV1, TorrentMetaV1, TorrentMetaV2,
};
use rt_metrics::{MemoryClass, MemoryLease, PayloadCopyPath, ResourceGovernor};
use rt_path::{SafeRelPath, StorageProfile, StorageRootId};
use rt_peer_manager::{
    ChokeDecision, ChokeMode, ChokeState, Choker, PeerId, PeerSnapshot, DEFAULT_MAX_UNCHOKED,
};
use rt_peer_wire::{
    codec::PeerCodec,
    extension::{ExtensionHandshake, UtMetadataMessage, EXT_HANDSHAKE_ID},
    handshake::{ExtensionFlags, Handshake},
    message::Message,
};
use rt_piece_map::{FileSpan, PieceMap, V2FileSpan, V2PieceMap};
use rt_piece_picker::{Availability, BlockRequest, PieceAvailability, PiecePicker, MAX_BLOCK_SIZE};
use rt_session::{SessionRegistry, TorrentEntry, TorrentState};
use rt_storage::{
    scheduler::{scheduled_write, scheduled_write_with_shared_payload_lease},
    HybridV2PieceExpectation, IoClass, IoRequestPriority, MountScheduler, PieceVerifier,
    SchedulerConfig, StorageIoConfig, VerifyResult,
};
#[cfg(test)]
use rt_tracker::{AnnounceResponse, TrackerError};
use rt_tracker::{
    TrackerEvent, TrackerState, TrackerStatus, MAX_TRACKER_PEERS, MAX_TRACKER_STATE_ID_BYTES,
    MAX_TRACKER_STATE_TEXT_BYTES,
};
use rt_utp::UtpStream;

#[path = "torrent_task/peer_connections.rs"]
mod peer_connections;
#[path = "torrent_task/peer_session.rs"]
mod peer_session;
#[path = "torrent_task/peer_transfer.rs"]
mod peer_transfer;

use crate::command::TorrentPeerStats;
use crate::crash_safety::{self, CrashSafetyRuntime};
use crate::db_worker::DbExecutor;
use crate::egress_policy::{OutboundEgressPolicy, OutboundTargetKind};
use crate::network_budget::{
    GlobalNetworkBudget, RateAdmissionAttempt, RateAdmissionGrant, RateLimitCancellation,
    SourceRequestPermit,
};
use crate::tracker_runtime::{
    announce_tracker, bounded_response_body, first_tracker_key, next_tracker_key, protocol_numwant,
    tracker_keys_for_announce, tracker_keys_for_stopped_announce, url_log_target,
    TrackerAnnounceContext, TrackerAnnounceResult, TrackerAnnounceSpec, TrackerKey,
    TrackerScrapeResult, TrackerWorkerEvent, TrackerWorkers, MAX_TRACKER_ANNOUNCES_IN_FLIGHT,
    STOPPED_TRACKER_ANNOUNCE_DEADLINE,
};
use crate::transfer::coords::{
    BlockExtent, ConnectionId, HybridGeometry, PieceGeometry, Plane, TorrentKey, TransferPeerId,
};
use crate::transfer::ledger::{
    Action as TransferAction, CommitOutcome, ReceiveOutcome, ReserveMode,
};
use crate::transfer::live::LiveTransferLedger as TransferLedger;
use crate::transfer::obligations::{
    InboundDecision, Reject as InboundReject, RejectReason as InboundRejectReason,
    Served as InboundServed,
};
use crate::transfer::rate::RatePeerId;
use crate::transfer::shared_upload::{SharedUploadPeer, SharedUploadReadHandle};
use crate::transfer::upload_scheduler::UploadReadPermit;
use crate::transfer::window::{WindowConfig, WindowController, WindowInputs};
use crate::{EnginePeerSnapshot, EngineTorrentLimits, EngineWebseedSnapshot, TorrentRuntimeStats};

const LOCAL_UT_METADATA_ID: u8 = 1;
const LOCAL_UT_PEX_ID: u8 = 2;
const METADATA_PIECE_SIZE: usize = 16 * 1024;
const PEER_IDLE_TIMEOUT: Duration = Duration::from_secs(120);
pub(crate) const UTP_CONNECT_TIMEOUT: Duration = Duration::from_secs(3);
const UPLOAD_ACCOUNTING_BATCH_BYTES: u64 = 64 * 1024;
const UPLOAD_ACCOUNTING_MAX_DELAY: Duration = Duration::from_millis(25);
const MAX_READY_UPLOAD_INTAKE_MESSAGES: usize = MAX_UPLOAD_READ_BATCH_BLOCKS;
// A pipelined receiver can refill one 16 KiB request at a time. Ready-only
// draining never combines those refills, so every cache hit still enters the
// disk queue. Bound collection latency, and never wait for more requests than
// this peer has demonstrated it can keep outstanding.
const UPLOAD_READ_COALESCE_MAX_DELAY: Duration = Duration::from_millis(8);

pub(crate) async fn connect_utp_with_deadline(
    network_budget: &GlobalNetworkBudget,
    addr: SocketAddr,
) -> anyhow::Result<UtpStream> {
    timeout(
        UTP_CONNECT_TIMEOUT,
        network_budget.utp_runtime().connect(addr),
    )
    .await
    .map_err(|_| {
        anyhow::anyhow!(
            "uTP connection to {addr} timed out after {} ms",
            UTP_CONNECT_TIMEOUT.as_millis()
        )
    })?
    .map_err(Into::into)
}

fn lock_prepared_files(files: &Mutex<HashSet<u32>>) -> MutexGuard<'_, HashSet<u32>> {
    match files.lock() {
        Ok(guard) => guard,
        Err(poisoned) => {
            // Prepared-file membership is an optimization. Re-preparing is
            // safe: storage refuses to shrink existing payloads and length
            // setup is idempotent, so discard potentially stale membership.
            let mut guard = poisoned.into_inner();
            guard.clear();
            files.clear_poison();
            guard
        }
    }
}
const PEER_UPLOAD_READ_TIMEOUT: Duration = Duration::from_secs(30);
const PEER_SOCKET_WRITE_TIMEOUT: Duration = Duration::from_secs(10);
// Upload demand is bounded by the request queue and the pending-read cap
// below, with response bytes metered by the torrent and global upload
// buckets. There is deliberately no requests-per-interval ceiling: a count
// derived from a 64 MiB test fixture capped a continuously used connection at
// about 6.4 MiB/s and silently dropped valid requests beyond it.
const MAX_PENDING_UPLOAD_READS: usize = 16;
// Start with 64 KiB storage reads: four legal 16 KiB wire requests share one
// bounded pread while keeping response obligations and rate grants separate.
const MAX_UPLOAD_READ_BATCH_BLOCKS: usize = 4;
const MAX_UPLOAD_READ_BATCH_BYTES: usize = 64 * 1024;
// A 64 MiB fixture at the protocol's 16 KiB block size is 4,096 requests.
// Requests are only small coordinates; the response data remains bounded by
// MAX_PENDING_UPLOAD_READS and the peer-buffer governor.
const MAX_QUEUED_UPLOAD_REQUESTS: usize = 4_096;
const MAX_UPLOAD_WORK: usize = MAX_PENDING_UPLOAD_READS + MAX_QUEUED_UPLOAD_REQUESTS;
const PEER_EVENT_SEND_TIMEOUT: Duration = Duration::from_millis(500);
// Terminal and seed-limit transitions must leave time for persistence and
// peer teardown. Tracker stop delivery is best effort and cannot consume the
// engine's entire command/shutdown budget when a tracker is unresponsive.
const STOPPED_TRACKER_CONTROL_ANNOUNCE_DEADLINE: Duration = Duration::from_secs(1);
const WEBSEED_RETRY_BASE: Duration = Duration::from_secs(1);
const WEBSEED_RETRY_MAX: Duration = Duration::from_secs(300);
const MAX_UT_PEX_PEERS: usize = 2_048;
// BEP 11 payloads arrive from untrusted peers inside a legal peer-wire
// message. Keep a flat bencode node bomb from reaching the parser's much
// larger generic default before the compact-peer count checks run.
const MAX_UT_PEX_BENCODE_NODES: usize = 16 * 1024;
// Peer snapshots are compatibility/API projections rather than a scheduling
// primitive. Keep a damaged or unusually configured torrent from allocating
// an unbounded response vector when an endpoint asks for its peers.
pub(crate) const MAX_PEER_SNAPSHOT_ITEMS: usize = 16_384;
fn peer_event_channel_capacity(max_peers: usize) -> usize {
    max_peers.clamp(64, 512)
}

fn db_i64(value: u64) -> i64 {
    i64::try_from(value).unwrap_or(i64::MAX)
}

fn build_piece_map(piece_length: u64, files: &[TorrentFileV1]) -> Result<Arc<PieceMap>, String> {
    PieceMap::new_with_padding(
        piece_length,
        files
            .iter()
            .map(|file| FileSpan {
                file_index: file.index,
                path: file.path.clone(),
                content_offset: file.offset,
                length: file.length,
            })
            .collect(),
        files
            .iter()
            .filter_map(|file| file.pad.then_some(file.index)),
    )
    .map(Arc::new)
    .map_err(|error| format!("building torrent piece map: {error}"))
}

fn validate_padding_block(
    piece_map: &PieceMap,
    piece: u32,
    begin: u32,
    data: &[u8],
) -> anyhow::Result<()> {
    let length = u32::try_from(data.len())
        .map_err(|_| anyhow::anyhow!("peer block length does not fit in u32"))?;
    let regions = piece_map.request_regions(piece, begin, length)?;
    let mut data_offset = 0usize;
    for region in regions {
        let region_len = usize::try_from(region.length)
            .map_err(|_| anyhow::anyhow!("piece region length does not fit in memory"))?;
        let end = data_offset
            .checked_add(region_len)
            .ok_or_else(|| anyhow::anyhow!("piece region data offset overflow"))?;
        let region_data = data
            .get(data_offset..end)
            .ok_or_else(|| anyhow::anyhow!("peer block does not cover mapped piece regions"))?;
        if region.pad && region_data.iter().any(|byte| *byte != 0) {
            anyhow::bail!("peer block contains non-zero bytes for BEP 47 padding");
        }
        data_offset = end;
    }
    if data_offset != data.len() {
        anyhow::bail!("mapped piece regions do not cover the peer block");
    }
    Ok(())
}

const TORRENT_METADATA_MEMORY_BASE: usize = 64 * 1024;

fn add_owned_string_bytes(total: &mut usize, value: &String) {
    *total = total.saturating_add(value.capacity());
}

fn add_safe_path_bytes(total: &mut usize, path: &rt_path::SafeRelPath) {
    // SafeRelPath's component vector is private, but construction bounds its
    // capacity to the component count. Charge the vector and every owned
    // String rather than just the joined display length.
    *total = total.saturating_add(
        path.components()
            .len()
            .saturating_mul(std::mem::size_of::<String>()),
    );
    for component in path.components() {
        add_owned_string_bytes(total, component);
    }
}

fn add_v1_file_graph_bytes(
    total: &mut usize,
    files: &[TorrentFileV1],
    capacity: usize,
    entry_size: usize,
) {
    *total = total.saturating_add(capacity.saturating_mul(entry_size));
    for file in files {
        add_safe_path_bytes(total, &file.path);
    }
}

fn persistent_file_graph_memory_bytes(files: &[TorrentFileV1]) -> usize {
    let mut total = 0;
    add_v1_file_graph_bytes(
        &mut total,
        files,
        files.len(),
        std::mem::size_of::<TorrentFileV1>(),
    );
    add_v1_file_graph_bytes(
        &mut total,
        files,
        files.len(),
        std::mem::size_of::<FileSpan>(),
    );
    total
}

/// Estimate the allocations retained by one live v1 task outside the piece
/// hash/picker lease and the exact BEP9 upload-payload lease.
///
/// The task owns the parsed file graph, a second copy used to rebuild durable
/// file policy, and a third path graph inside PieceMap. It also materializes
/// tracker state and webseed bookkeeping from the parsed metadata. Admission
/// must reserve this lifetime memory before the task is constructed; otherwise
/// a session containing many large multi-file torrents can bypass the metadata
/// governor even though every individual parser input is bounded. Tracker
/// state is reserved separately after the durable tracker override is known.
pub(crate) fn persistent_torrent_metadata_memory_bytes(meta: &TorrentMetaV1) -> usize {
    let mut total = TORRENT_METADATA_MEMORY_BASE
        .saturating_add(std::mem::size_of::<TorrentMetaV1>())
        .saturating_add(std::mem::size_of::<PieceMap>())
        .saturating_add(2 * std::mem::size_of::<usize>());

    add_v1_file_graph_bytes(
        &mut total,
        &meta.files,
        meta.files.capacity(),
        std::mem::size_of::<TorrentFileV1>(),
    );
    // `metainfo_files` is a deep clone used to restore the original paths
    // after a durable file-policy projection changes them.
    total = total.saturating_add(persistent_file_graph_memory_bytes(&meta.files));

    add_owned_string_bytes(&mut total, &meta.name);
    if let Some(comment) = &meta.comment {
        add_owned_string_bytes(&mut total, comment);
    }
    if let Some(created_by) = &meta.created_by {
        add_owned_string_bytes(&mut total, created_by);
    }
    if let Some(announce) = &meta.announce {
        add_owned_string_bytes(&mut total, announce);
    }
    total = total.saturating_add(
        meta.announce_list
            .capacity()
            .saturating_mul(std::mem::size_of::<Vec<String>>()),
    );
    // tracker_tiers has one outer Vec and one inner Vec per non-empty source
    // tier, with a possible extra tier for the standalone announce URL.
    total = total.saturating_add(
        meta.announce_list
            .len()
            .saturating_add(1)
            .saturating_mul(std::mem::size_of::<Vec<TrackerState>>()),
    );
    for tier in &meta.announce_list {
        total = total.saturating_add(
            tier.capacity()
                .saturating_mul(std::mem::size_of::<String>()),
        );
        for tracker in tier {
            add_owned_string_bytes(&mut total, tracker);
        }
    }

    total = total.saturating_add(
        meta.webseeds
            .capacity()
            .saturating_mul(std::mem::size_of::<String>()),
    );
    for webseed in &meta.webseeds {
        add_owned_string_bytes(&mut total, webseed);
    }
    let webseed_count = meta.webseeds.len();
    total = total
        .saturating_add(webseed_count.saturating_mul(std::mem::size_of::<u8>()))
        .saturating_add(webseed_count.saturating_mul(std::mem::size_of::<Option<Instant>>()))
        .saturating_add(webseed_count.saturating_mul(std::mem::size_of::<i64>()))
        .saturating_add(webseed_count.saturating_mul(std::mem::size_of::<Option<Instant>>()));

    total
}

/// Estimate the v1 task graph plus the compact v2 verification projection and
/// shared hybrid geometry retained by a hybrid task. The original v2 paths,
/// raw info dictionary, tracker strings, and name are dropped after the
/// projection is built.
pub(crate) fn persistent_hybrid_metadata_memory_bytes(
    v1: &TorrentMetaV1,
    v2: &TorrentMetaV2,
) -> usize {
    let payload_file_count = v1
        .files
        .iter()
        .filter(|file| !file.pad && file.length > 0)
        .count();
    let mut total = persistent_torrent_metadata_memory_bytes(v1)
        .saturating_add(std::mem::size_of::<HybridV2Meta>())
        .saturating_add(payload_file_count.saturating_mul(std::mem::size_of::<HybridV2File>()))
        .saturating_add(
            v2.files
                .len()
                .saturating_mul(std::mem::size_of::<V2FileSpan>()),
        )
        .saturating_add(2 * std::mem::size_of::<HybridGeometry>())
        .saturating_add(std::mem::size_of::<V2PieceMap>())
        .saturating_add(std::mem::size_of::<HashMap<ConnectionId, Plane>>())
        .saturating_add(4 * std::mem::size_of::<usize>())
        .saturating_add(
            v2.piece_layers
                .capacity()
                .saturating_mul(std::mem::size_of::<([u8; 32], Vec<[u8; 32]>)>()),
        );
    for hashes in v2.piece_layers.values() {
        total = total.saturating_add(
            hashes
                .capacity()
                .saturating_mul(std::mem::size_of::<[u8; 32]>()),
        );
    }
    // The hybrid geometry owns normalized v2 paths that point at the v1
    // storage layout. A rootless v2 tree can therefore add the v1 torrent-name
    // directory that is absent from the original v2 metainfo path.
    let path_bytes = |path: &SafeRelPath| {
        path.components()
            .iter()
            .map(|component| std::mem::size_of::<String>().saturating_add(component.len()))
            .sum::<usize>()
    };
    for (v1_file, v2_file) in v1
        .files
        .iter()
        .filter(|file| !file.pad)
        .zip(v2.files.iter().filter(|file| !file.pad))
    {
        total = total.saturating_add(path_bytes(&v1_file.path).max(path_bytes(&v2_file.path)));
    }
    total
}

/// Estimate the complete retained tracker projection, including bounded
/// response fields that are not present in metainfo. The ID and status text
/// portions are reserved at their protocol bounds so a later announce cannot
/// grow a live task outside the governor after admission.
fn tracker_state_memory_bytes(tiers: &[Vec<TrackerState>], outer_capacity: usize) -> usize {
    let mut total = outer_capacity.saturating_mul(std::mem::size_of::<Vec<TrackerState>>());
    for tier in tiers {
        total = total.saturating_add(
            tier.capacity()
                .saturating_mul(std::mem::size_of::<TrackerState>()),
        );
        for tracker in tier {
            total = total
                .saturating_add(tracker.url.capacity())
                .saturating_add(MAX_TRACKER_STATE_ID_BYTES)
                .saturating_add(MAX_TRACKER_STATE_TEXT_BYTES);
        }
    }
    total
}

fn reserve_tracker_state_memory(
    resources: &ResourceGovernor,
    tiers: &[Vec<TrackerState>],
    outer_capacity: usize,
) -> Result<Vec<MemoryLease>, String> {
    let bytes = u64::try_from(tracker_state_memory_bytes(tiers, outer_capacity))
        .map_err(|_| "tracker state memory estimate does not fit in u64".to_owned())?;
    if bytes == 0 {
        return Ok(Vec::new());
    }
    resources
        .try_acquire(MemoryClass::Metadata, bytes)
        .map(|lease| vec![lease])
        .ok_or_else(|| format!("tracker state allocation of {bytes} bytes denied"))
}

fn parse_persisted_file_path(path: &str) -> Result<rt_path::SafeRelPath, String> {
    rt_path::SafeRelPath::from_slash_separated(path, cfg!(windows))
        .map_err(|error| format!("invalid persisted torrent file path {path:?}: {error}"))
}

fn restore_runtime_projection(entry: &mut TorrentEntry, previous: &TorrentEntry) {
    entry.total_length = previous.total_length;
    entry.amount_left = previous.amount_left;
    entry.finalizing = previous.finalizing;
    entry.state = previous.state;
    entry.completed_at = previous.completed_at;
    entry.error_message = previous.error_message.clone();
}

fn restore_progress_projection(entry: &mut TorrentEntry, previous: &TorrentEntry) {
    entry.total_length = previous.total_length;
    entry.amount_left = previous.amount_left;
    entry.finalizing = previous.finalizing;
}

/// Packed piece availability. A `Vec<bool>` uses one allocation and one
/// byte-ish slot per piece on the hot peer path; this representation keeps
/// the exact piece count while using one bit per piece. It is intentionally
/// private to the engine because wire/API compatibility still uses ordinary
/// bool vectors at the protocol boundary.
#[derive(Debug, Clone, PartialEq, Eq)]
struct PieceBitmap {
    len: usize,
    words: Vec<u64>,
}

impl PieceBitmap {
    fn memory_bytes_for_len(len: usize) -> u64 {
        len.div_ceil(64).saturating_mul(std::mem::size_of::<u64>()) as u64
    }

    fn new(len: usize) -> Self {
        Self {
            len,
            words: vec![0; len.div_ceil(64)],
        }
    }

    /// A bitmap with every piece in `0..len` set. Used for BEP 6
    /// `HaveAll`, which stands in for a full `Bitfield` on the wire.
    fn all_true(len: usize) -> Self {
        Self {
            len,
            words: vec![u64::MAX; len.div_ceil(64)],
        }
    }

    #[cfg(test)]
    fn from_bools(bits: &[bool]) -> Self {
        let mut bitmap = Self::new(bits.len());
        for (index, value) in bits.iter().copied().enumerate() {
            if value {
                bitmap.set(index, true);
            }
        }
        bitmap
    }

    #[cfg(test)]
    fn from_bitfield(bits: &[u8], piece_count: usize) -> anyhow::Result<Self> {
        validate_bitfield_shape(bits, piece_count)?;
        Ok(Self::from_validated_bitfield(bits, piece_count))
    }

    fn from_validated_bitfield(bits: &[u8], piece_count: usize) -> Self {
        let mut bitmap = Self::new(piece_count);
        for (byte_index, byte) in bits.iter().copied().enumerate() {
            for bit in 0..8 {
                let piece = byte_index * 8 + bit;
                if piece >= piece_count {
                    break;
                }
                if byte & (0x80 >> bit) != 0 {
                    bitmap.set(piece, true);
                }
            }
        }
        bitmap
    }

    fn memory_bytes(&self) -> u64 {
        Self::memory_bytes_for_len(self.len)
    }

    fn len(&self) -> usize {
        self.len
    }

    fn get(&self, index: usize) -> Option<bool> {
        (index < self.len).then(|| self.words[index / 64] & (1_u64 << (index % 64)) != 0)
    }

    fn set(&mut self, index: usize, value: bool) {
        if index >= self.len {
            return;
        }
        let word = &mut self.words[index / 64];
        let mask = 1_u64 << (index % 64);
        if value {
            *word |= mask;
        } else {
            *word &= !mask;
        }
    }

    fn count_ones(&self) -> usize {
        self.words
            .iter()
            .enumerate()
            .map(|(index, word)| {
                let masked = if index + 1 == self.words.len() && !self.len.is_multiple_of(64) {
                    word & ((1_u64 << (self.len % 64)) - 1)
                } else {
                    *word
                };
                masked.count_ones() as usize
            })
            .sum()
    }

    fn first_set_u32(&self) -> Option<u32> {
        self.words.iter().enumerate().find_map(|(index, word)| {
            if *word == 0 {
                return None;
            }
            let piece = index
                .checked_mul(64)
                .and_then(|base| base.checked_add(word.trailing_zeros() as usize))?;
            u32::try_from(piece).ok()
        })
    }

    fn to_bitfield(&self) -> Vec<u8> {
        let mut bits = vec![0_u8; self.len.div_ceil(8)];
        for index in 0..self.len {
            if self.get(index).unwrap_or(false) {
                bits[index / 8] |= 0x80 >> (index % 8);
            }
        }
        bits
    }
}

impl PieceAvailability for PieceBitmap {
    fn has_piece(&self, piece: usize) -> bool {
        self.get(piece).unwrap_or(false)
    }

    fn for_each_set_piece(&self, piece_count: usize, visitor: &mut dyn FnMut(usize)) {
        self.for_each_set_piece_while(piece_count, &mut |piece| {
            visitor(piece);
            true
        });
    }

    fn for_each_set_piece_while(&self, piece_count: usize, visitor: &mut dyn FnMut(usize) -> bool) {
        let piece_count = piece_count.min(self.len);
        for (word_index, word) in self.words.iter().copied().enumerate() {
            let base = word_index.saturating_mul(u64::BITS as usize);
            if base >= piece_count {
                break;
            }
            let valid_bits = (piece_count - base).min(u64::BITS as usize);
            let mut pending = if valid_bits == u64::BITS as usize {
                word
            } else {
                word & ((1_u64 << valid_bits) - 1)
            };
            while pending != 0 {
                let piece = base + pending.trailing_zeros() as usize;
                if !visitor(piece) {
                    return;
                }
                pending &= pending - 1;
            }
        }
    }
}

/// Messages from the engine to a running torrent task.
#[derive(Debug)]
pub enum TorrentCmd {
    /// Pause the task.  Callers that need a durable lifecycle acknowledgement
    /// provide a reply sender; internal best-effort control paths may leave it
    /// absent.
    Pause {
        reply: Option<oneshot::Sender<Result<(), String>>>,
    },
    /// Begin resuming the task.  The acknowledgement is sent after the
    /// `Checking` transition is durable; the potentially long piece recheck
    /// continues afterward.
    Resume {
        reply: Option<oneshot::Sender<Result<(), String>>>,
    },
    Recheck {
        job_id: Option<String>,
    },
    CancelJob {
        job_id: String,
    },
    Reannounce,
    ReloadFilePolicy {
        reply: Option<oneshot::Sender<Result<(), String>>>,
    },
    UpdateLimits {
        limits: EngineTorrentLimits,
        reply: Option<oneshot::Sender<Result<(), String>>>,
    },
    /// Replace the persisted tracker override and apply it to the live task.
    /// A reply is used for API mutations; internal task-control paths may
    /// leave it absent.
    UpdateTrackers {
        trackers: Vec<String>,
        reply: Option<oneshot::Sender<Result<(), String>>>,
    },
    UpdatePeerExchange(bool),
    /// TNG-002: stops network activity, disconnects every peer, and drains
    /// any already-buffered peer events so no further disk write can reach
    /// `handle_block` after the reply is sent. The caller must hold this
    /// guarantee for the entire duration of a storage move against this
    /// torrent's files -- without it, a peer write racing the move could
    /// write to a path mid-rename, or resurrect a file at the old path
    /// after the move already deleted it there. Replies with whether the
    /// torrent was already paused before this call, so the caller can restore
    /// that state afterward instead of unconditionally resuming. The
    /// acknowledgement fails if the durable `Paused` transition could not be
    /// persisted.
    QuiesceForStorageMove {
        reply: oneshot::Sender<Result<bool, String>>,
    },
    /// TNG-002: re-points this task's cached `save_root` (and rebuilds the
    /// `MountScheduler` bound to it, so device-topology detection and any
    /// per-path handle-cache state is re-derived for the new location
    /// rather than staying pinned to the pre-move mount) after a storage
    /// move committed, then resumes activity unless the torrent was
    /// already paused before the move began. `new_save_root` is `None`
    /// when the move failed and rolled back -- the task simply resumes
    /// unchanged in that case). The reply is sent after the new runtime root
    /// is installed and, for an active torrent, the durable `Checking`
    /// transition succeeds. The potentially long recheck continues after the
    /// acknowledgement.
    ResumeAfterStorageMove {
        new_save_root: Option<PathBuf>,
        resume_paused: bool,
        reply: oneshot::Sender<Result<(), String>>,
    },
    Shutdown,
    /// Peers discovered by DHT.
    NewPeers(Vec<SocketAddr>),
    /// Peers explicitly added through a client API.
    PriorityPeers(Vec<SocketAddr>),
    /// Remove a peer immediately after the engine-wide ban policy admits it.
    /// Admission checks prevent future connections; this command closes an
    /// already-connected session and releases its piece/request state too.
    BanPeer(SocketAddr),
    /// Re-check the shared ban policy and evict every matching active peer.
    /// The command is intentionally payload-free so one ban request does not
    /// multiply by the number of newly banned endpoints and torrent tasks.
    EvictBannedPeers,
    /// Legacy queue-filler command retained for DHT tests/compatibility. API
    /// callers must use the bounded result-bearing command below.
    GetPeers {
        reply: oneshot::Sender<Vec<EnginePeerSnapshot>>,
    },
    GetPeerSnapshotCount {
        reply: oneshot::Sender<usize>,
    },
    GetPeerSnapshots {
        max_entries: usize,
        reply: oneshot::Sender<Result<Vec<EnginePeerSnapshot>, String>>,
    },
    GetWebseeds {
        reply: oneshot::Sender<Vec<EngineWebseedSnapshot>>,
    },
    GetRuntimeStats {
        reply: oneshot::Sender<TorrentRuntimeStats>,
    },
    GetPeerSummary {
        reply: oneshot::Sender<TorrentPeerStats>,
    },
    /// An inbound TCP peer whose handshake already matched this torrent.
    AcceptPeer {
        stream: TcpStream,
        peer_addr: SocketAddr,
        handshake: Handshake,
        peer_permit: OwnedSemaphorePermit,
    },
    /// An inbound uTP peer whose handshake already matched this torrent.
    AcceptUtpPeer {
        stream: Box<UtpStream>,
        peer_addr: SocketAddr,
        handshake: Handshake,
        peer_permit: OwnedSemaphorePermit,
    },
}

async fn receive_torrent_command(
    cmd_rx: &mut mpsc::Receiver<TorrentCmd>,
    pending_command: &mut Option<TorrentCmd>,
) -> Option<TorrentCmd> {
    if pending_command.is_some() {
        pending_command.take()
    } else {
        cmd_rx.recv().await
    }
}

/// Run the best-effort stopped announce without stranding the actor. A
/// lifecycle command can arrive after its caller has already received a
/// durable acknowledgement; keep that command in the actor's normal FIFO
/// path while the network future is cancelled.
async fn await_stopped_announce_or_queue_command(
    task: &mut TorrentTask,
    cmd_rx: &mut mpsc::Receiver<TorrentCmd>,
    pending_command: &mut Option<TorrentCmd>,
) {
    // Deciding which branch won, and restoring `task.stopped_announced`, must
    // happen after `operation` (which mutably borrows `task`) is dropped —
    // doing the restore assignment inside the `select!` arm itself conflicts
    // with that live borrow under NLL. So the arms only report an outcome;
    // `task` is touched once, below, outside the pinned future's scope.
    enum Outcome {
        Completed,
        Interrupted(Option<TorrentCmd>),
    }

    let outcome = {
        let operation = task.announce_stopped();
        tokio::pin!(operation);
        tokio::select! {
            _ = &mut operation => Outcome::Completed,
            command = cmd_rx.recv() => Outcome::Interrupted(command),
        }
    };

    if let Outcome::Interrupted(command) = outcome {
        // `announce_stopped` consumes the one-shot flag before it starts its
        // network work. If a later lifecycle command, or a closed command
        // channel, interrupts that future, no stopped request may have
        // reached any tracker. Restore the flag so the shutdown path can
        // make one bounded retry, and leave any received command pending in
        // the actor's normal FIFO path.
        task.stopped_announced = false;
        if let Some(command) = command {
            *pending_command = Some(command);
        }
    }
}

fn reject_torrent_command_during_shutdown(command: TorrentCmd) {
    const ERROR: &str = "torrent task is shutting down";
    match command {
        TorrentCmd::Pause { reply } | TorrentCmd::Resume { reply } => {
            if let Some(reply) = reply {
                let _ = reply.send(Err(ERROR.to_owned()));
            }
        }
        TorrentCmd::ReloadFilePolicy { reply } | TorrentCmd::UpdateLimits { reply, .. } => {
            if let Some(reply) = reply {
                let _ = reply.send(Err(ERROR.to_owned()));
            }
        }
        TorrentCmd::UpdateTrackers { reply, .. } => {
            if let Some(reply) = reply {
                let _ = reply.send(Err(ERROR.to_owned()));
            }
        }
        TorrentCmd::QuiesceForStorageMove { reply } => {
            let _ = reply.send(Err(ERROR.to_owned()));
        }
        TorrentCmd::ResumeAfterStorageMove { reply, .. } => {
            let _ = reply.send(Err(ERROR.to_owned()));
        }
        TorrentCmd::GetPeers { reply } => {
            let _ = reply.send(Vec::new());
        }
        TorrentCmd::GetPeerSnapshotCount { reply } => {
            let _ = reply.send(0);
        }
        TorrentCmd::GetPeerSnapshots { reply, .. } => {
            let _ = reply.send(Err(ERROR.to_owned()));
        }
        TorrentCmd::GetWebseeds { reply } => {
            let _ = reply.send(Vec::new());
        }
        TorrentCmd::GetRuntimeStats { reply } => {
            let _ = reply.send(Default::default());
        }
        TorrentCmd::GetPeerSummary { reply } => {
            let _ = reply.send(TorrentPeerStats::default());
        }
        TorrentCmd::AcceptPeer { .. }
        | TorrentCmd::AcceptUtpPeer { .. }
        | TorrentCmd::Shutdown
        | TorrentCmd::Recheck { .. }
        | TorrentCmd::CancelJob { .. }
        | TorrentCmd::Reannounce
        | TorrentCmd::NewPeers(_)
        | TorrentCmd::PriorityPeers(_)
        | TorrentCmd::UpdatePeerExchange(_)
        | TorrentCmd::BanPeer(_)
        | TorrentCmd::EvictBannedPeers => {}
    }
}

fn reject_pending_torrent_commands(
    cmd_rx: &mut mpsc::Receiver<TorrentCmd>,
    pending_command: &mut Option<TorrentCmd>,
) {
    if let Some(command) = pending_command.take() {
        reject_torrent_command_during_shutdown(command);
    }
    while let Ok(command) = cmd_rx.try_recv() {
        reject_torrent_command_during_shutdown(command);
    }
}

#[derive(Debug)]
enum RecheckOutcome {
    Complete,
    Paused {
        reply: Option<oneshot::Sender<Result<(), String>>>,
        previous_paused: bool,
        previous_restore_state: Option<TorrentState>,
        state_persisted: bool,
    },
    Cancelled,
    Shutdown,
    Failed(String),
}

struct RecheckInvalidPieces {
    values: Vec<i64>,
    total: usize,
}

impl RecheckInvalidPieces {
    fn new(piece_count: u32) -> Self {
        Self {
            values: Vec::with_capacity((piece_count as usize).min(rt_db::MAX_JOB_INVALID_PIECES)),
            total: 0,
        }
    }

    fn record(&mut self, piece: u32) {
        self.total = self.total.saturating_add(1);
        if self.values.len() < rt_db::MAX_JOB_INVALID_PIECES {
            self.values.push(piece as i64);
        }
    }
}

const JOB_STATE_RUNNING: &str = "running";
const JOB_STATE_PAUSED: &str = "paused";
const JOB_STATE_CANCELLING: &str = "cancelling";
const JOB_STATE_CANCELLED: &str = "cancelled";
const JOB_STATE_COMPLETED: &str = "completed";
const JOB_STATE_FAILED: &str = "failed";
const MAX_IN_MEMORY_PIECE_ASSEMBLIES: usize = 64;
const MAX_IN_MEMORY_PIECE_ASSEMBLY_BYTES_PER_TORRENT: usize = 64 * 1024 * 1024;
const PEER_REQUEST_PIPELINE_NORMAL: usize = 32;
const PEER_REQUEST_PIPELINE_CONSTRAINED: usize = 8;
/// Upper bound of the adaptive per-peer window (2 MiB of 16 KiB blocks).
const PEER_REQUEST_PIPELINE_ADAPTIVE_MAX: usize = 128;
/// Requests in flight across the whole torrent beyond which no peer's window
/// grows past the normal size (32 MiB of blocks).
const TORRENT_REQUESTS_ADAPTIVE_CAP: usize = 2_048;
/// Seconds of a peer's delivery rate the window should keep in flight.
const PEER_REQUEST_WINDOW_SECS: f64 = 0.25;
const TRACKER_PEER_CACHE_MIN: usize = 256;
const TRACKER_PEER_CACHE_MULTIPLIER: usize = 4;
// A HashSet bucket contains the socket address plus control bytes and can
// round capacity up during allocation. Reserve conservatively for the full
// bounded cache before accepting any tracker peers so later inserts cannot
// grow this state outside the governor.
const TRACKER_PEER_CACHE_BYTES_PER_ENTRY: u64 = 128;
// A dirty-piece watermark is only needed between storage-sync barriers. Keep
// the live set bounded; if more pieces become dirty than this, an unclean
// fastresume save deliberately carries no watermark and therefore falls back
// to a full recheck after a crash.
const MAX_RUNTIME_DIRTY_PIECES: usize = 65_536;

#[derive(Debug, Default)]
struct DirtyPieceTracker {
    pieces: HashSet<u32>,
    overflowed: bool,
}

impl DirtyPieceTracker {
    fn insert(&mut self, piece: u32) {
        if self.overflowed || self.pieces.contains(&piece) {
            return;
        }
        if self.pieces.len() >= MAX_RUNTIME_DIRTY_PIECES {
            self.pieces.clear();
            self.overflowed = true;
            return;
        }
        self.pieces.insert(piece);
    }

    fn len(&self) -> u64 {
        if self.overflowed {
            (MAX_RUNTIME_DIRTY_PIECES as u64).saturating_add(1)
        } else {
            self.pieces.len() as u64
        }
    }

    fn is_overflowed(&self) -> bool {
        self.overflowed
    }

    fn clear(&mut self) {
        self.pieces.clear();
        self.overflowed = false;
    }
}

/// Ceiling on pieces re-read by a `sample` completion verification, so a huge
/// torrent cannot turn a spot check into a near-full recheck.
const MAX_COMPLETION_SAMPLE_PIECES: usize = 16_384;
const COMPLETION_GATE_RETRY_MIN: Duration = Duration::from_secs(5);
const COMPLETION_GATE_RETRY_MAX: Duration = Duration::from_secs(60);
const MAX_REGRESSION_SAMPLE_PIECES: usize = 32;
const MAX_REGRESSION_FILES: usize = 20;

/// A finished download held back until its data is durable.
///
/// While it exists the torrent stays `Downloading` and reports one byte
/// remaining (see [`TorrentTask::reported_bytes_left`]), so no API consumer
/// sees a completed torrent whose data a power cut could still take back.
struct CompletionGate {
    runtime: Arc<CrashSafetyRuntime>,
    started: Instant,
    next_attempt: Instant,
    attempts: u32,
    settled: bool,
}

impl CompletionGate {
    fn new(runtime: Arc<CrashSafetyRuntime>) -> Self {
        runtime.record_gate_started();
        let now = Instant::now();
        CompletionGate {
            runtime,
            started: now,
            next_attempt: now,
            attempts: 0,
            settled: false,
        }
    }

    fn schedule_retry(&mut self) {
        let exponent = self.attempts.saturating_sub(1).min(4);
        let delay = COMPLETION_GATE_RETRY_MIN
            .saturating_mul(1u32 << exponent)
            .min(COMPLETION_GATE_RETRY_MAX);
        self.next_attempt = Instant::now() + delay;
    }

    fn release(mut self) {
        self.settled = true;
        self.runtime.record_gate_released();
    }
}

impl Drop for CompletionGate {
    fn drop(&mut self) {
        if !self.settled {
            self.runtime.record_gate_dropped();
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum BarrierOutcome {
    /// Payload files were fsynced and the scheduler issued proof of the barrier.
    Synced,
    /// `fast` durability mode: no fsync by design.
    SkippedFast,
    /// The filesystem cannot fsync (e.g. some FUSE mounts); best effort.
    Unsupported,
    Failed,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct SaveOutcome {
    barrier: BarrierOutcome,
    persisted: bool,
}

impl SaveOutcome {
    /// Whether a completion may be released on the strength of this save.
    fn releases_completion(&self) -> bool {
        self.persisted
            && matches!(
                self.barrier,
                BarrierOutcome::Synced | BarrierOutcome::Unsupported
            )
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum VerifyPlan {
    Sample,
    Full,
}

enum GateStep {
    /// Waiting for the barrier to succeed.
    Pending,
    /// The barrier succeeded; a read-back verification must run next.
    Verify(VerifyPlan),
    Released,
    /// The torrent is no longer complete; the gate was discarded.
    Dropped,
}

pub(crate) fn splitmix64(state: &mut u64) -> u64 {
    *state = state.wrapping_add(0x9E37_79B9_7F4A_7C15);
    let mut z = *state;
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^ (z >> 31)
}

/// Pick the pieces a `sample` completion verification re-reads: the first and
/// last piece of every file (where a size-only preallocation most often leaves
/// an unwritten tail or head), plus a deterministic pseudo-random `percent` of
/// all pieces. Returns `None` when the sample would cover every piece anyway,
/// meaning a full verification is no more expensive.
fn select_completion_sample(
    piece_map: &PieceMap,
    files: &[(u32, u64, bool)],
    percent: u8,
    seed: u64,
) -> Option<Vec<u32>> {
    let count = piece_map.piece_count as usize;
    if count == 0 || percent >= 100 {
        return None;
    }
    let mut selected = std::collections::BTreeSet::new();
    for &(index, length, pad) in files {
        if pad || length == 0 {
            continue;
        }
        if let Some((first, _)) = piece_map.piece_range_for_file_bytes(index, 0, 1) {
            selected.insert(first);
        }
        if let Some((_, last)) = piece_map.piece_range_for_file_bytes(index, length - 1, length) {
            selected.insert(last.saturating_sub(1));
        }
    }
    let target = ((count as u64) * u64::from(percent)).div_ceil(100).max(1) as usize;
    let target = target
        .min(MAX_COMPLETION_SAMPLE_PIECES)
        .max(selected.len().min(MAX_COMPLETION_SAMPLE_PIECES));
    let mut rng = seed;
    let mut attempts = target.saturating_mul(4).saturating_add(16);
    while selected.len() < target && attempts > 0 {
        attempts -= 1;
        selected.insert((splitmix64(&mut rng) % count as u64) as u32);
    }
    if selected.len() >= count {
        return None;
    }
    let mut pieces: Vec<u32> = selected.into_iter().collect();
    pieces.truncate(MAX_COMPLETION_SAMPLE_PIECES.max(1));
    Some(pieces)
}

/// Blocking body of the startup allocation audit: which piece ranges overlap a
/// hole or unwritten extent of any file. Files that are missing or unreadable
/// are left to the file-hint check.
fn audit_files_blocking(
    piece_map: &PieceMap,
    files: Vec<(u32, PathBuf, u64)>,
) -> (Vec<(u32, u32)>, u64) {
    let mut ranges = Vec::new();
    let mut unsupported = 0u64;
    for (index, path, length) in files {
        match rt_storage::audit_file_allocation(&path, length) {
            Ok(rt_storage::AllocationAudit::Gaps { gaps, .. }) => {
                for (start, end) in gaps.merged() {
                    if let Some(range) = piece_map.piece_range_for_file_bytes(index, start, end) {
                        ranges.push(range);
                    }
                }
            }
            Ok(rt_storage::AllocationAudit::Unsupported) => unsupported += 1,
            Err(_) => {}
        }
    }
    (ranges, unsupported)
}

fn effective_piece_assembly_soft_cap(configured_bytes: usize) -> usize {
    configured_bytes.min(MAX_IN_MEMORY_PIECE_ASSEMBLY_BYTES_PER_TORRENT)
}

fn memory_aware_request_pipeline(piece_assembly_bytes: usize, soft_cap_bytes: usize) -> usize {
    if soft_cap_bytes == 0 {
        // A zero assembly cap disables aggregation, not downloading. Blocks
        // take the direct-write path in this mode, so keep the peer pipeline
        // open instead of permanently starving the torrent.
        return PEER_REQUEST_PIPELINE_NORMAL;
    }
    if piece_assembly_bytes.saturating_mul(4) >= soft_cap_bytes.saturating_mul(3) {
        PEER_REQUEST_PIPELINE_CONSTRAINED
    } else {
        PEER_REQUEST_PIPELINE_NORMAL
    }
}

/// Window for one peer: the fixed floor, grown toward `rate x delay / block`
/// only for a peer with proven sustained delivery, never under memory
/// pressure, and only while the whole torrent stays under its request cap. A
/// fixed 32-block window limited a peer to `512 KiB / response time` (about
/// 10 MiB/s at 50 ms) no matter how fast it could deliver.
fn adaptive_request_pipeline(
    memory_pipeline: usize,
    peer_rate_bytes_per_sec: f64,
    other_peers_outstanding: usize,
) -> usize {
    if memory_pipeline < PEER_REQUEST_PIPELINE_NORMAL
        || peer_rate_bytes_per_sec.is_nan()
        || peer_rate_bytes_per_sec <= 0.0
    {
        return memory_pipeline;
    }
    let wanted = (peer_rate_bytes_per_sec * PEER_REQUEST_WINDOW_SECS / f64::from(MAX_BLOCK_SIZE))
        .ceil() as usize;
    let headroom = TORRENT_REQUESTS_ADAPTIVE_CAP.saturating_sub(other_peers_outstanding);
    wanted
        .clamp(
            PEER_REQUEST_PIPELINE_NORMAL,
            PEER_REQUEST_PIPELINE_ADAPTIVE_MAX,
        )
        .min(headroom.max(PEER_REQUEST_PIPELINE_NORMAL))
}

#[cfg(test)]
fn stricter_limit(torrent_limit: Option<u64>, global_limit: Option<u64>) -> Option<u64> {
    match (torrent_limit, global_limit) {
        (Some(torrent), Some(global)) => Some(torrent.min(global)),
        (Some(limit), None) | (None, Some(limit)) => Some(limit),
        (None, None) => None,
    }
}

pub(crate) fn tracker_peer_cache_cap(max_peers: usize) -> usize {
    max_peers
        .saturating_mul(TRACKER_PEER_CACHE_MULTIPLIER)
        .clamp(TRACKER_PEER_CACHE_MIN, MAX_TRACKER_PEERS)
}

pub(crate) fn reserve_webseed_body_bytes(
    resources: &ResourceGovernor,
    bytes: u32,
) -> anyhow::Result<MemoryLease> {
    resources
        .try_acquire(MemoryClass::WebseedBody, u64::from(bytes))
        .ok_or_else(|| anyhow::anyhow!("webseed body allocation of {bytes} bytes denied"))
}

fn reserve_peer_upload_bytes(
    resources: &ResourceGovernor,
    bytes: u32,
) -> anyhow::Result<MemoryLease> {
    resources
        .try_acquire(MemoryClass::PeerBuffer, u64::from(bytes))
        .ok_or_else(|| anyhow::anyhow!("peer upload buffer allocation of {bytes} bytes denied"))
}

#[cfg(test)]
fn reserve_peer_bitfield_bytes(
    resources: &ResourceGovernor,
    pieces: &PieceBitmap,
) -> anyhow::Result<MemoryLease> {
    reserve_peer_bitfield_len(resources, pieces.len())
}

fn reserve_peer_bitfield_len(
    resources: &ResourceGovernor,
    piece_count: usize,
) -> anyhow::Result<MemoryLease> {
    let bytes = PieceBitmap::memory_bytes_for_len(piece_count);
    resources
        .try_acquire(MemoryClass::PeerBuffer, bytes)
        .ok_or_else(|| anyhow::anyhow!("peer bitfield allocation of {bytes} bytes denied"))
}

fn reserve_peer_bitfield_wire_bytes(
    resources: &ResourceGovernor,
    pieces: &PieceBitmap,
) -> anyhow::Result<MemoryLease> {
    let bitfield_bytes = u64::try_from(pieces.len().div_ceil(8))
        .map_err(|_| anyhow::anyhow!("peer bitfield wire allocation does not fit in u64"))?;
    // The payload is held by Message, Message::encode creates a second
    // length-prefixed copy, and TCP's framed writer can retain a third copy
    // until the send flushes. Reserve the peak rather than letting a large
    // torrent's piece count bypass the peer-buffer governor.
    let bytes = bitfield_bytes.saturating_mul(3).saturating_add(5);
    resources
        .try_acquire(MemoryClass::PeerBuffer, bytes)
        .ok_or_else(|| anyhow::anyhow!("peer bitfield wire allocation of {bytes} bytes denied"))
}

fn reserve_peer_event_bytes(
    resources: &ResourceGovernor,
    bytes: usize,
) -> anyhow::Result<MemoryLease> {
    let bytes = u64::try_from(bytes)
        .map_err(|_| anyhow::anyhow!("peer event allocation does not fit in u64"))?;
    resources
        .try_acquire(MemoryClass::PeerBuffer, bytes)
        .ok_or_else(|| anyhow::anyhow!("peer event allocation of {bytes} bytes denied"))
}

fn reserve_metadata_payload_bytes(
    resources: &ResourceGovernor,
    bytes: usize,
) -> anyhow::Result<MemoryLease> {
    let bytes = u64::try_from(bytes)
        .map_err(|_| anyhow::anyhow!("metadata payload allocation does not fit in u64"))?;
    resources
        .try_acquire(MemoryClass::Metadata, bytes)
        .ok_or_else(|| anyhow::anyhow!("metadata payload allocation of {bytes} bytes denied"))
}

fn prepare_metadata_payload(
    resources: &ResourceGovernor,
    info_hash: &str,
    raw: &[u8],
) -> (Option<Arc<Vec<u8>>>, Option<MemoryLease>) {
    let mut parse_memory_lease = match crate::engine::reserve_torrent_parse_memory(
        resources,
        raw.len(),
        "metadata upload extraction",
    ) {
        Ok(lease) => lease,
        Err(error) => {
            warn!(
                component = "memory",
                operation = "extract_upload_payload",
                torrent = %info_hash,
                result = "denied",
                error = %error,
                "disabling metadata upload because parser memory admission failed"
            );
            return (None, None);
        }
    };
    let mut reserve = |additional| {
        u64::try_from(additional)
            .map(|bytes| parse_memory_lease.try_grow(bytes))
            .unwrap_or(false)
    };
    match torrent_info_bytes_with_allocation_reservation(raw, &mut reserve) {
        Ok(metadata) => match reserve_metadata_payload_bytes(resources, metadata.len()) {
            Ok(lease) => (Some(Arc::new(metadata)), Some(lease)),
            Err(error) => {
                warn!(
                    component = "metadata",
                    operation = "reserve_upload_payload",
                    torrent = %info_hash,
                    result = "denied",
                    error = %error,
                    "disabling metadata upload because the metadata memory budget is exhausted"
                );
                (None, None)
            }
        },
        Err(error) => {
            warn!(
                component = "metadata",
                operation = "extract_upload_payload",
                torrent = %info_hash,
                result = "unavailable",
                error = %error,
                "disabling metadata upload because the torrent info dictionary is unavailable"
            );
            (None, None)
        }
    }
}

fn reserve_piece_assembly_bytes(
    resources: &ResourceGovernor,
    bytes: usize,
) -> anyhow::Result<MemoryLease> {
    let bytes = u64::try_from(bytes)
        .map_err(|_| anyhow::anyhow!("piece assembly allocation does not fit in u64"))?;
    resources
        .try_acquire(MemoryClass::PieceAssembly, bytes)
        .ok_or_else(|| anyhow::anyhow!("piece assembly allocation of {bytes} bytes denied"))
}

pub(crate) fn prepare_tracker_peer_cache(
    resources: &ResourceGovernor,
    max_peers: usize,
) -> (HashSet<SocketAddr>, Option<MemoryLease>) {
    let capacity = tracker_peer_cache_cap(max_peers);
    let bytes = u64::try_from(capacity)
        .unwrap_or(u64::MAX)
        .saturating_mul(TRACKER_PEER_CACHE_BYTES_PER_ENTRY);
    let Some(memory_lease) = resources.try_acquire(MemoryClass::TrackerPeers, bytes) else {
        return (HashSet::new(), None);
    };

    let mut known = HashSet::new();
    if known.try_reserve(capacity).is_err() {
        // The governor lease is dropped with this return value, and the
        // cache remains disabled rather than allowing an infallible reserve
        // to turn allocator pressure into a process abort.
        return (HashSet::new(), None);
    }
    (known, Some(memory_lease))
}

#[cfg(test)]
fn remember_tracker_peers_bounded(
    known: &mut HashSet<SocketAddr>,
    peers: &[SocketAddr],
    cap: usize,
) -> u64 {
    let mut dropped = 0u64;
    for &peer in peers {
        if known.contains(&peer) {
            continue;
        }
        if known.len() >= cap {
            dropped = dropped.saturating_add(1);
            continue;
        }
        known.insert(peer);
    }
    dropped
}

/// A block received from a peer.
#[derive(Debug)]
pub struct BlockEvent {
    pub piece: u32,
    pub offset: u32,
    pub data: bytes::Bytes,
}

#[derive(Debug)]
struct LeasedBlockEvent {
    block: BlockEvent,
    _memory_lease: Option<Arc<MemoryLease>>,
    response_delay_nanos: Option<u64>,
    network_bytes: Option<u64>,
}

struct WebseedFetchInFlight {
    request: BlockRequest,
    connection: ConnectionId,
    seed_index: usize,
    task: JoinHandle<Result<WebseedFetchedBlock, WebseedFetchError>>,
}

impl Drop for WebseedFetchInFlight {
    fn drop(&mut self) {
        // Dropping a Tokio JoinHandle detaches the task. Keep the HTTP worker
        // tied to its torrent actor even if an unexpected exit drops state.
        self.task.abort();
    }
}

struct WebseedFetchedBlock {
    event: LeasedBlockEvent,
    fetch_elapsed: Duration,
    _source_permit: SourceRequestPermit,
}

#[derive(Debug)]
enum WebseedFetchError {
    Admission(String),
    SourceCapacity,
    Fetch(String),
}

struct PreparedWebseedRange {
    url: Url,
    file_offset: u64,
    block_offset: usize,
    length: usize,
}

const MAX_TRANSFER_COMPLETION_JOBS: usize = 64;

#[derive(Debug, Default)]
struct PendingPieceWork {
    generation: u64,
    writes_in_flight: usize,
    failed: bool,
    verify_ready: bool,
    verify_in_flight: bool,
    aggregate_write: bool,
    aggregate_write_ready: bool,
    verified_payload: Option<(bytes::Bytes, Option<Arc<MemoryLease>>)>,
}

enum TransferCompletion {
    BlockWritten {
        piece: u32,
        generation: u64,
        offset: u32,
        length: u64,
        downloaded_bytes: u64,
        result: Result<(), String>,
    },
    PieceVerified {
        piece: u32,
        generation: u64,
        result: VerifyResult,
        assembled: Option<(bytes::Bytes, Option<Arc<MemoryLease>>)>,
    },
    AggregatePieceWritten {
        piece: u32,
        generation: u64,
        result: Result<(), String>,
    },
}

type TransferJobFuture =
    Pin<Box<dyn std::future::Future<Output = TransferCompletion> + Send + 'static>>;

impl LeasedBlockEvent {
    fn new(block: BlockEvent, memory_lease: MemoryLease) -> anyhow::Result<Self> {
        let payload_bytes = u64::try_from(block.data.len())?;
        anyhow::ensure!(
            payload_bytes <= memory_lease.bytes(),
            "payload of {payload_bytes} bytes exceeds its {}-byte reservation",
            memory_lease.bytes()
        );
        Ok(Self {
            block,
            _memory_lease: Some(Arc::new(memory_lease)),
            response_delay_nanos: None,
            network_bytes: None,
        })
    }

    fn with_shared_lease(block: BlockEvent, memory_lease: Option<Arc<MemoryLease>>) -> Self {
        Self {
            block,
            _memory_lease: memory_lease,
            response_delay_nanos: None,
            network_bytes: None,
        }
    }

    fn with_optional_lease(
        block: BlockEvent,
        memory_lease: Option<MemoryLease>,
        response_delay_nanos: Option<u64>,
    ) -> anyhow::Result<Self> {
        let mut event = match memory_lease {
            Some(memory_lease) => Self::new(block, memory_lease),
            None => Ok(Self::with_shared_lease(block, None)),
        }?;
        event.response_delay_nanos = response_delay_nanos;
        Ok(event)
    }

    fn with_network_bytes(mut self, network_bytes: u64) -> Self {
        self.network_bytes = Some(network_bytes);
        self
    }

    #[cfg(test)]
    fn uncharged_for_test(piece: u32, offset: u32, data: bytes::Bytes) -> Self {
        Self {
            block: BlockEvent {
                piece,
                offset,
                data,
            },
            _memory_lease: None,
            response_delay_nanos: None,
            network_bytes: None,
        }
    }

    fn len(&self) -> usize {
        self.block.data.len()
    }
}

#[derive(Debug)]
struct PieceAssembly {
    data: Vec<u8>,
    /// Once every block has arrived, freeze the original allocation into an
    /// immutable view. Hashing and file writes can then share it without
    /// copying the completed piece.
    completed_data: Option<bytes::Bytes>,
    received: Vec<bool>,
    last_used: Instant,
    /// The data allocation stays in the process-wide piece-assembly budget
    /// while this assembly or any shared payload view remains live. Tests
    /// that exercise the standalone value constructor may omit the lease;
    /// production insertion always uses `with_memory_lease`.
    _memory_lease: Option<Arc<MemoryLease>>,
}

#[derive(Debug)]
struct LeasedPiecePayload {
    data: Vec<u8>,
    /// The immutable Bytes owner holds this lease until its last shared view
    /// is dropped, even if the torrent task is cancelled during queued I/O.
    _memory_lease: Option<Arc<MemoryLease>>,
}

impl AsRef<[u8]> for LeasedPiecePayload {
    fn as_ref(&self) -> &[u8] {
        &self.data
    }
}

impl PieceAssembly {
    #[cfg(test)]
    fn new(len: usize) -> Self {
        Self::new_with_lease(len, None)
    }

    fn with_memory_lease(len: usize, memory_lease: MemoryLease) -> Self {
        Self::new_with_lease(len, Some(memory_lease))
    }

    fn new_with_lease(len: usize, memory_lease: Option<MemoryLease>) -> Self {
        Self {
            data: vec![0; len],
            completed_data: None,
            received: vec![false; len.div_ceil(MAX_BLOCK_SIZE as usize)],
            last_used: Instant::now(),
            _memory_lease: memory_lease.map(Arc::new),
        }
    }

    fn insert(&mut self, offset: u32, block: &[u8]) -> anyhow::Result<()> {
        self.last_used = Instant::now();
        let start = offset as usize;
        let end = start
            .checked_add(block.len())
            .ok_or_else(|| anyhow::anyhow!("piece block offset overflow"))?;
        if end > self.len() {
            anyhow::bail!(
                "piece block range {}..{} exceeds piece length {}",
                start,
                end,
                self.len()
            );
        }
        let block_idx = start / MAX_BLOCK_SIZE as usize;
        let Some(received) = self.received.get_mut(block_idx) else {
            anyhow::bail!("piece block index {block_idx} out of range");
        };
        if *received {
            if self.data()[start..end] == *block {
                return Ok(());
            }
            anyhow::bail!("conflicting duplicate block at offset {offset}");
        }
        self.data[start..end].copy_from_slice(block);
        *received = true;
        if self.is_complete() {
            self.completed_data = Some(bytes::Bytes::from_owner(LeasedPiecePayload {
                data: std::mem::take(&mut self.data),
                _memory_lease: self._memory_lease.clone(),
            }));
        }
        Ok(())
    }

    fn data(&self) -> &[u8] {
        self.completed_data
            .as_deref()
            .unwrap_or(self.data.as_slice())
    }

    fn is_complete(&self) -> bool {
        self.received.iter().all(|received| *received)
    }

    fn received_blocks(
        &self,
        resources: &ResourceGovernor,
        piece: u32,
    ) -> anyhow::Result<Vec<(u32, LeasedBlockEvent)>> {
        let mut blocks = Vec::new();
        for (block_idx, received) in self.received.iter().enumerate() {
            if !received {
                continue;
            }
            let start = block_idx.saturating_mul(MAX_BLOCK_SIZE as usize);
            let end = start
                .saturating_add(MAX_BLOCK_SIZE as usize)
                .min(self.len());
            if start >= end {
                continue;
            }
            let len = end - start;
            let offset = start as u32;
            if let Some(data) = &self.completed_data {
                blocks.push((
                    offset,
                    LeasedBlockEvent::with_shared_lease(
                        BlockEvent {
                            piece,
                            offset,
                            data: data.slice(start..end),
                        },
                        self._memory_lease.clone(),
                    ),
                ));
            } else {
                let lease = reserve_peer_event_bytes(resources, len)?;
                let data = bytes::Bytes::copy_from_slice(&self.data[start..end]);
                blocks.push((
                    offset,
                    LeasedBlockEvent::new(
                        BlockEvent {
                            piece,
                            offset,
                            data,
                        },
                        lease,
                    )?,
                ));
            }
        }
        Ok(blocks)
    }

    /// Split received ranges into immutable views that share the assembly's
    /// backing allocation. This is used when an assembly is evicted, so the
    /// spill path does not allocate another copy while memory is constrained.
    fn into_received_blocks(self, piece: u32) -> anyhow::Result<Vec<(u32, LeasedBlockEvent)>> {
        let Self {
            data,
            completed_data,
            received,
            _memory_lease,
            ..
        } = self;
        let data = completed_data.unwrap_or_else(|| bytes::Bytes::from(data));
        let memory_lease = _memory_lease;
        let mut blocks = Vec::new();
        blocks.try_reserve_exact(received.len())?;
        for (block_idx, is_received) in received.into_iter().enumerate() {
            if !is_received {
                continue;
            }
            let start = block_idx.saturating_mul(MAX_BLOCK_SIZE as usize);
            let end = start
                .saturating_add(MAX_BLOCK_SIZE as usize)
                .min(data.len());
            if start >= end {
                continue;
            }
            let offset = start as u32;
            blocks.push((
                offset,
                LeasedBlockEvent::with_shared_lease(
                    BlockEvent {
                        piece,
                        offset,
                        data: data.slice(start..end),
                    },
                    memory_lease.clone(),
                ),
            ));
        }
        Ok(blocks)
    }

    fn len(&self) -> usize {
        self.data().len()
    }
}

fn evict_piece_assemblies_to_budget(
    assemblies: &mut HashMap<u32, PieceAssembly>,
    assembly_bytes: &mut usize,
    current_piece: u32,
    max_assemblies: usize,
    max_bytes: usize,
) -> Vec<(u32, PieceAssembly)> {
    let mut evictions = Vec::new();
    while assemblies.len() > max_assemblies || *assembly_bytes > max_bytes {
        let Some(evict_piece) = assemblies
            .iter()
            .filter(|(piece, _)| **piece != current_piece)
            .min_by_key(|(_, assembly)| assembly.last_used)
            .map(|(piece, _)| *piece)
        else {
            break;
        };

        if let Some(assembly) = assemblies.remove(&evict_piece) {
            *assembly_bytes = assembly_bytes.saturating_sub(assembly.len());
            evictions.push((evict_piece, assembly));
        }
    }
    evictions
}

#[derive(Debug)]
enum PeerEvent {
    PlaneSelected {
        peer: SocketAddr,
        id: PeerId,
        plane: Plane,
    },
    Bitfield {
        peer: SocketAddr,
        id: PeerId,
        pieces: PieceBitmap,
        _memory_lease: MemoryLease,
    },
    Have {
        peer: SocketAddr,
        id: PeerId,
        piece: u32,
    },
    Unchoked {
        peer: SocketAddr,
        id: PeerId,
        download_generation: u64,
    },
    Choked {
        peer: SocketAddr,
        id: PeerId,
        download_generation: u64,
        fast_negotiated: bool,
        /// Requests that reached the wire. Fast Choke keeps these alive;
        /// legacy Choke reports them for picker cancellation.
        outstanding: Vec<BlockRequest>,
    },
    Interested {
        peer: SocketAddr,
        id: PeerId,
    },
    NotInterested {
        peer: SocketAddr,
        id: PeerId,
    },
    Piece {
        peer: SocketAddr,
        id: PeerId,
        block: LeasedBlockEvent,
    },
    RequestSent {
        peer: SocketAddr,
        id: PeerId,
        request: BlockRequest,
    },
    RequestRejected {
        peer: SocketAddr,
        id: PeerId,
        rejected: BlockRequest,
    },
    Uploaded {
        peer: SocketAddr,
        id: PeerId,
    },
    Disconnected {
        peer: SocketAddr,
        id: PeerId,
        outstanding: Vec<BlockRequest>,
    },
    RequestTimedOut {
        peer: SocketAddr,
        id: PeerId,
        timed_out: Vec<BlockRequest>,
    },
    ExtendedHandshake {
        peer: SocketAddr,
        id: PeerId,
        ut_metadata_id: Option<u8>,
        ut_pex_id: Option<u8>,
        metadata_size: Option<u32>,
        reqq: Option<usize>,
    },
    PeerExchange {
        peer: SocketAddr,
        id: PeerId,
        peers: Vec<SocketAddr>,
        dropped: Vec<SocketAddr>,
        _memory_lease: MemoryLease,
    },
}

impl PeerEvent {
    fn identity(&self) -> (SocketAddr, PeerId) {
        match self {
            Self::PlaneSelected { peer, id, .. }
            | Self::Bitfield { peer, id, .. }
            | Self::Have { peer, id, .. }
            | Self::Unchoked { peer, id, .. }
            | Self::Choked { peer, id, .. }
            | Self::Interested { peer, id }
            | Self::NotInterested { peer, id }
            | Self::Piece { peer, id, .. }
            | Self::RequestSent { peer, id, .. }
            | Self::RequestRejected { peer, id, .. }
            | Self::Uploaded { peer, id, .. }
            | Self::Disconnected { peer, id, .. }
            | Self::RequestTimedOut { peer, id, .. }
            | Self::ExtendedHandshake { peer, id, .. }
            | Self::PeerExchange { peer, id, .. } => (*peer, *id),
        }
    }
}

#[derive(Debug)]
struct PeerHandle {
    id: PeerId,
    transfer_conn: ConnectionId,
    plane: Plane,
    cmd_tx: mpsc::Sender<PeerCommand>,
    upload_control: RateLimitCancellation,
    shutdown_control: RateLimitCancellation,
    /// Out-of-band cancellation for a peer whose command queue may be full.
    /// Control messages such as a ban must not depend on an untrusted peer
    /// draining a bounded command queue.
    peer_task: Option<JoinHandle<()>>,
    peer_has: PieceBitmap,
    peer_have_count: usize,
    choked: bool,
    upload_choked: bool,
    interested: bool,
    downloaded: u64,
    uploaded: u64,
    upload_accounting: Arc<UploadAccountingState>,
    download_rate: f64,
    upload_rate: f64,
    download_rate_window: u64,
    upload_rate_window: u64,
    download_rate_window_started: Instant,
    upload_rate_window_started: Instant,
    outstanding: usize,
    /// Invalidates requests still waiting in the peer command queue after a
    /// remote Choke. Requests already on the wire remain valid under Fast.
    download_generation: u64,
    /// Coordinates mirrored for picker cancellation; the peer loop owns each
    /// response-byte lease after its request command is accepted.
    requested: Vec<BlockRequest>,
    ut_metadata_id: Option<u8>,
    ut_pex_id: Option<u8>,
    metadata_size: Option<u32>,
    request_window: WindowController,
    _peer_permit: OwnedSemaphorePermit,
    /// Dense per-peer availability maps are sized by the torrent's piece
    /// count. Keep their backing allocation under the process-wide peer
    /// memory budget for the full lifetime of the peer entry.
    _bitmap_memory_lease: MemoryLease,
    /// HAVE messages that could not enter the bounded peer mailbox. The
    /// bitmap keeps this retry state bounded by the torrent's piece map and
    /// avoids losing a protocol update when a peer is briefly backlogged.
    pending_have: PieceBitmap,
}

impl PeerHandle {
    fn replace_peer_have(&mut self, pieces: PieceBitmap) {
        self.peer_have_count = pieces.count_ones();
        self.peer_has = pieces;
    }

    fn add_peer_have(&mut self, piece: usize) -> bool {
        if self.peer_has.get(piece) != Some(false) {
            return false;
        }
        self.peer_has.set(piece, true);
        self.peer_have_count = self.peer_have_count.saturating_add(1);
        true
    }
}

#[derive(Debug)]
enum PeerCommand {
    Request {
        request: BlockRequest,
        /// A queued request from before the latest Choke is discarded after
        /// the peer loop advances its download generation.
        download_generation: u64,
        /// Acquired before enqueue; moves into the peer loop's outstanding
        /// request and is settled when the matching payload arrives.
        memory_lease: MemoryLease,
        rate_grant: Option<RateAdmissionGrant>,
        source_permit: Option<SourceRequestPermit>,
    },
    /// Endgame loser cancellation. The peer loop keeps an on-wire request and
    /// its response lease outstanding because a Piece or Reject may still
    /// race the Cancel.
    Cancel {
        request: BlockRequest,
    },
    Have(u32),
    Choke,
    Unchoke,
    Shutdown,
}

struct UploadContext {
    save_root: PathBuf,
    // TNG-014: shared, not owned per peer -- PieceMap's `files: Vec<FileSpan>`
    // scales with file count, and a fresh deep clone on every new peer
    // connection (`upload_context()` below) was real, avoidable per-peer
    // memory and allocation cost for torrents with many files, at swarm
    // scale. `PieceMap` is only ever read after construction (never
    // mutated), so an `Arc` clone here is a cheap refcount bump instead.
    piece_map: Arc<PieceMap>,
    hybrid_v2: Option<Arc<HybridV2Meta>>,
    plane: Plane,
    storage: MountScheduler,
    resources: ResourceGovernor,
    have_pieces: PieceBitmap,
    /// The upload-side availability bitmap is one more dense per-peer map.
    /// Keep its backing allocation charged until the peer task releases it.
    _bitmap_memory_lease: Option<MemoryLease>,
    metadata: Option<Arc<Vec<u8>>>,
    is_private: bool,
    pex_enabled: bool,
    /// BEP 6 was negotiated with this peer. A request we will not serve must
    /// then be answered with Reject Request instead of being dropped.
    fast_negotiated: bool,
    upload_control: RateLimitCancellation,
    shutdown_control: RateLimitCancellation,
    upload_rate: UploadRateAdmission,
    /// Bytes already sent on the socket but not yet folded into actor-owned
    /// transfer totals. The actor drains this on each batch notification or
    /// peer removal, including task cancellation.
    upload_accounting: Arc<UploadAccountingState>,
}

#[derive(Debug)]
struct UploadAccountingState {
    pending_uploaded_bytes: AtomicU64,
    batch_bytes: AtomicU64,
}

impl UploadAccountingState {
    fn new(batch_bytes: u64) -> Self {
        Self {
            pending_uploaded_bytes: AtomicU64::new(0),
            batch_bytes: AtomicU64::new(batch_bytes.max(1)),
        }
    }
}

fn atomic_saturating_add(counter: &AtomicU64, addend: u64) {
    let mut current = counter.load(Ordering::Relaxed);
    loop {
        let next = current.saturating_add(addend);
        match counter.compare_exchange_weak(current, next, Ordering::Relaxed, Ordering::Relaxed) {
            Ok(_) => return,
            Err(observed) => current = observed,
        }
    }
}

#[derive(Default)]
struct UploadAccountingBatch {
    bytes_since_notification: u64,
}

impl UploadAccountingBatch {
    fn is_empty(&self) -> bool {
        self.bytes_since_notification == 0
    }

    fn add(&mut self, bytes: u64, batch_bytes: u64) -> bool {
        self.bytes_since_notification = self.bytes_since_notification.saturating_add(bytes);
        self.bytes_since_notification >= batch_bytes.max(1)
    }

    fn clear(&mut self) {
        self.bytes_since_notification = 0;
    }
}

impl UploadContext {
    fn hybrid_v2_wire_hash(&self) -> Option<[u8; 20]> {
        hybrid_v2_wire_hash(self.hybrid_v2.as_deref())
    }

    fn outgoing_plane(&self, v1_info_hash: [u8; 20], remote: &Handshake) -> anyhow::Result<Plane> {
        outgoing_hybrid_plane(v1_info_hash, self.hybrid_v2.as_deref(), remote)
    }

    fn peer_wire_hash(&self, v1_info_hash: [u8; 20], plane: Plane) -> Option<[u8; 20]> {
        match plane {
            Plane::V1 => Some(v1_info_hash),
            Plane::V2 => self.hybrid_v2_wire_hash(),
        }
    }

    fn canonical_to_wire_block(&self, block: BlockExtent) -> Option<BlockExtent> {
        match self.plane {
            Plane::V1 => Some(block),
            Plane::V2 => self
                .hybrid_v2
                .as_ref()?
                .geometry
                .as_ref()?
                .canonical_v2_block_for_v1(block),
        }
    }

    fn wire_to_canonical_block(&self, block: BlockExtent) -> Option<BlockExtent> {
        match self.plane {
            Plane::V1 => Some(block),
            Plane::V2 => self
                .hybrid_v2
                .as_ref()?
                .geometry
                .as_ref()?
                .canonical_v1_block_for_v2(block),
        }
    }

    fn expand_wire_block(
        &self,
        block: BlockExtent,
        payload: &bytes::Bytes,
    ) -> Option<(BlockExtent, bytes::Bytes)> {
        match self.plane {
            Plane::V1 => Some((block, payload.clone())),
            Plane::V2 => {
                let (canonical, expanded) = self
                    .hybrid_v2
                    .as_ref()?
                    .geometry
                    .as_ref()?
                    .expand_v2_block_to_v1(block, payload)?;
                Some((canonical, bytes::Bytes::from(expanded)))
            }
        }
    }

    fn v1_block_is_padding_only(&self, block: BlockExtent) -> bool {
        self.hybrid_v2
            .as_ref()
            .and_then(|hybrid| hybrid.geometry.as_ref())
            .and_then(|geometry| geometry.v1().block_content_ranges(block).ok())
            .is_some_and(|ranges| {
                !ranges.is_empty() && ranges.iter().all(|range| range.content.pad)
            })
    }
}

// These collections have a protocol scheduling bound; keep their elements
// inline instead of allocating a new Vec at each stage of every read.
type UploadBatch<T> = smallvec::SmallVec<[T; MAX_UPLOAD_READ_BATCH_BLOCKS]>;

struct UploadReadContext {
    save_root: PathBuf,
    piece_map: Arc<PieceMap>,
    hybrid_v2: Option<Arc<HybridV2Meta>>,
    plane: Plane,
    storage: MountScheduler,
    resources: ResourceGovernor,
    upload_control: RateLimitCancellation,
    upload_rate: UploadRateAdmission,
    read_admission: SharedUploadReadHandle,
}

#[derive(Clone)]
struct UploadRateAdmission {
    network_budget: GlobalNetworkBudget,
    peer: RatePeerId,
}

struct LeasedUploadBlock {
    data: bytes::Bytes,
    _lease: UploadMemoryLease,
    _read_permit: UploadReadPermit,
    rate_grant: Option<RateAdmissionGrant>,
}

/// A single block has one owner. Only slices of a multi-block backing need
/// shared ownership of their memory charge.
enum UploadMemoryLease {
    Single { _lease: MemoryLease },
    Shared { _lease: Arc<MemoryLease> },
}

#[cfg(test)]
impl UploadMemoryLease {
    fn bytes(&self) -> u64 {
        match self {
            Self::Single { _lease } => _lease.bytes(),
            Self::Shared { _lease } => _lease.bytes(),
        }
    }
}

#[derive(Clone, Copy)]
struct UploadReadSpan {
    file_ordinal: usize,
    offset: u64,
    length: usize,
}

#[derive(Clone, Copy)]
struct UploadReadSpec {
    request: UploadRequest,
    span: Option<UploadReadSpan>,
    choke_critical: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct UploadRequest {
    /// Canonical v1 coordinate used by storage and inbound obligations.
    piece: u32,
    begin: u32,
    length: u32,
    /// Coordinate echoed on this peer's negotiated wire plane.
    wire_piece: u32,
    wire_begin: u32,
    wire_length: u32,
}

impl UploadRequest {
    fn new(canonical: BlockExtent, wire: BlockExtent) -> Self {
        Self {
            piece: canonical.piece,
            begin: canonical.begin,
            length: canonical.length,
            wire_piece: wire.piece,
            wire_begin: wire.begin,
            wire_length: wire.length,
        }
    }

    fn from_wire(block: BlockExtent) -> Self {
        Self::new(block, block)
    }

    fn canonical_block(self) -> BlockExtent {
        BlockExtent::new(self.piece, self.begin, self.length)
    }

    fn wire_block(self) -> BlockExtent {
        BlockExtent::new(self.wire_piece, self.wire_begin, self.wire_length)
    }
}

enum UploadReadCompletion {
    Completed {
        request: UploadRequest,
        result: anyhow::Result<LeasedUploadBlock>,
        rate_interrupted: bool,
    },
    Panicked {
        request: UploadRequest,
    },
}

#[cfg(test)]
async fn catch_upload_read(
    request: UploadRequest,
    read: impl std::future::Future<Output = (anyhow::Result<LeasedUploadBlock>, bool)> + Send + 'static,
) -> UploadReadCompletion {
    match std::panic::AssertUnwindSafe(read).catch_unwind().await {
        Ok((result, rate_interrupted)) => UploadReadCompletion::Completed {
            request,
            result,
            rate_interrupted,
        },
        Err(_) => UploadReadCompletion::Panicked { request },
    }
}

/// Own in-flight upload-read futures in the peer loop so dropping the owner
/// immediately drops pending I/O and releases its leases.
struct UploadReadTasks<F> {
    futures: futures::stream::FuturesUnordered<F>,
    pending_requests: usize,
}

impl<F> Default for UploadReadTasks<F> {
    fn default() -> Self {
        Self {
            futures: futures::stream::FuturesUnordered::new(),
            pending_requests: 0,
        }
    }
}

impl<F> UploadReadTasks<F> {
    fn push_batch(&mut self, future: F, request_count: usize) {
        debug_assert!(request_count > 0);
        self.pending_requests = self.pending_requests.saturating_add(request_count);
        self.futures.push(future);
    }

    fn finish_request(&mut self) {
        self.pending_requests = self.pending_requests.saturating_sub(1);
    }

    fn pending_request_count(&self) -> usize {
        self.pending_requests
    }
}

impl<F> std::ops::Deref for UploadReadTasks<F> {
    type Target = futures::stream::FuturesUnordered<F>;

    fn deref(&self) -> &Self::Target {
        &self.futures
    }
}

impl<F> std::ops::DerefMut for UploadReadTasks<F> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.futures
    }
}

#[derive(Debug, Clone)]
struct HybridV2Meta {
    info_hash_v2: [u8; 32],
    piece_length: u64,
    files: Vec<HybridV2File>,
    /// Retains the v2 piece map and shares the task's existing v1 map.
    geometry: Option<Arc<HybridGeometry>>,
    piece_layers: HashMap<[u8; 32], Vec<[u8; 32]>>,
    valid_layout: bool,
}

#[derive(Debug, Clone)]
struct HybridV2File {
    /// The v1 file index used by `PieceMap`; v1 padding entries can make this
    /// differ from the file's v2 index.
    file_index: u32,
    /// Lookup key for the file region returned by the shared v2 geometry.
    v2_file_index: u32,
    length: u64,
    pieces_root: Option<[u8; 32]>,
}

impl HybridV2Meta {
    fn from_validated_views(
        v1: &TorrentMetaV1,
        v1_piece_map: Arc<PieceMap>,
        v2: TorrentMetaV2,
    ) -> Self {
        let v1_payload_count = v1
            .files
            .iter()
            .filter(|file| !file.pad && file.length > 0)
            .count();
        let mut files = Vec::with_capacity(v1_payload_count);
        let mut valid_layout = v1.piece_length == v2.piece_length
            && v2.piece_length >= V2_BLOCK_SIZE as u64
            && v2.piece_length.is_power_of_two();

        // A v1 multi-file torrent stores its payload under `name/`, while a
        // BEP 52 file tree is rootless unless its creator explicitly includes
        // that same directory. Normalize every v2 file span to the matching
        // v1 path so path-based geometry comparisons and disk reads refer to
        // the one physical payload.
        let mut canonical_v2_paths = vec![None; v2.files.len()];
        let mut v1_files = v1.files.iter().filter(|file| !file.pad);
        for v2_file in v2.files.iter().filter(|file| !file.pad) {
            let Some(v1_file) = v1_files.next() else {
                valid_layout = false;
                break;
            };
            if v1.name != v2.name
                || !hybrid_file_paths_match(&v1.name, &v1_file.path, &v2_file.path)
                || v1_file.length != v2_file.length
                || (v2_file.length > 0 && v1_file.offset != v2_file.piece_offset)
            {
                valid_layout = false;
            }
            match usize::try_from(v2_file.index)
                .ok()
                .and_then(|index| canonical_v2_paths.get_mut(index))
            {
                Some(path) => *path = Some(v1_file.path.clone()),
                None => valid_layout = false,
            }
            if v2_file.length > 0 {
                files.push(HybridV2File {
                    file_index: v1_file.index,
                    v2_file_index: v2_file.index,
                    length: v2_file.length,
                    pieces_root: v2_file.pieces_root,
                });
            }
        }
        if v1_files.next().is_some() {
            valid_layout = false;
        }

        let v2_spans = v2
            .files
            .iter()
            .map(|file| {
                let path = usize::try_from(file.index)
                    .ok()
                    .and_then(|index| canonical_v2_paths.get(index))
                    .and_then(Option::as_ref)
                    .unwrap_or(&file.path)
                    .clone();
                V2FileSpan {
                    file_index: file.index,
                    path,
                    piece_offset: file.piece_offset,
                    length: file.length,
                    pad: file.pad,
                }
            })
            .collect();
        let geometry = V2PieceMap::new(v2.piece_length, v2_spans)
            .ok()
            .map(Arc::new)
            .map(|v2_piece_map| Arc::new(HybridGeometry::new(v1_piece_map, v2_piece_map)));
        valid_layout &= geometry.is_some();
        if let Some(geometry) = &geometry {
            // The live hybrid adapter deliberately keeps v1 piece numbers as
            // canonical actor coordinates. A v2 wire plane is safe only when
            // both validated views expose the same global piece index range.
            valid_layout &= PieceGeometry::piece_count(geometry.v1())
                == PieceGeometry::piece_count(geometry.v2());
        }
        files.sort_unstable_by_key(|file| file.v2_file_index);

        Self {
            info_hash_v2: v2.info_hash_v2,
            piece_length: v2.piece_length,
            files,
            geometry,
            piece_layers: v2.piece_layers,
            valid_layout,
        }
    }

    fn piece_expectation(&self, piece: u32) -> Option<HybridV2PieceExpectation> {
        if !self.valid_layout || self.piece_length == 0 {
            return None;
        }
        let geometry = self.geometry.as_ref()?;
        let region = geometry.v2().piece_to_file(piece).ok()?;
        let file_index = self
            .files
            .binary_search_by_key(&region.file_index, |file| file.v2_file_index)
            .ok()?;
        let file = self.files.get(file_index)?;
        let file_offset = region.file_offset;
        let content_len = u64::from(region.length);
        let pieces_root = file.pieces_root?;
        let (expected_root, piece_leaf_count) = if file.length <= self.piece_length {
            (pieces_root, None)
        } else {
            let layer_index = usize::try_from(file_offset / self.piece_length).ok()?;
            let root = *self.piece_layers.get(&pieces_root)?.get(layer_index)?;
            let leaf_count = usize::try_from(self.piece_length / V2_BLOCK_SIZE as u64).ok()?;
            (root, Some(leaf_count))
        };

        Some(HybridV2PieceExpectation {
            file_index: file.file_index,
            file_offset,
            content_len,
            expected_root,
            piece_leaf_count,
        })
    }
}

fn hybrid_file_paths_match(
    torrent_name: &str,
    v1_path: &SafeRelPath,
    v2_path: &SafeRelPath,
) -> bool {
    let v1_components = v1_path.components();
    let v2_components = v2_path.components();
    v1_components == v2_components
        || (v1_components.len() == v2_components.len().saturating_add(1)
            && v1_components
                .first()
                .is_some_and(|component| component == torrent_name)
            && v1_components.get(1..) == Some(v2_components))
}

fn incoming_hybrid_plane(
    v1_info_hash: [u8; 20],
    hybrid_v2: Option<&HybridV2Meta>,
    handshake: &Handshake,
) -> Option<Plane> {
    if handshake.info_hash == v1_info_hash {
        return Some(Plane::V1);
    }
    let v2_wire_hash = hybrid_v2_wire_hash(hybrid_v2)?;
    (handshake.info_hash == v2_wire_hash && handshake.reserved.supports_v2()).then_some(Plane::V2)
}

fn hybrid_v2_wire_hash(hybrid_v2: Option<&HybridV2Meta>) -> Option<[u8; 20]> {
    let hybrid = hybrid_v2.filter(|hybrid| hybrid.valid_layout)?;
    hybrid.info_hash_v2[..20].try_into().ok()
}

fn outgoing_hybrid_plane(
    v1_info_hash: [u8; 20],
    hybrid_v2: Option<&HybridV2Meta>,
    remote: &Handshake,
) -> anyhow::Result<Plane> {
    if remote.info_hash == v1_info_hash {
        return Ok(Plane::V1);
    }
    if hybrid_v2_wire_hash(hybrid_v2) == Some(remote.info_hash) && remote.reserved.supports_v2() {
        return Ok(Plane::V2);
    }
    anyhow::bail!("peer returned an unknown or unsupported hybrid infohash")
}

#[derive(Clone)]
struct TransferIoContext {
    meta: Arc<TorrentMetaV1>,
    piece_map: Arc<PieceMap>,
    save_root: PathBuf,
    storage: MountScheduler,
    prepared_files: Arc<Mutex<HashSet<u32>>>,
    prepared_file_locks: Arc<tokio::sync::Mutex<HashMap<u32, Arc<tokio::sync::Mutex<()>>>>>,
    resources: ResourceGovernor,
}

async fn prepare_transfer_file_once(
    context: &TransferIoContext,
    file_index: u32,
    path: &std::path::Path,
    length: u64,
) -> anyhow::Result<()> {
    prepare_file_once_with_locks(
        &context.storage,
        &context.prepared_files,
        &context.prepared_file_locks,
        file_index,
        path,
        length,
    )
    .await
}

pub(crate) async fn prepare_file_once_with_locks(
    storage: &MountScheduler,
    prepared_files: &Mutex<HashSet<u32>>,
    prepared_file_locks: &tokio::sync::Mutex<HashMap<u32, Arc<tokio::sync::Mutex<()>>>>,
    file_index: u32,
    path: &std::path::Path,
    length: u64,
) -> anyhow::Result<()> {
    let file_lock = {
        let mut locks = prepared_file_locks.lock().await;
        Arc::clone(
            locks
                .entry(file_index)
                .or_insert_with(|| Arc::new(tokio::sync::Mutex::new(()))),
        )
    };
    let _file_guard = file_lock.lock().await;
    if lock_prepared_files(prepared_files).contains(&file_index) {
        return Ok(());
    }
    storage
        .prepare_file(path, length, storage.io_config().preallocation_mode)
        .await?;
    lock_prepared_files(prepared_files).insert(file_index);
    Ok(())
}

async fn write_transfer_block(
    context: &TransferIoContext,
    event: LeasedBlockEvent,
) -> anyhow::Result<()> {
    let LeasedBlockEvent {
        block,
        _memory_lease,
        ..
    } = event;
    let block_len = u32::try_from(block.data.len())
        .map_err(|_| anyhow::anyhow!("peer block length does not fit in u32"))?;
    context.piece_map.validate_request_block(BlockExtent::new(
        block.piece,
        block.offset,
        block_len,
    ))?;
    let regions = context
        .piece_map
        .request_regions(block.piece, block.offset, block_len)?;
    let mut data_offset = 0usize;

    for region in regions {
        let region_len = usize::try_from(region.length)
            .map_err(|_| anyhow::anyhow!("piece region length does not fit in memory"))?;
        let start = data_offset;
        let end = start
            .checked_add(region_len)
            .ok_or_else(|| anyhow::anyhow!("piece region data offset overflow"))?;
        let region_data = block
            .data
            .get(start..end)
            .ok_or_else(|| anyhow::anyhow!("peer block does not cover mapped piece regions"))?;
        if region.pad {
            if region_data.iter().any(|byte| *byte != 0) {
                anyhow::bail!("peer block contains non-zero bytes for BEP 47 padding");
            }
            data_offset = end;
            continue;
        }
        let path = region.path.resolve(&context.save_root);
        prepare_transfer_file_once(context, region.file_index, &path, region.file_length).await?;
        data_offset = end;
        match _memory_lease.as_ref() {
            Some(lease) => {
                scheduled_write_with_shared_payload_lease(
                    &context.storage,
                    IoClass::PeerWrite,
                    &path,
                    region.file_offset,
                    block.data.slice(start..end),
                    true,
                    Arc::clone(lease),
                )
                .await?;
            }
            None => {
                context.resources.record_payload_copy(
                    PayloadCopyPath::PeerFileSegment,
                    region_data.len() as u64,
                );
                scheduled_write(
                    &context.storage,
                    IoClass::PeerWrite,
                    &path,
                    region.file_offset,
                    bytes::Bytes::copy_from_slice(region_data),
                    true,
                )
                .await?;
            }
        }
    }

    if data_offset != block.data.len() {
        anyhow::bail!("mapped piece regions do not cover the peer block");
    }
    Ok(())
}

async fn write_transfer_piece(
    context: &TransferIoContext,
    piece: u32,
    data: bytes::Bytes,
    payload_lease: Option<Arc<MemoryLease>>,
) -> anyhow::Result<()> {
    let regions = context.piece_map.piece_to_file_regions(piece)?;
    for region in regions {
        if region.pad {
            continue;
        }
        let file = context
            .meta
            .files
            .iter()
            .find(|file| file.index == region.file_index)
            .ok_or_else(|| anyhow::anyhow!("file index {} out of range", region.file_index))?;
        let path = file.path.resolve(&context.save_root);
        prepare_transfer_file_once(context, file.index, &path, file.length).await?;
        let start = usize::try_from(region.piece_offset)
            .map_err(|_| anyhow::anyhow!("piece region offset does not fit memory"))?;
        let region_len = usize::try_from(region.length)
            .map_err(|_| anyhow::anyhow!("piece region length does not fit memory"))?;
        let end = start
            .checked_add(region_len)
            .ok_or_else(|| anyhow::anyhow!("piece region data offset overflow"))?;
        anyhow::ensure!(
            data.get(start..end).is_some(),
            "piece assembly does not cover mapped region"
        );
        let region_data = data.slice(start..end);
        match payload_lease.as_ref() {
            Some(lease) => {
                scheduled_write_with_shared_payload_lease(
                    &context.storage,
                    IoClass::PeerWrite,
                    &path,
                    region.file_offset,
                    region_data,
                    true,
                    Arc::clone(lease),
                )
                .await?;
            }
            None => {
                scheduled_write(
                    &context.storage,
                    IoClass::PeerWrite,
                    &path,
                    region.file_offset,
                    region_data,
                    true,
                )
                .await?;
            }
        }
    }
    Ok(())
}

async fn verify_transfer_piece(
    context: TransferIoContext,
    hybrid_v2: Option<Arc<HybridV2Meta>>,
    piece: u32,
    assembled: Option<(bytes::Bytes, Option<Arc<MemoryLease>>)>,
) -> VerifyResult {
    if let Some((data, payload_lease)) = assembled {
        let Some(expected) = context.meta.pieces.get(piece as usize) else {
            return VerifyResult::Missing {
                file_index: 0,
                reason: format!("no hash for piece {piece}"),
            };
        };
        if let Some(hybrid_v2) = hybrid_v2.as_ref() {
            let Some(expectation) = hybrid_v2.piece_expectation(piece) else {
                return VerifyResult::Missing {
                    file_index: 0,
                    reason: format!("no authenticated v2 file range for hybrid piece {piece}"),
                };
            };
            let Ok(piece_length) = usize::try_from(context.meta.piece_length) else {
                return VerifyResult::Missing {
                    file_index: expectation.file_index,
                    reason: "hybrid piece length does not fit memory address space".to_owned(),
                };
            };
            let Ok(v2_content_len) = usize::try_from(expectation.content_len) else {
                return VerifyResult::Missing {
                    file_index: expectation.file_index,
                    reason: "hybrid content length does not fit memory address space".to_owned(),
                };
            };
            let hashes = match payload_lease.as_ref() {
                Some(lease) => {
                    context
                        .storage
                        .hash_hybrid_piece_retry_queue_full_with_shared_payload_lease(
                            data,
                            v2_content_len,
                            piece_length,
                            Arc::clone(lease),
                        )
                        .await
                }
                None => {
                    context
                        .storage
                        .hash_hybrid_piece_retry_queue_full(data, v2_content_len, piece_length)
                        .await
                }
            };
            return match hashes {
                Ok(hashes) if hashes.v1_sha1 == *expected => {
                    let actual_v2 = match expectation.piece_leaf_count {
                        Some(_) => hashes.v2_piece_root,
                        None => hashes.v2_file_root,
                    };
                    if actual_v2 == expectation.expected_root {
                        VerifyResult::Valid
                    } else {
                        VerifyResult::Invalid
                    }
                }
                Ok(_) => VerifyResult::Invalid,
                Err(error) => VerifyResult::Missing {
                    file_index: expectation.file_index,
                    reason: error.to_string(),
                },
            };
        }
        let hash = match payload_lease.as_ref() {
            Some(lease) => {
                context
                    .storage
                    .hash_sha1_retry_queue_full_with_shared_payload_lease(data, Arc::clone(lease))
                    .await
            }
            None => context.storage.hash_sha1_retry_queue_full(data).await,
        };
        return match hash {
            Ok(actual) if &actual == expected => VerifyResult::Valid,
            Ok(_) => VerifyResult::Invalid,
            Err(error) => VerifyResult::Missing {
                file_index: 0,
                reason: error.to_string(),
            },
        };
    }

    let verifier = PieceVerifier::new(
        &context.save_root,
        &context.storage,
        &context.piece_map,
        &context.meta.pieces,
    );
    match hybrid_v2.as_ref() {
        Some(meta) => match meta.piece_expectation(piece) {
            Some(expectation) => verifier.verify_hybrid_piece(piece, &expectation).await,
            None => VerifyResult::Missing {
                file_index: 0,
                reason: format!("no authenticated v2 file range for hybrid piece {piece}"),
            },
        },
        None => verifier.verify_piece(piece).await,
    }
}

pub struct TorrentTask {
    info_hash_hex: String,
    meta: Arc<TorrentMetaV1>,
    hybrid_v2: Option<Arc<HybridV2Meta>>,
    /// Exact bencoded `info` bytes used for BEP 9 upload responses. This is
    /// shared by every peer instead of being rebuilt and copied per
    /// connection. The allocation is retained under the metadata budget for
    /// the lifetime of the torrent task.
    metadata: Option<Arc<Vec<u8>>>,
    _metadata_memory_lease: Option<MemoryLease>,
    /// Incremental reservation for a durable file-policy projection whose
    /// paths are larger than the original metainfo paths. The base metadata
    /// lease covers the original runtime graph; this lease tracks replacements
    /// applied by `apply_file_policy_from_db` and is refreshed on every path
    /// change so a database rename cannot bypass the governor.
    _file_policy_memory_lease: Option<MemoryLease>,
    /// Lifetime reservation for the parsed file/tracker graph retained by the
    /// task. This is separate from the exact BEP9 payload lease above because
    /// the latter can be disabled without discarding transfer metadata.
    _torrent_metadata_memory_lease: Option<MemoryLease>,
    /// Reservation for the current tracker tier projection. This is kept as
    /// one or more leases so an update can acquire only its growth before the
    /// old projection is replaced; a failed admission therefore leaves the
    /// previous tracker set and its accounting intact.
    _tracker_state_memory_leases: Vec<MemoryLease>,
    /// Backing storage for the picker and availability counts. The engine
    /// reserves this before constructing a live task so dense piece state
    /// cannot bypass the process-wide memory governor.
    _piece_index_memory_lease: Option<MemoryLease>,
    /// The immutable paths from the metainfo. `meta.files` is the runtime
    /// projection and may carry durable client-side rename overrides; keeping
    /// the wire paths lets a policy reload recover cleanly if the file
    /// projection is absent.
    metainfo_files: Vec<TorrentFileV1>,
    save_root: PathBuf,
    piece_map: Arc<PieceMap>,
    storage: MountScheduler,
    fastresume: FastresumeStore,
    tracker_tiers: Vec<Vec<TrackerState>>,
    active_tracker_tier: usize,
    private_tracker_key: Option<TrackerKey>,
    tracker_event: TrackerEvent,
    stopped_announced: bool,
    listen_port: u16,
    http_timeout: Duration,
    udp_timeout: Duration,
    min_announce_interval: Option<Duration>,
    registry: Arc<RwLock<SessionRegistry>>,
    db: DbExecutor,
    resources: ResourceGovernor,
    network_budget: GlobalNetworkBudget,
    transfer_rate_torrent: TorrentKey,
    cmd_rx: mpsc::Receiver<TorrentCmd>,
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_event_rx: mpsc::Receiver<PeerEvent>,
    peer_disconnect_tx: mpsc::Sender<PeerEvent>,
    peer_disconnect_rx: mpsc::Receiver<PeerEvent>,
    tracker_workers: TrackerWorkers,
    picker: PiecePicker,
    /// Shared owner of live v1/hybrid peer requests, webseed blocks, and
    /// received content. The picker still ranks candidates; this ledger
    /// arbitrates cross-source ownership and response lifetimes.
    transfer_ledger: TransferLedger<Arc<PieceMap>>,
    /// A transient ledger connection for one webseed request. It may overlap
    /// peer transfers; the shared ledger arbitrates ownership and responses.
    webseed_transfer_conn: Option<ConnectionId>,
    _webseed_transfer_connection_memory_lease: Option<MemoryLease>,
    /// One bounded webseed fetch runs outside the torrent actor so a slow
    /// HTTP response cannot delay peer events or lifecycle commands.
    webseed_fetch: Option<WebseedFetchInFlight>,
    /// Wake source scheduling after policy, recheck, or resume changes.
    webseed_wake_notify: Notify,
    /// Logical ledger-state reservations are charged with peer request state,
    /// separately from the picker's candidate index and payload assemblies.
    transfer_piece_memory_leases: HashMap<u32, MemoryLease>,
    transfer_started_at: Instant,
    choker: Choker,
    /// active peer addresses
    active_peers: HashMap<SocketAddr, PeerHandle>,
    /// Peers whose next request is parked on rate admission. Keeping this
    /// sparse set lets requestability changes retry only affected peers.
    rate_waiting_peers: HashSet<SocketAddr>,
    shutting_down_peers: bool,
    known_tracker_peers: HashSet<SocketAddr>,
    /// The cache is pre-sized and its reservation covers the hash table's
    /// bounded capacity for the task lifetime. This prevents tracker, DHT,
    /// PEX, and manual peer churn from growing an ungoverned address cache.
    _tracker_peer_cache_memory_lease: Option<MemoryLease>,
    last_peerless_reannounce: Option<Instant>,
    egress_policy: OutboundEgressPolicy,
    webseed_next_index: usize,
    webseed_failures: Vec<u8>,
    webseed_next_attempt: Vec<Option<Instant>>,
    webseed_last_rates: Vec<i64>,
    webseed_last_success: Vec<Option<Instant>>,
    last_progress_persist: Option<Instant>,
    transfer_stats_dirty: bool,
    piece_assemblies: HashMap<u32, PieceAssembly>,
    /// Partial pieces restored from fastresume already have their received
    /// bytes on disk, but their contents are not hydrated into an in-memory
    /// assembly. Keep those pieces on the direct-write path until they either
    /// verify or are rejected; otherwise a new block would be combined with
    /// zero-filled bytes and the completed piece would fail verification.
    restored_partial_pieces: HashSet<u32>,
    piece_assembly_bytes: usize,
    piece_assembly_soft_cap_bytes: usize,
    piece_assembly_evictions: u64,
    peer_request_window_reductions: u64,
    peer_command_queue_full: u64,
    peer_request_memory_retry_pending: bool,
    tracker_peer_cache_drops: u64,
    dirty_pieces_since_barrier: DirtyPieceTracker,
    /// Shared crash-safety settings, run verdict and counters. Defaults to an
    /// inert instance until the engine attaches the real one.
    crash_safety: Arc<CrashSafetyRuntime>,
    completion_gate: Option<CompletionGate>,
    /// A read-back verification queued by the completion gate, started by
    /// [`TorrentTask::drive_crash_safety`] where the command receiver is
    /// available.
    completion_verify_plan: Option<VerifyPlan>,
    /// The recheck now running (or about to run) is a completion verification.
    /// While set, the torrent keeps reporting one byte remaining.
    completion_verifying: bool,
    /// Pieces the next recheck should verify instead of the whole torrent.
    recheck_subset: Option<Vec<u32>>,
    /// A failed `sample` verification proved storage returned bad data; follow
    /// it with a full recheck.
    escalate_full_recheck: bool,
    /// The save path's filesystem cannot fsync; stop retrying.
    fsync_unsupported: bool,
    /// Why the startup recheck was forced by crash recovery, for event labels.
    recovery_recheck_reason: Option<RecheckReason>,
    /// Unix seconds of the last payload write. Persisted into fastresume to
    /// date recent writes for the post-host-crash recheck window.
    last_data_write_unix: std::sync::atomic::AtomicU64,
    super_seeding: bool,
    seed_ratio_limit: Option<f64>,
    seed_idle_limit: Option<Duration>,
    seeding_started_at: Option<Instant>,
    last_upload_at: Instant,
    /// Earliest scheduler deadline for a block request that could not yet be
    /// admitted. Nothing else restarts a peer whose request window drained.
    download_rate_wake: Option<Instant>,
    torrent_download_limit_bytes_per_sec: Option<u64>,
    torrent_upload_limit_bytes_per_sec: Option<u64>,
    completed_piece_verify_from_memory: u64,
    completed_piece_verify_from_disk: u64,
    prepared_files: Arc<Mutex<HashSet<u32>>>,
    prepared_file_locks: Arc<tokio::sync::Mutex<HashMap<u32, Arc<tokio::sync::Mutex<()>>>>>,
    transfer_jobs: futures::stream::FuturesUnordered<TransferJobFuture>,
    pending_transfer_blocks: HashMap<(u32, u32), u64>,
    pending_transfer_pieces: HashMap<u32, PendingPieceWork>,
    next_transfer_generation: u64,
    paused: bool,
    /// The lifecycle state to restore when a recheck was requested for a
    /// dormant/paused task. Dormant tasks are constructed with `paused = true`
    /// even when their durable state was active, so the runtime boolean alone
    /// cannot distinguish "paused by the user" from "temporarily quiesced
    /// until the recheck command arrives".
    recheck_restore_state: Option<TorrentState>,
    /// Durable state captured when a dormant task is promoted. Most dormant
    /// tasks stage through `Paused`, but an `Error` task must remain `Error`
    /// until an explicit resume/recheck command can move it to `Checking`.
    initial_state: TorrentState,
    max_peers: usize,
    torrent_max_peers: Option<usize>,
    pex_enabled: bool,
    event_retention: usize,
}

impl Drop for TorrentTask {
    fn drop(&mut self) {
        // The engine may have to abort this actor after a full mailbox or a
        // stuck storage/tracker operation. Dropping a Tokio JoinHandle detaches
        // its task, so explicitly abort every peer here as the final lifecycle
        // fallback. Otherwise handshakes
        // can keep sockets alive after the torrent actor has disappeared.
        for peer in self.active_peers.values() {
            peer.upload_control.cancel();
            peer.shutdown_control.cancel();
            if let Some(peer_task) = &peer.peer_task {
                peer_task.abort();
            }
        }
        self.network_budget
            .remove_transfer_torrent(self.transfer_rate_torrent);
    }
}

impl TorrentTask {
    pub(crate) fn attach_torrent_metadata_memory_lease(&mut self, lease: MemoryLease) {
        self._torrent_metadata_memory_lease = Some(lease);
    }

    pub(crate) fn attach_hybrid_v2_metadata(&mut self, meta: TorrentMetaV2) {
        let projection =
            HybridV2Meta::from_validated_views(&self.meta, Arc::clone(&self.piece_map), meta);
        if projection.valid_layout {
            if let Some(geometry) = projection.geometry.clone() {
                if !self.transfer_ledger.attach_hybrid_geometry(geometry) {
                    warn!(
                        component = "transfer",
                        operation = "attach_hybrid_ledger",
                        torrent = %self.info_hash_hex,
                        result = "skipped",
                        "hybrid metadata arrived after the live ledger had already been used"
                    );
                }
            }
        }
        if !projection.valid_layout {
            warn!(
                component = "torrent",
                operation = "hybrid_metadata_projection",
                torrent = %self.info_hash_hex,
                result = "invalid",
                "hybrid v2 metadata did not match the validated v1 file layout"
            );
        }
        self.hybrid_v2 = Some(Arc::new(projection));
    }

    /// Share the engine's crash-safety runtime with this task.
    pub(crate) fn attach_crash_safety(&mut self, runtime: Arc<CrashSafetyRuntime>) {
        self.crash_safety = runtime;
    }

    fn reserve_file_policy_memory(
        &self,
        effective_files: &[TorrentFileV1],
    ) -> Result<Option<MemoryLease>, String> {
        let baseline = persistent_file_graph_memory_bytes(&self.metainfo_files);
        let required = persistent_file_graph_memory_bytes(effective_files).saturating_sub(baseline);
        if required == 0 {
            return Ok(None);
        }
        let bytes = u64::try_from(required)
            .map_err(|_| "file-policy memory estimate does not fit in u64".to_owned())?;
        self.resources
            .try_acquire(MemoryClass::Metadata, bytes)
            .map(Some)
            .ok_or_else(|| {
                format!(
                    "file-policy allocation of {bytes} bytes denied for {} files",
                    effective_files.len()
                )
            })
    }

    fn reserve_file_policy_workspace_memory(&self) -> Result<Option<MemoryLease>, String> {
        let bytes = persistent_file_graph_memory_bytes(&self.metainfo_files);
        if bytes == 0 {
            return Ok(None);
        }
        let bytes = u64::try_from(bytes)
            .map_err(|_| "file-policy workspace memory estimate does not fit in u64".to_owned())?;
        self.resources
            .try_acquire(MemoryClass::Metadata, bytes)
            .map(Some)
            .ok_or_else(|| format!("file-policy workspace allocation of {bytes} bytes denied"))
    }

    fn refresh_tracker_state_memory(
        &mut self,
        tracker_tiers: &[Vec<TrackerState>],
        outer_capacity: usize,
    ) -> Result<(), String> {
        let required = u64::try_from(tracker_state_memory_bytes(tracker_tiers, outer_capacity))
            .map_err(|_| "tracker state memory estimate does not fit in u64".to_owned())?;
        let held = self
            ._tracker_state_memory_leases
            .iter()
            .map(MemoryLease::bytes)
            .fold(0u64, u64::saturating_add);

        if required > held {
            let extra = required - held;
            let lease = self
                .resources
                .try_acquire(MemoryClass::Metadata, extra)
                .ok_or_else(|| format!("tracker state allocation of {extra} bytes denied"))?;
            self._tracker_state_memory_leases.push(lease);
        } else if required == 0 {
            self._tracker_state_memory_leases.clear();
        } else if required < held {
            // Acquire before releasing the old reservation. If the temporary
            // double reservation does not fit, retaining the larger old lease
            // is safe and avoids an uncharged replacement window.
            if let Some(lease) = self.resources.try_acquire(MemoryClass::Metadata, required) {
                let old = std::mem::replace(&mut self._tracker_state_memory_leases, vec![lease]);
                drop(old);
            }
        }
        Ok(())
    }

    // This constructor is the current dependency-injection seam for a
    // torrent actor. It is intentionally explicit while the actor context is
    // being split into storage/network/persistence components.
    #[allow(clippy::too_many_arguments)]
    pub(crate) async fn new(
        mut meta: TorrentMetaV1,
        save_root: PathBuf,
        paused: bool,
        initial_state: TorrentState,
        registry: Arc<RwLock<SessionRegistry>>,
        db: DbExecutor,
        resources: ResourceGovernor,
        cmd_rx: mpsc::Receiver<TorrentCmd>,
        fastresume_dir: PathBuf,
        max_peers: usize,
        listen_port: u16,
        http_timeout_secs: u64,
        udp_timeout_secs: u64,
        min_interval_secs: u64,
        piece_assembly_cap_bytes: usize,
        storage_io: StorageIoConfig,
        pex_enabled: bool,
        egress_policy: OutboundEgressPolicy,
        network_budget: GlobalNetworkBudget,
        event_retention: usize,
        piece_index_memory_lease: Option<MemoryLease>,
    ) -> Self {
        // Peer events are bounded per active torrent. Derive the capacity from
        // the daemon-wide peer ceiling so a deployment that deliberately runs
        // with a small peer budget does not retain 512 message slots per hot
        // torrent, while still keeping enough burst room for a normal
        // handshake/block event sequence. The upper bound prevents an
        // accidentally huge max_peers setting from multiplying memory.
        let peer_event_capacity = peer_event_channel_capacity(max_peers);
        let transfer_rate_torrent = network_budget.new_transfer_torrent_key();
        let (peer_event_tx, peer_event_rx) = mpsc::channel(peer_event_capacity);
        let (peer_disconnect_tx, peer_disconnect_rx) = mpsc::channel(peer_event_capacity);
        let total = meta.total_length();
        let last_piece_len = if total.is_multiple_of(meta.piece_length) {
            meta.piece_length
        } else {
            total % meta.piece_length
        };
        let piece_count = meta.pieces.len();
        let webseed_failures = vec![0; meta.webseeds.len()];
        let webseed_next_attempt = vec![None; meta.webseeds.len()];
        let webseed_last_rates = vec![0; meta.webseeds.len()];
        let webseed_last_success = vec![None; meta.webseeds.len()];
        let picker = PiecePicker::new(piece_count, meta.piece_length as u32, last_piece_len as u32);
        let info_hash_hex: String = meta.info_hash.iter().map(|b| format!("{b:02x}")).collect();
        let metainfo_files = meta.files.clone();
        // The task only needs the exact info dictionary for BEP 9 uploads;
        // retaining the complete parsed .torrent blob here would keep up to
        // MAX_TORRENT_BYTES alive for every promoted torrent. Extract the
        // leased upload payload, then release the parser-owned raw blob.
        let raw = std::mem::take(&mut meta.raw);
        let (metadata, metadata_memory_lease) =
            prepare_metadata_payload(&resources, &info_hash_hex, &raw);
        drop(raw);
        let (known_tracker_peers, tracker_peer_cache_memory_lease) =
            prepare_tracker_peer_cache(&resources, max_peers);
        if tracker_peer_cache_memory_lease.is_none() {
            warn!(
                component = "memory",
                operation = "reserve_tracker_peer_cache",
                torrent = %info_hash_hex,
                result = "disabled",
                "tracker peer cache disabled because its memory budget or allocator reserve was unavailable"
            );
        }
        let piece_map = build_piece_map(meta.piece_length, &meta.files)
            .expect("metainfo parser rejects invalid piece maps");
        // The serial webseed fallback owns one transient ledger connection in
        // addition to the configured peer slots. Dispatch starts while idle,
        // though a new peer may overlap a fetch already in progress.
        let transfer_ledger =
            TransferLedger::new_bounded(Arc::clone(&piece_map), max_peers.saturating_add(1));
        let storage = MountScheduler::new_for_path(
            StorageRootId::new(),
            &save_root,
            &SchedulerConfig {
                profile: StorageProfile::Unknown,
                resources: Some(resources.clone()),
                storage_io,
                ..Default::default()
            },
        );
        let metainfo_trackers = meta.all_trackers();
        let mut tracker_tiers = tracker_tiers_from_meta(&meta);
        let tracker_restore = db
            .run("restore_tracker_state", {
                let info_hash = info_hash_hex.clone();
                move |db| {
                    let (count, bytes) = rt_db::torrent_tracker_snapshot_size(db, &info_hash)
                        .map_err(|error| error.to_string())?;
                    crate::engine::validate_tracker_snapshot_size(count, bytes)?;
                    let rows = rt_db::list_torrent_trackers(db, &info_hash)
                        .map_err(|error| error.to_string())?;
                    let persisted_trackers = rt_db::torrent_tracker_override(db, &info_hash)
                        .map_err(|error| error.to_string())?;
                    Ok((rows, persisted_trackers))
                }
            })
            .await;
        match tracker_restore {
            Ok((rows, persisted_trackers)) => {
                // `torrents.trackers` is the durable client override. Keep
                // the metainfo's BEP-12 tiers for untouched torrents, but
                // treat a changed value (including an explicit empty list)
                // as authoritative after an actor restart.
                if persisted_trackers
                    .as_ref()
                    .is_some_and(|trackers| trackers.as_slice() != metainfo_trackers.as_slice())
                {
                    tracker_tiers =
                        tracker_tiers_from_urls(persisted_trackers.as_deref().unwrap_or_default());
                }
                restore_tracker_state_from_rows(&mut tracker_tiers, &rows);
            }
            Err(error) => {
                warn!(
                    component = "db",
                    operation = "restore_tracker_state",
                    torrent = %info_hash_hex,
                    result = "error",
                    error = %error,
                    "failed to restore durable tracker state; using fresh tracker session"
                );
            }
        }
        let tracker_state_memory_leases = match reserve_tracker_state_memory(
            &resources,
            &tracker_tiers,
            tracker_tiers.capacity(),
        ) {
            Ok(leases) => leases,
            Err(error) => {
                warn!(
                    component = "memory",
                    operation = "reserve_tracker_state",
                    torrent = %info_hash_hex,
                    result = "disabled",
                    error = %error,
                    "tracker state disabled because its memory budget or allocator reserve was unavailable"
                );
                // Assign a fresh empty vector rather than clearing the
                // current one: Vec::clear retains its outer allocation.
                tracker_tiers = Vec::new();
                Vec::new()
            }
        };
        let private_tracker_key = if meta.private {
            first_tracker_key(&tracker_tiers)
        } else {
            None
        };
        let mut task = TorrentTask {
            info_hash_hex,
            meta: Arc::new(meta),
            hybrid_v2: None,
            metadata,
            _metadata_memory_lease: metadata_memory_lease,
            _file_policy_memory_lease: None,
            _torrent_metadata_memory_lease: None,
            _tracker_state_memory_leases: tracker_state_memory_leases,
            _piece_index_memory_lease: piece_index_memory_lease,
            metainfo_files,
            save_root,
            piece_map,
            storage,
            fastresume: FastresumeStore::new(fastresume_dir),
            tracker_tiers,
            active_tracker_tier: 0,
            private_tracker_key,
            tracker_event: TrackerEvent::Started,
            stopped_announced: paused,
            listen_port,
            http_timeout: Duration::from_secs(http_timeout_secs.max(1)),
            udp_timeout: Duration::from_secs(udp_timeout_secs.max(1)),
            min_announce_interval: (min_interval_secs > 0)
                .then(|| Duration::from_secs(min_interval_secs)),
            registry,
            db,
            resources,
            network_budget,
            transfer_rate_torrent,
            cmd_rx,
            peer_event_tx,
            peer_event_rx,
            peer_disconnect_tx,
            peer_disconnect_rx,
            tracker_workers: TrackerWorkers::new(),
            picker,
            transfer_ledger,
            webseed_transfer_conn: None,
            _webseed_transfer_connection_memory_lease: None,
            webseed_fetch: None,
            webseed_wake_notify: Notify::new(),
            transfer_piece_memory_leases: HashMap::new(),
            transfer_started_at: Instant::now(),
            choker: Choker::new(DEFAULT_MAX_UNCHOKED),
            active_peers: HashMap::new(),
            rate_waiting_peers: HashSet::new(),
            shutting_down_peers: false,
            known_tracker_peers,
            _tracker_peer_cache_memory_lease: tracker_peer_cache_memory_lease,
            last_peerless_reannounce: None,
            egress_policy,
            webseed_next_index: 0,
            webseed_failures,
            webseed_next_attempt,
            webseed_last_rates,
            webseed_last_success,
            last_progress_persist: None,
            transfer_stats_dirty: false,
            piece_assemblies: HashMap::new(),
            restored_partial_pieces: HashSet::new(),
            piece_assembly_bytes: 0,
            piece_assembly_soft_cap_bytes: effective_piece_assembly_soft_cap(
                piece_assembly_cap_bytes,
            ),
            piece_assembly_evictions: 0,
            peer_request_window_reductions: 0,
            peer_command_queue_full: 0,
            peer_request_memory_retry_pending: false,
            tracker_peer_cache_drops: 0,
            dirty_pieces_since_barrier: DirtyPieceTracker::default(),
            crash_safety: CrashSafetyRuntime::inert(),
            completion_gate: None,
            completion_verify_plan: None,
            completion_verifying: false,
            recheck_subset: None,
            escalate_full_recheck: false,
            fsync_unsupported: false,
            recovery_recheck_reason: None,
            last_data_write_unix: std::sync::atomic::AtomicU64::new(0),
            super_seeding: false,
            seed_ratio_limit: None,
            seed_idle_limit: None,
            seeding_started_at: None,
            last_upload_at: Instant::now(),
            download_rate_wake: None,
            torrent_download_limit_bytes_per_sec: None,
            torrent_upload_limit_bytes_per_sec: None,
            completed_piece_verify_from_memory: 0,
            completed_piece_verify_from_disk: 0,
            prepared_files: Arc::new(Mutex::new(HashSet::new())),
            prepared_file_locks: Arc::new(tokio::sync::Mutex::new(HashMap::new())),
            transfer_jobs: futures::stream::FuturesUnordered::new(),
            pending_transfer_blocks: HashMap::new(),
            pending_transfer_pieces: HashMap::new(),
            next_transfer_generation: 0,
            paused,
            recheck_restore_state: match initial_state {
                TorrentState::Paused => Some(TorrentState::Paused),
                TorrentState::Stopped => Some(TorrentState::Stopped),
                _ => None,
            },
            initial_state,
            max_peers,
            torrent_max_peers: None,
            pex_enabled,
            event_retention,
        };
        match task.apply_torrent_limits_from_db().await {
            Ok(()) => {}
            Err(error) => {
                // Starting with an unbounded picker after a persisted-policy
                // read failed is unsafe: a damaged or unavailable database
                // must not silently widen the set of pieces we may write.
                task.fail_closed_runtime_policy("restore_runtime_policy", &error);
            }
        }
        task.network_budget.register_upload_torrent(
            task.transfer_rate_torrent,
            task.torrent_upload_limit_bytes_per_sec,
        );
        task.network_budget.register_download_torrent(
            task.transfer_rate_torrent,
            task.torrent_download_limit_bytes_per_sec,
        );
        task
    }

    pub async fn run(mut self) {
        // Keep the command receiver outside the actor loop so it has one clear
        // owner while the cancellable webseed worker runs independently. The
        // replacement is never observed: this task owns the real receiver
        // until it exits.
        let (_, replacement_cmd_rx) = mpsc::channel(1);
        let mut cmd_rx = std::mem::replace(&mut self.cmd_rx, replacement_cmd_rx);
        let mut pending_command = None;
        let restored = self.restore_fastresume().await;
        self.persist_tracker_state().await;
        if self.paused {
            self.persist_progress().await;
            // Dormant promotion constructs the task paused so no transfer
            // starts before the queued command is delivered. Preserve an
            // explicitly stopped projection during that staging window;
            // rewriting it as Paused makes a stopped torrent resume with the
            // wrong lifecycle state if the process exits before the command.
            let startup_state = match self.initial_state {
                TorrentState::Error => TorrentState::Error,
                // Promotion stages every dormant task paused. Preserve a
                // queued lifecycle projection during that staging window;
                // otherwise a process exit before the queued command arrives
                // silently turns queue admission into a user pause.
                TorrentState::Queued => TorrentState::Queued,
                _ => self.recheck_restore_state.unwrap_or(TorrentState::Paused),
            };
            if let Err(error) = self.set_state_checked(startup_state).await {
                warn!(
                    component = "torrent",
                    operation = "startup_state",
                    torrent = %self.info_hash_hex,
                    result = "error",
                    error = %error,
                    "failed to persist paused startup state; stopping task"
                );
                reject_pending_torrent_commands(&mut cmd_rx, &mut pending_command);
                return;
            }
        } else if self.initial_state == TorrentState::Checking || !restored {
            // `Checking` is a durable promise that the previous process had
            // not completed verification. A fastresume file may still exist
            // from before that scan, so it must never be allowed to turn the
            // task directly into Downloading/Seeding on restore. The engine
            // also recovers a queued recheck job after tasks are loaded; the
            // scan below can adopt that job id when its command arrives.
            match self
                .run_recheck_with_receiver(&mut cmd_rx, &mut pending_command, None)
                .await
            {
                RecheckOutcome::Shutdown => {
                    reject_pending_torrent_commands(&mut cmd_rx, &mut pending_command);
                    return;
                }
                RecheckOutcome::Failed(error) => {
                    warn!(
                        component = "torrent",
                        operation = "startup_recheck",
                        torrent = %self.info_hash_hex,
                        result = "error",
                        error = %error,
                        "startup recheck failed; stopping task"
                    );
                    reject_pending_torrent_commands(&mut cmd_rx, &mut pending_command);
                    return;
                }
                RecheckOutcome::Complete
                | RecheckOutcome::Paused { .. }
                | RecheckOutcome::Cancelled => {}
            }
        } else if self.picker.is_complete() {
            if let Err(error) = self.set_state_checked(TorrentState::Seeding).await {
                warn!(
                    component = "torrent",
                    operation = "startup_state",
                    torrent = %self.info_hash_hex,
                    result = "error",
                    error = %error,
                    "failed to persist seeding startup state; stopping task"
                );
                reject_pending_torrent_commands(&mut cmd_rx, &mut pending_command);
                return;
            }
        } else if let Err(error) = self.set_state_checked(TorrentState::Downloading).await {
            warn!(
                component = "torrent",
                operation = "startup_state",
                torrent = %self.info_hash_hex,
                result = "error",
                error = %error,
                "failed to persist downloading startup state; stopping task"
            );
            reject_pending_torrent_commands(&mut cmd_rx, &mut pending_command);
            return;
        }

        let mut choke_tick = interval(Duration::from_secs(10));
        let mut tracker_tick = interval(Duration::from_secs(5));
        let mut peer_retry_tick = interval(Duration::from_secs(30));
        let mut peer_control_retry_tick = interval(Duration::from_secs(1));
        // A torrent admits at most one webseed block at a time, alongside
        // peer work. Sleep until fresh work is requestable; after a source
        // failure, follow that seed's exponential retry deadline.
        let mut webseed_sleep = Box::pin(sleep(WEBSEED_RETRY_MAX));
        reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
        let global_download_limit_changes = self.network_budget.download_limit_changes();
        let mut global_download_limit_generation = global_download_limit_changes.generation();
        let download_demand_changes = self
            .network_budget
            .download_demand_changes(self.transfer_rate_torrent);
        let mut download_demand_generation = download_demand_changes.generation();

        loop {
            tokio::select! {
                command = receive_torrent_command(&mut cmd_rx, &mut pending_command) => {
                    let Some(cmd) = command else {
                        // The owning engine is gone. Persist the last safe
                        // state and close peer tasks instead of leaving a
                        // detached torrent actor running on timers forever.
                        warn!(
                            component = "torrent",
                            operation = "run",
                            torrent = %self.info_hash_hex,
                            result = "command_channel_closed",
                            "torrent command channel closed; shutting down"
                        );
                        self.close_webseed_transfer_connection();
                        self.cancel_tracker_announces();
                        self.announce_stopped_with_control_deadline().await;
                        self.drain_transfer_jobs().await;
                        self.persist_progress().await;
                        self.save_fastresume_for_exit().await;
                        self.shutdown_peers().await;
                        break;
                    };
                    match cmd {
                        TorrentCmd::Shutdown => {
                            self.close_webseed_transfer_connection();
                            self.cancel_tracker_announces();
                            self.announce_stopped_with_control_deadline().await;
                            self.drain_transfer_jobs().await;
                            self.persist_progress().await;
                            self.save_fastresume_for_exit().await;
                            self.shutdown_peers().await;
                            break;
                        }
                        TorrentCmd::Pause { reply } => {
                            let was_paused = self.paused;
                            self.paused = true;
                            self.close_webseed_transfer_connection();
                            self.cancel_tracker_announces();
                            self.drain_transfer_jobs().await;
                            self.save_fastresume(false).await;
                            self.shutdown_peers().await;
                            let result = self.set_state_checked(TorrentState::Paused).await;
                            if let Err(error) = &result {
                                // A failed state write must not turn a
                                // rejected pause into a runtime-only pause.
                                // Restore the prior control state and let the
                                // caller retry once the durable store is
                                // available again.
                                self.paused = was_paused;
                                if !was_paused {
                                    self.restart_tracker_session();
                                }
                                warn!(
                                    component = "torrent",
                                    operation = "pause",
                                    torrent = %self.info_hash_hex,
                                    result = "error",
                                    error = %error,
                                    "failed to persist torrent pause"
                                );
                            } else {
                                self.recheck_restore_state = Some(TorrentState::Paused);
                                self.tracker_event = TrackerEvent::Started;
                            }
                            if let Some(reply) = reply {
                                let _ = reply.send(result);
                            }
                            if self.paused {
                                // Tracker shutdown is best-effort lifecycle
                                // housekeeping. Do it after the durable pause
                                // acknowledgement so a slow tracker cannot
                                // make the caller time out with a task that is
                                // already safely paused.
                                await_stopped_announce_or_queue_command(
                                    &mut self,
                                    &mut cmd_rx,
                                    &mut pending_command,
                                )
                                .await;
                            }
                        }
                        TorrentCmd::Resume { reply } => {
                            let result = self.prepare_resume().await;
                            if let Some(reply) = reply {
                                // Do not make API callers wait for a full
                                // disk recheck. `Checking` is the durable
                                // acknowledgement; the recheck continues in
                                // this actor immediately afterward.
                                let _ = reply.send(result.clone());
                            }
                            if result.is_ok() {
                                match self
                                    .run_recheck_with_receiver(
                                        &mut cmd_rx,
                                        &mut pending_command,
                                        None,
                                    )
                                    .await
                                {
                                    RecheckOutcome::Shutdown => break,
                                    RecheckOutcome::Failed(error) => {
                                        warn!(
                                            component = "torrent",
                                            operation = "resume_recheck",
                                            torrent = %self.info_hash_hex,
                                            result = "error",
                                            error = %error,
                                            "resume recheck failed; stopping task"
                                        );
                                        break;
                                    }
                                    RecheckOutcome::Complete
                                    | RecheckOutcome::Paused { .. }
                                    | RecheckOutcome::Cancelled => {}
                                }
                            }
                            // A recheck can invalidate pieces after the
                            // webseed timer has backed off because the picker
                            // was complete. Wake the scheduler immediately so
                            // repair does not wait for the long retry deadline.
                            reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                        }
                        TorrentCmd::QuiesceForStorageMove { reply } => {
                            let was_paused = self.paused;
                            self.paused = true;
                            self.close_webseed_transfer_connection();
                            self.cancel_tracker_announces();
                            self.drain_transfer_jobs().await;
                            self.save_fastresume(false).await;
                            self.shutdown_peers().await;
                            if let Err(error) = self.set_state_checked(TorrentState::Paused).await {
                                self.paused = was_paused;
                                if !was_paused {
                                    self.restart_tracker_session();
                                }
                                let _ = reply.send(Err(format!(
                                    "failed to persist torrent quiesce state: {error}"
                                )));
                                continue;
                            }
                            self.tracker_event = TrackerEvent::Started;
                            // `shutdown_peers` above terminates every peer
                            // task, so no *new* PeerEvent can arrive after
                            // it returns -- but an event already buffered
                            // in the channel a moment before disconnect
                            // could still be sitting there. Drop anything
                            // left so a leftover Block event can't reach
                            // `handle_block` (and write to disk) after we
                            // hand back this reply.
                            while self.peer_event_rx.try_recv().is_ok() {}
                            let _ = reply.send(Ok(was_paused));
                            await_stopped_announce_or_queue_command(
                                &mut self,
                                &mut cmd_rx,
                                &mut pending_command,
                            )
                            .await;
                        }
                        TorrentCmd::ResumeAfterStorageMove {
                            new_save_root,
                            resume_paused,
                            reply,
                        } => {
                            if let Some(new_root) = new_save_root {
                                self.save_root = new_root.clone();
                                self.storage = MountScheduler::new_for_path(
                                    StorageRootId::new(),
                                    &new_root,
                                    &SchedulerConfig {
                                        profile: StorageProfile::Unknown,
                                        resources: Some(self.resources.clone()),
                                        storage_io: self.storage.io_config().clone(),
                                        ..Default::default()
                                    },
                                );
                                // Any file-prepared bookkeeping refers to
                                // handles/allocations at the old path; the
                                // files now live at a verified-identical
                                // new path, so start clean rather than
                                // trust stale state across the move.
                                lock_prepared_files(&self.prepared_files).clear();
                            }
                            if !resume_paused {
                                match self.prepare_resume().await {
                                    Ok(()) => {
                                        // `Checking` is the durable handoff
                                        // point. Do not make storage-job
                                        // completion wait for a full disk
                                        // recheck, but do report failures that
                                        // would otherwise leave the task
                                        // paused after the job was marked
                                        // complete.
                                        let _ = reply.send(Ok(()));
                                        match self
                                            .run_recheck_with_receiver(
                                                &mut cmd_rx,
                                                &mut pending_command,
                                                None,
                                            )
                                            .await
                                        {
                                            RecheckOutcome::Shutdown => break,
                                            RecheckOutcome::Failed(error) => {
                                                warn!(
                                                    component = "torrent",
                                                    operation = "storage_move_resume_recheck",
                                                    torrent = %self.info_hash_hex,
                                                    result = "error",
                                                    error = %error,
                                                    "post-storage-move recheck failed; stopping task"
                                                );
                                                break;
                                            }
                                            RecheckOutcome::Complete
                                            | RecheckOutcome::Paused { .. }
                                            | RecheckOutcome::Cancelled => {}
                                        }
                                    }
                                    Err(error) => {
                                        let _ = reply.send(Err(error.clone()));
                                        warn!(
                                            component = "torrent",
                                            operation = "storage_move_resume",
                                            torrent = %self.info_hash_hex,
                                            result = "error",
                                            error = %error,
                                            "post-storage-move resume could not be persisted"
                                        );
                                    }
                                }
                                reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                            } else {
                                let _ = reply.send(Ok(()));
                            }
                        }
                        TorrentCmd::NewPeers(addrs) => {
                            if !self.paused {
                                if !self.meta.private {
                                    self.remember_tracker_peers(&addrs);
                                }
                                self.connect_peers(addrs, PeerSource::Dht).await;
                            }
                        }
                        TorrentCmd::PriorityPeers(addrs) => {
                            if !self.paused {
                                // Private torrents have no tracker/DHT/PEX
                                // peer source. An explicit peer supplied by a
                                // client is therefore the authority that
                                // admits this address for the connection and
                                // for later reconnects.
                                if self.meta.private {
                                    self.remember_tracker_peers(&addrs);
                                }
                                self.connect_priority_peers(addrs).await;
                            }
                        }
                        TorrentCmd::BanPeer(peer) => {
                            self.evict_peer(peer).await;
                        }
                        TorrentCmd::EvictBannedPeers => {
                            self.evict_banned_peers().await;
                        }
                        TorrentCmd::GetPeers { reply } => {
                            let _ = reply.send(Vec::new());
                        }
                        TorrentCmd::GetPeerSnapshotCount { reply } => {
                            let _ = reply.send(self.active_peers.len());
                        }
                        TorrentCmd::GetPeerSnapshots {
                            max_entries,
                            reply,
                        } => {
                            let _ = reply.send(self.peer_snapshots_limited(max_entries));
                        }
                        TorrentCmd::GetWebseeds { reply } => {
                            let _ = reply.send(self.webseed_snapshots());
                        }
                        TorrentCmd::GetRuntimeStats { reply } => {
                            let _ = reply.send(self.runtime_stats());
                        }
                        TorrentCmd::GetPeerSummary { reply } => {
                            let _ = reply.send(self.peer_stats());
                        }
                        TorrentCmd::AcceptPeer {
                            stream,
                            peer_addr,
                            handshake,
                            peer_permit,
                        } => {
                            if !self.paused {
                                self.accept_peer(stream, peer_addr, handshake, peer_permit)
                                    .await;
                            }
                        }
                        TorrentCmd::AcceptUtpPeer {
                            stream,
                            peer_addr,
                            handshake,
                            peer_permit,
                        } => {
                            if !self.paused {
                                self.accept_utp_peer(*stream, peer_addr, handshake, peer_permit)
                                    .await;
                            }
                        }
                        TorrentCmd::Recheck { job_id } => {
                            match self
                                .run_recheck_with_receiver(
                                    &mut cmd_rx,
                                    &mut pending_command,
                                    job_id,
                                )
                                .await
                            {
                                RecheckOutcome::Shutdown => break,
                                RecheckOutcome::Failed(error) => {
                                    warn!(
                                        component = "torrent",
                                        operation = "recheck",
                                        torrent = %self.info_hash_hex,
                                        result = "error",
                                        error = %error,
                                        "recheck failed; stopping task"
                                    );
                                    break;
                                }
                                RecheckOutcome::Complete
                                | RecheckOutcome::Paused { .. }
                                | RecheckOutcome::Cancelled => {}
                            }
                            // Recheck may transition a complete torrent back
                            // to downloading when corruption is found.
                            reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                        }
                        TorrentCmd::CancelJob { .. } => {}
                        TorrentCmd::Reannounce => {
                            self.tracker_event = TrackerEvent::Empty;
                            self.schedule_active_tracker_tier_now();
                        }
                        TorrentCmd::ReloadFilePolicy { reply } => {
                            let result = self.apply_file_policy_from_db().await;
                            if let Err(error) = &result {
                                warn!(
                                    component = "torrent",
                                    operation = "reload_file_policy",
                                    torrent = %self.info_hash_hex,
                                    result = "error",
                                    error = %error,
                                    "failed to reload persisted file policy; retaining the active policy"
                                );
                            }
                            if let Some(reply) = reply {
                                let _ = reply.send(result);
                            }
                        }
                        TorrentCmd::UpdateLimits { limits, reply } => {
                            let result = self.apply_torrent_limits(&limits).await;
                            if let Err(error) = &result {
                                warn!(
                                    component = "torrent",
                                    operation = "update_limits",
                                    torrent = %self.info_hash_hex,
                                    result = "error",
                                    error = %error,
                                    "failed to apply persisted torrent limits"
                                );
                            }
                            if let Some(reply) = reply {
                                let _ = reply.send(result);
                            }
                        }
                        TorrentCmd::UpdateTrackers { trackers, reply } => {
                            let result = self.apply_tracker_urls(trackers).await;
                            if let Err(error) = &result {
                                warn!(
                                    component = "torrent",
                                    operation = "update_trackers",
                                    torrent = %self.info_hash_hex,
                                    result = "error",
                                    error = %error,
                                    "failed to apply updated tracker URLs"
                                );
                            }
                            if let Some(reply) = reply {
                                let _ = reply.send(result);
                            }
                        }
                        TorrentCmd::UpdatePeerExchange(enabled) => {
                            self.pex_enabled = enabled;
                        }
                    }
                }

                Some(event) = self.peer_event_rx.recv() => {
                    let had_fresh_requestable = self.picker.has_fresh_requestable();
                    let requestability_changed = matches!(
                        &event,
                        PeerEvent::Bitfield { .. }
                            | PeerEvent::Have { .. }
                            | PeerEvent::RequestSent { .. }
                            | PeerEvent::Piece { .. }
                            | PeerEvent::Choked { .. }
                            | PeerEvent::RequestRejected { .. }
                            | PeerEvent::RequestTimedOut { .. }
                            | PeerEvent::Disconnected { .. }
                    );
                    let released_request = matches!(
                        &event,
                        PeerEvent::Choked { .. }
                            | PeerEvent::RequestRejected { .. }
                            | PeerEvent::RequestTimedOut { .. }
                            | PeerEvent::Disconnected { .. }
                    );
                    if let Some(event) = peer_event_if_active(self.paused, event) {
                        self.handle_peer_event(event).await;
                        if requestability_changed {
                            self.retry_rate_waiting_peers().await;
                        }
                        if released_request
                            && !had_fresh_requestable
                            && self.webseed_fetch.is_none()
                            && self.picker.has_fresh_requestable()
                        {
                            reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                        }
                    }
                    if self.crash_safety_work_pending() {
                        if !self.drive_crash_safety(&mut cmd_rx, &mut pending_command).await {
                            break;
                        }
                        reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                    }
                }

                Some(event) = self.peer_disconnect_rx.recv() => {
                    let had_fresh_requestable = self.picker.has_fresh_requestable();
                    let requestability_changed = matches!(
                        &event,
                        PeerEvent::Bitfield { .. }
                            | PeerEvent::Have { .. }
                            | PeerEvent::RequestSent { .. }
                            | PeerEvent::Piece { .. }
                            | PeerEvent::Choked { .. }
                            | PeerEvent::RequestRejected { .. }
                            | PeerEvent::RequestTimedOut { .. }
                            | PeerEvent::Disconnected { .. }
                    );
                    if let Some(event) = peer_event_if_active(self.paused, event) {
                        self.handle_peer_event(event).await;
                        if requestability_changed {
                            self.retry_rate_waiting_peers().await;
                        }
                        if (!had_fresh_requestable
                            && self.webseed_fetch.is_none()
                            && self.picker.has_fresh_requestable())
                            || self.active_peers.is_empty()
                        {
                            reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                        }
                    }
                }

                _ = self.webseed_wake_notify.notified() => {
                    reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                }

                result = async {
                    let fetch = self.webseed_fetch.as_mut().expect("guarded webseed fetch");
                    (&mut fetch.task).await
                }, if self.webseed_fetch.is_some() => {
                    let fetch = self.webseed_fetch.take().expect("completed webseed fetch");
                    if let Some(fetched) = self.finish_webseed_fetch(fetch, result) {
                        self.handle_webseed_block(fetched.event).await;
                        self.retry_rate_waiting_peers().await;
                    }
                    reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                }

                completion = self.transfer_jobs.next(), if !self.transfer_jobs.is_empty() => {
                    if let Some(completion) = completion {
                        let had_fresh_requestable = self.picker.has_fresh_requestable();
                        self.handle_transfer_completion(completion).await;
                        self.retry_rate_waiting_peers().await;
                        if !had_fresh_requestable
                            && self.webseed_fetch.is_none()
                            && self.picker.has_fresh_requestable()
                        {
                            reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                        }
                    }
                }

                Some(event) = self.tracker_workers.recv_event() => {
                    match event {
                        TrackerWorkerEvent::Announce(result) => {
                            self.handle_tracker_result(result).await;
                        }
                        TrackerWorkerEvent::Scrape(scrape) => {
                            self.handle_tracker_scrape(scrape).await;
                        }
                    }
                }

                _ = choke_tick.tick() => {
                    self.run_choker().await;
                }

                _ = tracker_tick.tick() => {
                    self.evict_banned_peers().await;
                    self.enforce_seed_limits().await;
                    if self.transfer_stats_dirty {
                        self.persist_progress().await;
                    }
                    if !self.paused {
                        self.start_due_tracker_announces().await;
                    }
                    if self.crash_safety_work_pending() {
                        if !self.drive_crash_safety(&mut cmd_rx, &mut pending_command).await {
                            break;
                        }
                        reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                    }
                }

                _ = peer_retry_tick.tick() => {
                    if !self.paused {
                        self.retry_known_tracker_peers().await;
                    }
                }

                _ = peer_control_retry_tick.tick() => {
                    self.retry_pending_peer_controls();
                    self.retry_memory_denied_peer_requests().await;
                }

                _ = sleep_until_download_rate(self.download_rate_wake), if self.download_rate_wake.is_some() => {
                    self.download_rate_wake = None;
                    if !self.paused {
                        let peers: Vec<SocketAddr> = self.active_peers.keys().copied().collect();
                        for peer in peers {
                            self.refill_peer_requests(peer).await;
                        }
                        if self.webseed_fetch.is_none() && self.picker.has_fresh_requestable() {
                            reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                        }
                    }
                }

                _ = global_download_limit_changes.wait_for_change(global_download_limit_generation) => {
                    global_download_limit_generation = global_download_limit_changes.generation();
                    if !self.paused {
                        let peers: Vec<SocketAddr> = self.active_peers.keys().copied().collect();
                        for peer in peers {
                            self.refill_peer_requests(peer).await;
                        }
                        if self.webseed_fetch.is_none() && self.picker.has_fresh_requestable() {
                            reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                        }
                    }
                }

                _ = download_demand_changes.wait_for_change(download_demand_generation) => {
                    download_demand_generation = download_demand_changes.generation();
                    if !self.paused {
                        self.retry_rate_waiting_peers().await;
                        if self.webseed_fetch.is_none() && self.picker.has_fresh_requestable() {
                            reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                        }
                    }
                }

                _ = &mut webseed_sleep, if !self.paused && self.webseed_fetch.is_none() && !self.meta.webseeds.is_empty() && !self.picker.is_complete() => {
                    if self.start_webseed_block() {
                        // The HTTP request and global rate wait now own their
                        // bounded job. The actor remains free to process peer
                        // events and lifecycle commands while it is pending.
                        reset_webseed_sleep(&mut webseed_sleep, WEBSEED_RETRY_MAX);
                    } else {
                        reset_webseed_sleep(&mut webseed_sleep, self.webseed_wake_delay());
                    }
                }
            }
        }

        // A Shutdown command wins FIFO ordering, but lifecycle/query commands
        // may already be queued behind it while the bounded cleanup above is
        // running. Resolve their replies before dropping the receiver so
        // callers observe a terminal error/result instead of a silent oneshot
        // disconnect.
        reject_pending_torrent_commands(&mut cmd_rx, &mut pending_command);
    }

    fn webseed_wake_delay(&self) -> Duration {
        if self.paused
            || self.meta.webseeds.is_empty()
            || self.picker.is_complete()
            || !self.picker.has_fresh_requestable()
        {
            return WEBSEED_RETRY_MAX;
        }

        let now = Instant::now();
        let mut earliest_retry = WEBSEED_RETRY_MAX;
        let mut has_ready_seed = false;
        for (failures, next_attempt) in self
            .webseed_failures
            .iter()
            .zip(self.webseed_next_attempt.iter())
        {
            if *failures == u8::MAX {
                continue;
            }
            match next_attempt {
                Some(deadline) => {
                    earliest_retry = earliest_retry.min(deadline.saturating_duration_since(now));
                }
                None => has_ready_seed = true,
            }
        }
        if has_ready_seed {
            self.download_rate_wake
                .map_or(Duration::from_millis(100), |deadline| {
                    deadline.saturating_duration_since(now)
                })
        } else {
            earliest_retry
        }
    }

    async fn start_due_tracker_announces(&mut self) {
        if self.tracker_tiers.is_empty() {
            return;
        }

        let tier_idx = self.active_tracker_tier.min(self.tracker_tiers.len() - 1);
        let available = self.tracker_workers.available();
        if available == 0 {
            return;
        }
        let candidates = tracker_keys_for_announce(
            &self.tracker_tiers,
            tier_idx,
            self.meta.private,
            self.private_tracker_key,
        )
        .into_iter()
        .filter_map(|key @ (selected_tier, tracker_index)| {
            let tracker = self.tracker_tiers.get(selected_tier)?.get(tracker_index)?;
            (tracker.is_due() && !self.tracker_workers.contains(key)).then(|| TrackerAnnounceSpec {
                key,
                url: tracker.url.clone(),
                tracker_id: tracker.tracker_id.clone(),
                event: self.tracker_event,
            })
        })
        .take(available)
        .collect::<Vec<_>>();
        if candidates.is_empty() {
            return;
        }

        let (uploaded, downloaded) = self.transfer_snapshot().await;
        let context = self.tracker_announce_context(uploaded, downloaded);
        self.tracker_workers.start(candidates, context);
    }

    async fn handle_tracker_scrape(&mut self, result: TrackerScrapeResult) {
        if !self.tracker_workers.is_current(result.generation) {
            return;
        }
        let (tier_idx, tracker_idx) = result.key;
        let Some(tracker) = self
            .tracker_tiers
            .get_mut(tier_idx)
            .and_then(|tier| tier.get_mut(tracker_idx))
        else {
            return;
        };
        tracker.scrape_complete = Some(result.scrape.complete);
        tracker.scrape_incomplete = Some(result.scrape.incomplete);
        tracker.scrape_downloaded = Some(result.scrape.downloaded);
        self.persist_tracker_state().await;
    }

    async fn handle_tracker_result(&mut self, result: TrackerAnnounceResult) {
        self.tracker_workers.complete(result.key, result.generation);
        if !self.tracker_workers.is_current(result.generation) {
            return;
        }
        let (tier_idx, tracker_idx) = result.key;
        let Some(tier) = self.tracker_tiers.get_mut(tier_idx) else {
            return;
        };
        let Some(tracker) = tier.get_mut(tracker_idx) else {
            return;
        };
        let failed = result.response.is_err();
        match result.response {
            Ok(resp) => {
                let peers: Vec<SocketAddr> = resp.peers.iter().map(|peer| peer.addr).collect();
                tracker.on_success_with_min_interval(&resp, self.min_announce_interval);
                self.persist_tracker_state().await;
                self.tracker_event = tracker_event_after_success(self.tracker_event, result.event);
                if !peers.is_empty() && !self.paused {
                    self.remember_tracker_peers(&peers);
                    info!(
                        torrent = %self.info_hash_hex,
                        tracker = %url_log_target(&result.url),
                        peers = peers.len(),
                        "tracker announce returned peers"
                    );
                    self.connect_peers(peers, PeerSource::Tracker).await;
                }
            }
            Err(err) => {
                warn!(
                    component = "tracker",
                    operation = "announce",
                    torrent = %self.info_hash_hex,
                    tracker = %url_log_target(&result.url),
                    result = "error",
                    error = %err,
                    "tracker announce failed"
                );
                tracker.on_failure(err);
                self.persist_tracker_state().await;
            }
        }
        if self.meta.private {
            if failed {
                self.advance_private_tracker_after_failure((tier_idx, tracker_idx))
                    .await;
            }
        } else {
            self.maybe_advance_tracker_tier(tier_idx);
        }
    }

    fn tracker_announce_context(&self, uploaded: u64, downloaded: u64) -> TrackerAnnounceContext {
        TrackerAnnounceContext {
            info_hash: self.meta.info_hash,
            uploaded,
            downloaded,
            left: self.picker.bytes_left(),
            listen_port: match self.network_budget.listen_port() {
                0 => self.listen_port,
                port => port,
            },
            http_timeout: self.http_timeout,
            udp_timeout: self.udp_timeout,
            numwant: protocol_numwant(self.peer_capacity()),
            egress_policy: self.egress_policy,
            resources: self.resources.clone(),
        }
    }

    fn maybe_advance_tracker_tier(&mut self, tier_idx: usize) {
        if tier_idx != self.active_tracker_tier || self.tracker_tiers[tier_idx].is_empty() {
            return;
        }
        let has_inflight = self.tracker_workers.has_inflight_tier(tier_idx);
        if !has_inflight
            && self.tracker_tiers[tier_idx]
                .iter()
                .all(|tracker| matches!(&tracker.status, TrackerStatus::Error(_)))
        {
            self.advance_tracker_tier();
        }
    }

    async fn advance_private_tracker_after_failure(&mut self, failed: TrackerKey) {
        if self.private_tracker_key != Some(failed) {
            return;
        }
        let Some(next) = next_tracker_key(&self.tracker_tiers, failed) else {
            return;
        };
        if next == failed {
            return;
        }

        self.cancel_tracker_announces();
        self.disconnect_private_tracker_peers().await;
        self.private_tracker_key = Some(next);
        self.active_tracker_tier = next.0;
        if let Some(tracker) = self
            .tracker_tiers
            .get_mut(next.0)
            .and_then(|tier| tier.get_mut(next.1))
        {
            tracker.schedule_immediate();
        }
        debug!(
            component = "tracker",
            operation = "private_failover",
            torrent = %self.info_hash_hex,
            from_tier = failed.0,
            to_tier = next.0,
            result = "switched",
            "private torrent advanced to the next tracker after failure"
        );
    }

    async fn disconnect_private_tracker_peers(&mut self) {
        self.known_tracker_peers.clear();
        let peers = self.active_peers.keys().copied().collect::<Vec<_>>();
        for peer in peers {
            self.evict_peer(peer).await;
        }
    }

    async fn announce_stopped(&mut self) {
        if !consume_stopped_announce(&mut self.stopped_announced) {
            return;
        }

        let (uploaded, downloaded) = self.transfer_snapshot().await;
        let context = self.tracker_announce_context(uploaded, downloaded);
        let candidates = tracker_keys_for_stopped_announce(
            &self.tracker_tiers,
            self.meta.private,
            self.private_tracker_key,
        )
        .into_iter()
        .filter_map(|(tier_idx, tracker_idx)| {
            let tracker = self.tracker_tiers.get(tier_idx)?.get(tracker_idx)?;
            Some((
                tier_idx,
                tracker_idx,
                tracker.url.clone(),
                tracker.tracker_id.clone(),
            ))
        })
        .collect::<Vec<_>>();
        if candidates.is_empty() {
            return;
        }

        // A stopped announce is still awaited so pause/quiesce/shutdown do
        // not report completion before the terminal tracker event has had a
        // chance to leave the process. The network work itself is bounded
        // and parallel, however: a dead tracker must not hold the actor for
        // one full timeout per tier entry. The outer deadline also cancels
        // requests whose individual HTTP/UDP timeout is longer.
        let mut pending = futures::stream::iter(candidates.into_iter().map(
            |(tier_idx, tracker_idx, url, tracker_id)| {
                let context = context.clone();
                async move {
                    let result = announce_tracker(
                        &context,
                        &url,
                        TrackerEvent::Stopped,
                        tracker_id.as_deref(),
                    )
                    .await
                    .map(|response| response.response);
                    (tier_idx, tracker_idx, url, result)
                }
            },
        ))
        .buffer_unordered(MAX_TRACKER_ANNOUNCES_IN_FLIGHT);
        let deadline = sleep(STOPPED_TRACKER_ANNOUNCE_DEADLINE);
        tokio::pin!(deadline);
        let mut results = Vec::new();
        let mut deadline_exceeded = false;
        loop {
            tokio::select! {
                result = pending.next() => {
                    let Some(result) = result else { break };
                    results.push(result);
                }
                _ = &mut deadline => {
                    deadline_exceeded = true;
                    break;
                }
            }
        }
        if deadline_exceeded {
            warn!(
                component = "tracker",
                operation = "announce_stopped",
                torrent = %self.info_hash_hex,
                result = "deadline_exceeded",
                deadline_secs = STOPPED_TRACKER_ANNOUNCE_DEADLINE.as_secs(),
                completed = results.len(),
                "stopped tracker announces exceeded aggregate deadline"
            );
        }

        let had_results = !results.is_empty();
        for (tier_idx, tracker_idx, url, result) in results {
            let Some(tracker) = self
                .tracker_tiers
                .get_mut(tier_idx)
                .and_then(|tier| tier.get_mut(tracker_idx))
            else {
                continue;
            };
            match result {
                Ok(resp) => tracker.on_success_with_min_interval(&resp, self.min_announce_interval),
                Err(err) => {
                    warn!(
                        component = "tracker",
                        operation = "announce_stopped",
                        torrent = %self.info_hash_hex,
                        tracker = %url_log_target(&url),
                        result = "error",
                        error = %err,
                        "tracker stopped announce failed"
                    );
                    tracker.on_failure(err);
                }
            }
        }
        if had_results {
            self.persist_tracker_state().await;
        }
    }

    async fn announce_stopped_with_control_deadline(&mut self) {
        if timeout(
            STOPPED_TRACKER_CONTROL_ANNOUNCE_DEADLINE,
            self.announce_stopped(),
        )
        .await
        .is_err()
        {
            warn!(
                component = "tracker",
                operation = "announce_stopped",
                torrent = %self.info_hash_hex,
                result = "control_deadline_exceeded",
                deadline_ms = STOPPED_TRACKER_CONTROL_ANNOUNCE_DEADLINE.as_millis(),
                "stopped tracker announce exceeded the lifecycle control deadline"
            );
        }
    }

    fn restart_tracker_session(&mut self) {
        self.cancel_tracker_announces();
        self.tracker_event = TrackerEvent::Started;
        self.stopped_announced = false;
        // A stopped announce records the tracker's ordinary next interval.
        // Resuming is a new tracker session, so that old deadline must not
        // delay the Started event until the previous session's interval has
        // elapsed.
        self.schedule_trackers_now();
    }

    fn cancel_tracker_announces(&mut self) {
        self.tracker_workers.cancel();
    }

    async fn persist_tracker_state(&mut self) {
        if let Err(error) = self.persist_tracker_state_inner().await {
            warn!(
                component = "db",
                operation = "persist_tracker_state",
                torrent = %self.info_hash_hex,
                result = "error",
                error = %error,
                "failed to persist tracker state; retaining the prior registry projection"
            );
        }
    }

    async fn persist_tracker_state_inner(&mut self) -> Result<(), String> {
        let (uploaded, downloaded) = self.transfer_snapshot().await;
        let left = db_i64(self.reported_bytes_left());
        let now = Instant::now();
        let mut rows = Vec::new();
        let mut tracker_index = 0i64;
        let mut tracker_count = 0u64;
        let mut tracker_snapshot_bytes = 0u64;
        // TorrentNG-client counterpart to the compatible-client service's
        // cached `t.message`
        // column: a torrent can be actively seeding/downloading fine while
        // its tracker rejects announces, which `state` alone never
        // reflects. Cache the first error/warning message found across
        // any tier on the registry entry so list/facet queries can read it
        // directly instead of needing a per-torrent round trip through
        // this actor.
        let mut tracker_message: Option<String> = None;
        for (tier_idx, tier) in self.tracker_tiers.iter().enumerate() {
            for tracker in tier {
                let failure_reason = tracker_failure_reason(&tracker.status);
                let warning_message = tracker_warning_message(&tracker.status);
                let row_bytes = 256u64
                    .saturating_add(self.info_hash_hex.len() as u64)
                    .saturating_add(tracker.url.len() as u64)
                    .saturating_add(tracker_status_label(&tracker.status).len() as u64)
                    .saturating_add(
                        tracker
                            .tracker_id
                            .as_ref()
                            .map_or(0, |tracker_id| tracker_id.len() as u64),
                    )
                    .saturating_add(
                        failure_reason
                            .as_ref()
                            .map_or(0, |message| message.len() as u64),
                    )
                    .saturating_add(
                        warning_message
                            .as_ref()
                            .map_or(0, |message| message.len() as u64),
                    );
                tracker_count = tracker_count.saturating_add(1);
                tracker_snapshot_bytes = tracker_snapshot_bytes.saturating_add(row_bytes);
                crate::engine::validate_tracker_snapshot_size(
                    tracker_count,
                    tracker_snapshot_bytes,
                )?;

                if tracker_message.is_none() {
                    tracker_message = failure_reason.clone().or_else(|| warning_message.clone());
                }
                rows.push(rt_db::TorrentTrackerRow {
                    info_hash: self.info_hash_hex.clone(),
                    tracker_index,
                    tier: i64::try_from(tier_idx).unwrap_or(i64::MAX),
                    url: tracker.url.clone(),
                    tracker_id: tracker.tracker_id.clone(),
                    status: tracker_status_label(&tracker.status).to_owned(),
                    last_announce_at: instant_to_unix(tracker.last_announce, now),
                    next_announce_at: instant_to_unix(tracker.next_announce, now),
                    last_success_at: instant_to_unix(tracker.last_success, now),
                    failure_reason,
                    warning_message,
                    seeders: tracker.scrape_complete.map(i64::from),
                    leechers: tracker.scrape_incomplete.map(i64::from),
                    completed: tracker.scrape_downloaded.map(i64::from),
                    uploaded: db_i64(uploaded),
                    downloaded: db_i64(downloaded),
                    left_bytes: left,
                });
                tracker_index += 1;
            }
        }
        let info_hash = self.info_hash_hex.clone();
        self.db
            .run("persist_tracker_state", move |db| {
                rt_db::replace_torrent_trackers(db, &info_hash, &rows)
                    .map_err(|error| error.to_string())
            })
            .await?;
        let mut reg = self.registry.write().await;
        if let Some(mut entry) = reg.get_mut(&self.info_hash_hex) {
            entry.tracker_message = tracker_message;
        };
        Ok(())
    }

    fn schedule_trackers_now(&mut self) {
        if self.meta.private {
            if let Some(key) = self
                .private_tracker_key
                .or_else(|| first_tracker_key(&self.tracker_tiers))
            {
                if let Some(tracker) = self
                    .tracker_tiers
                    .get_mut(key.0)
                    .and_then(|tier| tier.get_mut(key.1))
                {
                    tracker.schedule_immediate();
                }
            }
        } else {
            for tier in &mut self.tracker_tiers {
                for tracker in tier {
                    tracker.schedule_immediate();
                }
            }
        }
    }

    async fn apply_tracker_urls(&mut self, trackers: Vec<String>) -> Result<(), String> {
        let tracker_tiers = tracker_tiers_from_urls(&trackers);
        self.refresh_tracker_state_memory(&tracker_tiers, tracker_tiers.capacity())?;
        self.cancel_tracker_announces();
        if self.meta.private {
            self.disconnect_private_tracker_peers().await;
        }
        self.tracker_tiers = tracker_tiers;
        self.private_tracker_key = if self.meta.private {
            first_tracker_key(&self.tracker_tiers)
        } else {
            None
        };
        self.active_tracker_tier = self.private_tracker_key.map_or(0, |(tier, _)| tier);
        self.tracker_event = TrackerEvent::Empty;
        self.schedule_trackers_now();

        {
            let mut registry = self.registry.write().await;
            if let Some(mut entry) = registry.get_mut(&self.info_hash_hex) {
                entry.tracker_message = None;
            };
        }
        // The engine persists the compact URL override and fresh detail rows
        // before sending this command. A tracker result that was already
        // waiting on the DB worker can nevertheless complete after that
        // transaction and overwrite the detail rows with its older snapshot.
        // Re-persist the projection after installing the new URLs so the
        // command acknowledgement also fences that stale detail write.
        self.persist_tracker_state().await;
        Ok(())
    }

    fn schedule_active_tracker_tier_now(&mut self) {
        if self.tracker_tiers.is_empty() {
            return;
        }
        let tier_idx = self.active_tracker_tier.min(self.tracker_tiers.len() - 1);
        for (selected_tier, tracker_idx) in tracker_keys_for_announce(
            &self.tracker_tiers,
            tier_idx,
            self.meta.private,
            self.private_tracker_key,
        ) {
            if let Some(tracker) = self
                .tracker_tiers
                .get_mut(selected_tier)
                .and_then(|tier| tier.get_mut(tracker_idx))
            {
                tracker.schedule_immediate();
            }
        }
    }

    async fn apply_file_policy_from_db(&mut self) -> Result<(), String> {
        let info_hash = self.info_hash_hex.clone();
        let (rows, limits) = self
            .db
            .run("load_file_policy", move |db| {
                let rows = rt_db::list_torrent_files(db, &info_hash)
                    .map_err(|error| format!("loading torrent file policy: {error}"))?;
                let limits = Self::torrent_limits_from_db(db, &info_hash)?;
                Ok((rows, limits))
            })
            .await?;
        // Admission must precede the clone and replacement map construction;
        // reserving only after those allocations lets a large durable policy
        // briefly bypass the metadata governor during reload.
        let _file_policy_workspace_memory_lease = self.reserve_file_policy_workspace_memory()?;
        let mut effective_files = self.metainfo_files.clone();
        let mut policy = HashMap::with_capacity(rows.len());
        for row in rows {
            let file_index = u32::try_from(row.file_index).map_err(|_| {
                format!(
                    "persisted file policy has invalid file index {}",
                    row.file_index
                )
            })?;
            let Some(file) = effective_files
                .iter_mut()
                .find(|file| file.index == file_index)
            else {
                return Err(format!(
                    "persisted file policy references unknown file index {file_index}"
                ));
            };
            file.path = parse_persisted_file_path(&row.path)?;
            if !(0..=2).contains(&row.priority) {
                return Err(format!(
                    "persisted file policy has invalid priority {} for file {file_index}",
                    row.priority
                ));
            }
            if policy
                .insert(
                    file_index,
                    (
                        row.wanted && !file.pad,
                        if file.pad { 0 } else { row.priority },
                    ),
                )
                .is_some()
            {
                return Err(format!(
                    "persisted file policy contains duplicate file index {file_index}"
                ));
            }
        }

        // Padding entries are synthetic zero bytes. Keep them disabled even
        // when a partial durable projection omitted the row.
        for file in &effective_files {
            policy
                .entry(file.index)
                .or_insert((!file.pad, if file.pad { 0 } else { 1 }));
        }

        crate::engine::validate_file_path_projection(
            effective_files
                .iter()
                .filter(|file| !file.pad)
                .map(|file| file.path.as_display()),
        )?;

        let paths_changed = self.meta.files.len() != effective_files.len()
            || self
                .meta
                .files
                .iter()
                .zip(&effective_files)
                .any(|(current, effective)| {
                    current.index != effective.index || current.path != effective.path
                });
        if paths_changed {
            let mut changed_file_indices = self
                .meta
                .files
                .iter()
                .filter_map(|current| {
                    effective_files
                        .iter()
                        .find(|effective| effective.index == current.index)
                        .filter(|effective| effective.path != current.path)
                        .map(|_| current.index)
                })
                .collect::<Vec<_>>();
            changed_file_indices.sort_unstable();
            changed_file_indices.dedup();
            let changed_piece_ranges = self
                .piece_map
                .piece_ranges_for_file_indices(&changed_file_indices)
                .map_err(|error| format!("invalidating renamed file pieces: {error}"))?;
            let file_policy_memory_lease = self.reserve_file_policy_memory(&effective_files)?;
            // Peer upload contexts hold an Arc<PieceMap> and a copy of the
            // storage root. End those sessions before publishing the new map,
            // otherwise an in-flight peer can keep reading the old path after
            // the rename has been accepted.
            let piece_map = build_piece_map(self.meta.piece_length, &effective_files)?;
            self.shutdown_peers().await;
            // A path projection change changes the bytes represented by every
            // overlapping piece: the old file may still exist, the new file
            // may be missing, or an operator may have moved a replacement
            // into place. Do not retain the old picker result across that
            // boundary, or the task can remain falsely complete/seeding and
            // serve data from an unverified path.
            for (first, last) in changed_piece_ranges {
                for piece in first..last {
                    let (_, actions) = self.transfer_ledger.piece_failed_with_actions(piece);
                    self.apply_transfer_actions(actions);
                    self.transfer_piece_memory_leases.remove(&piece);
                    self.picker.reject_piece(piece as usize);
                    self.restored_partial_pieces.remove(&piece);
                }
            }
            Arc::make_mut(&mut self.meta).files = effective_files;
            self.piece_map = piece_map;
            self._file_policy_memory_lease = file_policy_memory_lease;
            lock_prepared_files(&self.prepared_files).clear();
        }

        let piece_count = self.piece_map.piece_count as usize;
        let file_lengths: HashMap<u32, u64> = self
            .meta
            .files
            .iter()
            .map(|file| (file.index, file.length))
            .collect();
        let mut enabled = vec![false; piece_count];
        let mut priority = vec![false; piece_count];
        for piece in 0..self.piece_map.piece_count {
            let regions = self
                .piece_map
                .piece_to_file_regions(piece)
                .map_err(|error| format!("building file policy for piece {piece}: {error}"))?;
            let mut any_wanted = false;
            let mut any_high = false;
            let mut any_first_last = false;
            for region in regions {
                if region.pad {
                    continue;
                }
                let (wanted, priority) =
                    policy.get(&region.file_index).copied().unwrap_or((true, 1));
                any_wanted |= wanted && priority > 0;
                any_high |= wanted && priority > 1;
                let file_len = file_lengths
                    .get(&region.file_index)
                    .copied()
                    .ok_or_else(|| {
                        format!(
                            "piece {piece} references unknown file index {}",
                            region.file_index
                        )
                    })?;
                if limits.first_last_piece_prio && wanted && priority > 0 {
                    if region.file_offset > file_len
                        || region.length > file_len.saturating_sub(region.file_offset)
                    {
                        return Err(format!(
                            "piece {piece} has an out-of-range region for file {}",
                            region.file_index
                        ));
                    }
                    any_first_last |= region.file_offset == 0
                        || region.file_offset.saturating_add(region.length) >= file_len;
                }
            }
            enabled[piece as usize] = any_wanted;
            if any_high || any_first_last {
                priority[piece as usize] = true;
            }
        }
        self.apply_piece_policy(&enabled, priority);
        // File priorities can make a previously denied peer's only useful
        // piece disappear. Reconcile those parked rate demands immediately.
        self.retry_rate_waiting_peers().await;
        Ok(())
    }

    fn apply_piece_policy(&mut self, enabled: &[bool], priority: Vec<bool>) {
        for (piece, enabled) in enabled.iter().copied().enumerate() {
            if !enabled && !self.picker.have_piece(piece) {
                let (_, actions) = self.transfer_ledger.piece_failed_with_actions(piece as u32);
                self.apply_transfer_actions(actions);
                self.transfer_piece_memory_leases.remove(&(piece as u32));
            }
            self.picker.set_piece_enabled(piece, enabled);
        }
        self.picker.set_priority_mask(priority);
        self.webseed_wake_notify.notify_one();
    }

    async fn apply_torrent_limits_from_db(&mut self) -> Result<(), String> {
        let info_hash = self.info_hash_hex.clone();
        let limits = self
            .db
            .run("load_torrent_limits", move |db| {
                Self::torrent_limits_from_db(db, &info_hash)
            })
            .await?;
        self.apply_torrent_limits(&limits).await
    }

    async fn apply_torrent_limits(&mut self, limits: &EngineTorrentLimits) -> Result<(), String> {
        // Validate and install the complete file policy before changing any
        // other in-memory limit. This keeps a malformed durable file-policy
        // row from producing a partially applied runtime configuration.
        self.apply_file_policy_from_db().await?;
        self.picker.set_sequential(limits.sequential_download);
        if let Some(piece) = limits.sequential_download_from_piece {
            self.picker.set_sequential_from_piece(piece as usize);
        }
        self.super_seeding = limits.super_seeding;
        self.seed_ratio_limit = limits
            .seed_ratio_limit
            .filter(|value| value.is_finite() && *value >= 0.0);
        self.seed_idle_limit = limits
            .seed_idle_limit
            .and_then(|minutes| u64::try_from(minutes).ok())
            .filter(|minutes| *minutes > 0)
            .map(|minutes| Duration::from_secs(minutes.saturating_mul(60)));
        let upload_accounting_batch_bytes =
            if self.seed_ratio_limit.is_some() || self.seed_idle_limit.is_some() {
                1
            } else {
                UPLOAD_ACCOUNTING_BATCH_BYTES
            };
        for peer in self.active_peers.values() {
            peer.upload_accounting
                .batch_bytes
                .store(upload_accounting_batch_bytes, Ordering::Relaxed);
        }
        self.flush_pending_upload_accounting().await;
        self.torrent_max_peers = limits.max_connections.and_then(|value| {
            usize::try_from(value)
                .ok()
                .filter(|connections| *connections > 0)
        });
        let previous_download_limit = self.torrent_download_limit_bytes_per_sec;
        self.set_torrent_download_limit(limits.download_limit);
        self.set_torrent_upload_limit(limits.upload_limit);
        if previous_download_limit != self.torrent_download_limit_bytes_per_sec {
            let peers = self.active_peers.keys().copied().collect::<Vec<_>>();
            for peer in peers {
                self.refill_peer_requests(peer).await;
            }
        }
        Ok(())
    }

    fn fail_closed_runtime_policy(&mut self, operation: &str, error: &str) {
        for piece in 0..self.piece_map.piece_count {
            self.picker.set_piece_enabled(piece as usize, false);
            if !self.picker.have_piece(piece as usize) {
                let (_, actions) = self.transfer_ledger.piece_failed_with_actions(piece);
                self.apply_transfer_actions(actions);
                self.transfer_piece_memory_leases.remove(&piece);
            }
        }
        self.picker.set_priority(Vec::new());
        self.paused = true;
        self.recheck_restore_state = Some(TorrentState::Paused);
        warn!(
            component = "torrent",
            operation,
            torrent = %self.info_hash_hex,
            result = "paused",
            error,
            "persisted runtime policy could not be loaded; torrent starts paused with piece selection disabled"
        );
    }

    fn peer_capacity(&self) -> usize {
        self.torrent_max_peers
            .map(|limit| limit.min(self.max_peers))
            .unwrap_or(self.max_peers)
    }

    fn set_torrent_download_limit(&mut self, limit: Option<i64>) {
        self.torrent_download_limit_bytes_per_sec =
            limit.and_then(|value| (value > 0).then_some(value as u64));
        self.recompute_download_limit();
    }

    fn recompute_download_limit(&mut self) {
        self.network_budget.set_download_torrent_limit(
            self.transfer_rate_torrent,
            self.torrent_download_limit_bytes_per_sec,
        );
        self.download_rate_wake = None;
    }

    fn set_torrent_upload_limit(&mut self, limit: Option<i64>) {
        self.torrent_upload_limit_bytes_per_sec =
            limit.and_then(|value| (value > 0).then_some(value as u64));
        self.recompute_upload_limit();
    }

    fn recompute_upload_limit(&mut self) {
        // See recompute_download_limit: global traffic is enforced by the
        // process-shared rate tree. Reapplying the torrent limit preserves
        // existing debt and wakes parked upload reads to recompute deadlines.
        self.network_budget.set_upload_torrent_limit(
            self.transfer_rate_torrent,
            self.torrent_upload_limit_bytes_per_sec,
        );
        // Retained during the reversible migration until the download side
        // and webseed adapters have moved to the shared service.
    }

    fn torrent_limits_from_db(
        db: &Connection,
        info_hash: &str,
    ) -> Result<EngineTorrentLimits, String> {
        match rt_db::get_torrent_limits(db, info_hash) {
            Ok(row) => Ok(EngineTorrentLimits {
                download_limit: row.download_limit,
                upload_limit: row.upload_limit,
                max_connections: row.max_connections,
                seed_ratio_limit: row.seed_ratio_limit,
                seed_idle_limit: row.seed_idle_limit,
                sequential_download: row.sequential_download,
                sequential_download_from_piece: row.sequential_download_from_piece,
                first_last_piece_prio: row.first_last_piece_prio,
                force_start: row.force_start,
                super_seeding: row.super_seeding,
                auto_tmm: row.auto_tmm,
                auto_management: row.auto_management,
            }),
            Err(rt_db::DbError::NotFound(_)) => Ok(EngineTorrentLimits::default()),
            Err(error) => Err(format!("loading torrent limits: {error}")),
        }
    }

    fn advance_tracker_tier(&mut self) {
        if self.tracker_tiers.len() <= 1 {
            return;
        }
        let old = self.active_tracker_tier;
        self.active_tracker_tier = (self.active_tracker_tier + 1) % self.tracker_tiers.len();
        for tracker in &mut self.tracker_tiers[self.active_tracker_tier] {
            tracker.schedule_immediate();
        }
        warn!(
            torrent = %self.info_hash_hex,
            from_tier = old,
            to_tier = self.active_tracker_tier,
            "advancing tracker tier after announce failures"
        );
    }

    async fn prepare_resume(&mut self) -> Result<(), String> {
        let was_paused = self.paused;
        self.paused = false;
        self.restart_tracker_session();
        if let Err(error) = self.set_state_checked(TorrentState::Checking).await {
            self.paused = was_paused;
            if was_paused {
                self.cancel_tracker_announces();
            }
            return Err(format!("failed to persist torrent resume state: {error}"));
        }
        self.recheck_restore_state = None;
        self.webseed_wake_notify.notify_one();
        Ok(())
    }

    #[cfg(test)]
    async fn run_recheck(&mut self, job_id: Option<String>) -> RecheckOutcome {
        let (_, replacement_cmd_rx) = mpsc::channel(1);
        let mut cmd_rx = std::mem::replace(&mut self.cmd_rx, replacement_cmd_rx);
        let mut pending_command = None;
        let outcome = self
            .run_recheck_with_receiver(&mut cmd_rx, &mut pending_command, job_id)
            .await;
        self.cmd_rx = cmd_rx;
        outcome
    }

    async fn run_recheck_with_receiver(
        &mut self,
        cmd_rx: &mut mpsc::Receiver<TorrentCmd>,
        pending_command: &mut Option<TorrentCmd>,
        job_id: Option<String>,
    ) -> RecheckOutcome {
        // A recheck decides the torrent's completion itself, so a completion
        // gate or queued verification from before it is void.
        self.completion_gate = None;
        self.completion_verify_plan = None;
        let outcome = self
            .run_recheck_inner(cmd_rx, pending_command, job_id)
            .await;
        self.completion_verifying = false;
        self.recheck_subset = None;
        outcome
    }

    async fn run_recheck_inner(
        &mut self,
        cmd_rx: &mut mpsc::Receiver<TorrentCmd>,
        pending_command: &mut Option<TorrentCmd>,
        mut job_id: Option<String>,
    ) -> RecheckOutcome {
        // Stop a source fetch before any recheck drain, persistence, or disk
        // work can hold the actor. Its late response must not cross into the
        // new verification epoch.
        self.close_webseed_transfer_connection();
        let mut valid = 0usize;
        // A subset recheck (completion `sample` verification) re-hashes only
        // the chosen pieces and leaves every other piece as it was.
        let subset = self.recheck_subset.take();
        let verification_run = self.completion_verifying;
        let previously_completed = self.registry_completed_at().await.is_some();
        let recheck_trigger = if verification_run {
            "completion_verify"
        } else if self.recovery_recheck_reason.take().is_some() {
            "crash_recovery"
        } else {
            "recheck"
        };
        let mut verified_bytes = 0_u64;
        // The picker is updated as each piece is verified, so retaining a
        // second result entry for every piece only multiplied recheck memory
        // for large torrents. Keep the job-facing invalid sample bounded at
        // the same limit enforced by the database, while the accumulator
        // retains the complete count for progress events.
        let mut invalid_pieces = RecheckInvalidPieces::new(self.piece_map.piece_count);
        // A recheck supersedes any announce already in flight. Without a
        // generation bump, a stale Started/Completed response can be handled
        // after a pause or cancellation and mutate the tracker session that
        // the recheck is supposed to have frozen.
        self.cancel_tracker_announces();
        // `shutdown_peers` also clears in-memory piece assemblies. Flush
        // those received blocks first so starting a recheck cannot discard
        // progress that has not yet crossed the normal complete-piece write
        // boundary.
        self.drain_transfer_jobs().await;
        self.save_fastresume(false).await;
        self.shutdown_peers().await;
        // Do not checkpoint the old fastresume bitmap while this scan is in
        // progress. Publish each piece below only after its current bytes
        // have been hashed, so a crash cannot restore stale-valid pieces.
        if subset.is_none() {
            for piece in 0..self.piece_map.piece_count {
                self.picker.reject_piece(piece as usize);
                let (_, actions) = self.transfer_ledger.piece_failed_with_actions(piece);
                self.apply_transfer_actions(actions);
                self.transfer_piece_memory_leases.remove(&piece);
            }
        }
        if let Err(error) = self.set_state_checked(TorrentState::Checking).await {
            self.paused = true;
            self.cancel_tracker_announces();
            await_stopped_announce_or_queue_command(self, cmd_rx, pending_command).await;
            if let Some(job_id) = &job_id {
                self.persist_recheck_job_progress(
                    job_id,
                    0,
                    verified_bytes,
                    &invalid_pieces,
                    JOB_STATE_FAILED,
                    Some("failed to persist torrent checking state"),
                )
                .await;
            }
            return RecheckOutcome::Failed(format!(
                "failed to persist torrent checking state: {error}"
            ));
        }

        let mut subset_pieces = subset.as_ref().map(|pieces| pieces.iter().copied());
        let mut next_piece = 0u32;
        loop {
            let piece = match subset_pieces.as_mut() {
                Some(pieces) => match pieces.next() {
                    Some(piece) => piece,
                    None => break,
                },
                None => {
                    if next_piece >= self.piece_map.piece_count {
                        break;
                    }
                    let piece = next_piece;
                    next_piece += 1;
                    piece
                }
            };
            match self
                .pending_recheck_control(cmd_rx, pending_command, &mut job_id)
                .await
            {
                Some(RecheckOutcome::Paused {
                    reply,
                    previous_paused,
                    previous_restore_state,
                    state_persisted,
                }) => {
                    self.save_fastresume(false).await;
                    let result = if state_persisted {
                        Ok(())
                    } else {
                        self.set_state_checked(TorrentState::Paused)
                            .await
                            .map_err(|error| {
                                format!("failed to persist torrent pause after recheck: {error}")
                            })
                    };
                    if let Err(error) = &result {
                        warn!(
                            component = "torrent",
                            operation = "pause_during_recheck",
                            torrent = %self.info_hash_hex,
                            result = "error",
                            error = %error,
                            "failed to persist torrent pause after recheck"
                        );
                    }
                    if let Some(reply) = reply {
                        let _ = reply.send(result.clone());
                    }
                    if result.is_err() {
                        // The pause request was rejected by durable storage.
                        // Restore the pre-request runtime intent and keep the
                        // recheck running against its still-Checking state;
                        // otherwise the task would remain paused while the
                        // registry/database still claim verification is active.
                        self.paused = previous_paused;
                        self.recheck_restore_state = previous_restore_state;
                        continue;
                    }
                    if let Some(job_id) = &job_id {
                        self.persist_recheck_job_progress(
                            job_id,
                            piece,
                            verified_bytes,
                            &invalid_pieces,
                            if result.is_ok() {
                                JOB_STATE_PAUSED
                            } else {
                                JOB_STATE_FAILED
                            },
                            if result.is_ok() {
                                Some("recheck paused")
                            } else {
                                Some("failed to persist torrent pause after recheck")
                            },
                        )
                        .await;
                    }
                    await_stopped_announce_or_queue_command(self, cmd_rx, pending_command).await;
                    return RecheckOutcome::Paused {
                        reply: None,
                        previous_paused,
                        previous_restore_state,
                        state_persisted: true,
                    };
                }
                Some(RecheckOutcome::Cancelled) => {
                    let restore_state = self.recheck_restore_state.unwrap_or(TorrentState::Paused);
                    self.paused =
                        matches!(restore_state, TorrentState::Paused | TorrentState::Stopped);
                    self.recheck_restore_state = Some(restore_state);
                    self.cancel_tracker_announces();
                    self.save_fastresume(false).await;
                    await_stopped_announce_or_queue_command(self, cmd_rx, pending_command).await;
                    let lifecycle_persisted = if let Err(error) =
                        self.set_state_checked(restore_state).await
                    {
                        warn!(
                            component = "torrent",
                            operation = "cancel_recheck",
                            torrent = %self.info_hash_hex,
                            result = "error",
                            error = %error,
                            "failed to persist torrent lifecycle state after recheck cancellation"
                        );
                        false
                    } else {
                        true
                    };
                    if lifecycle_persisted {
                        if let Some(job_id) = &job_id {
                            self.persist_recheck_job_progress(
                                job_id,
                                piece,
                                verified_bytes,
                                &invalid_pieces,
                                JOB_STATE_CANCELLED,
                                Some("recheck cancelled"),
                            )
                            .await;
                        }
                    } else {
                        // Keep the durable job in `cancelling` when the
                        // restored torrent state was not committed. A
                        // terminal job would be ignored by restart recovery
                        // while the torrent row still says `Checking`.
                        warn!(
                            component = "torrent",
                            operation = "cancel_recheck",
                            torrent = %self.info_hash_hex,
                            result = "recoverable",
                            "recheck cancellation remains recoverable until torrent state persistence succeeds"
                        );
                    }
                    return RecheckOutcome::Cancelled;
                }
                Some(RecheckOutcome::Shutdown) => {
                    // A disconnected command channel reaches this branch
                    // without the explicit Shutdown arm below. Keep the
                    // terminal tracker event best effort for both cases.
                    self.announce_stopped_with_control_deadline().await;
                    self.save_fastresume_for_exit().await;
                    if let Err(error) = self.set_state_checked(TorrentState::Stopped).await {
                        warn!(
                            component = "torrent",
                            operation = "shutdown_during_recheck",
                            torrent = %self.info_hash_hex,
                            result = "error",
                            error = %error,
                            "failed to persist stopped state after recheck shutdown"
                        );
                    }
                    if let Some(job_id) = &job_id {
                        self.persist_recheck_job_progress(
                            job_id,
                            piece,
                            verified_bytes,
                            &invalid_pieces,
                            JOB_STATE_PAUSED,
                            Some("recheck interrupted by shutdown"),
                        )
                        .await;
                    }
                    return RecheckOutcome::Shutdown;
                }
                Some(RecheckOutcome::Complete) | None => {}
                Some(RecheckOutcome::Failed(error)) => {
                    return RecheckOutcome::Failed(error);
                }
            }

            // Recheck must use the same torrent-view selection as completion
            // verification. For hybrid torrents this verifies the v1 piece
            // and authenticated v2 file range from one read stream.
            let result = self.verify_piece(piece).await;
            match result {
                VerifyResult::Valid => {
                    valid += 1;
                    verified_bytes = verified_bytes.saturating_add(
                        self.piece_length(piece).map(u64::from).unwrap_or_default(),
                    );
                    self.picker.mark_have(piece as usize);
                    let actions = self.transfer_ledger.mark_have(piece);
                    self.apply_transfer_actions(actions);
                    self.transfer_piece_memory_leases.remove(&piece);
                }
                VerifyResult::Invalid => {
                    invalid_pieces.record(piece);
                    self.picker.reject_piece(piece as usize);
                    let (_, actions) = self.transfer_ledger.piece_failed_with_actions(piece);
                    self.apply_transfer_actions(actions);
                    self.transfer_piece_memory_leases.remove(&piece);
                }
                VerifyResult::Missing { .. } => {
                    invalid_pieces.record(piece);
                    self.picker.reject_piece(piece as usize);
                    let (_, actions) = self.transfer_ledger.piece_failed_with_actions(piece);
                    self.apply_transfer_actions(actions);
                    self.transfer_piece_memory_leases.remove(&piece);
                }
            }

            if piece > 0 && piece % 64 == 0 {
                self.save_fastresume(false).await;
                if let Some(job_id) = &job_id {
                    self.persist_recheck_job_progress(
                        job_id,
                        piece + 1,
                        verified_bytes,
                        &invalid_pieces,
                        JOB_STATE_RUNNING,
                        Some("recheck progress"),
                    )
                    .await;
                }
            }
        }

        info!(
            torrent = %self.info_hash_hex,
            valid,
            invalid = invalid_pieces.total,
            "recheck complete"
        );
        // From here the recheck's own verdict (Seeding or Downloading) is
        // authoritative; the one-byte completion hold no longer applies.
        self.completion_verifying = false;
        self.report_recheck_outcome(
            &invalid_pieces,
            valid,
            previously_completed,
            verification_run,
            subset.is_some(),
            recheck_trigger,
        )
        .await;
        self.save_fastresume(subset.is_none()).await;

        let final_state = if self.paused {
            if let Some(restore_state) = self.recheck_restore_state {
                // A recheck requested for a paused or stopped torrent must
                // not silently start it. Dormant tasks are also constructed
                // paused, so this branch is gated by the explicit restore
                // intent rather than by `self.paused` alone.
                self.tracker_event = TrackerEvent::Started;
                self.cancel_tracker_announces();
                restore_state
            } else {
                // Promotion temporarily starts an active dormant torrent in
                // the paused runtime mode while its recheck command is being
                // delivered. Once verification completes, restore activity.
                self.paused = false;
                self.restart_tracker_session();
                if self.picker.is_complete() {
                    self.tracker_event = TrackerEvent::Completed;
                    self.schedule_trackers_now();
                    TorrentState::Seeding
                } else {
                    self.persist_progress().await;
                    TorrentState::Downloading
                }
            }
        } else if self.picker.is_complete() {
            self.tracker_event = TrackerEvent::Completed;
            self.schedule_trackers_now();
            TorrentState::Seeding
        } else {
            self.tracker_event = tracker_event_after_incomplete_recheck(self.tracker_event);
            // Rechecking cancelled any announce from the previous state. The
            // tracker needs a fresh left/count snapshot when the torrent is
            // found incomplete, even if the old session deadline was still in
            // the future.
            self.schedule_trackers_now();
            self.persist_progress().await;
            TorrentState::Downloading
        };
        if let Err(error) = self.set_state_checked(final_state).await {
            self.paused = true;
            self.tracker_event = TrackerEvent::Started;
            self.cancel_tracker_announces();
            await_stopped_announce_or_queue_command(self, cmd_rx, pending_command).await;
            self.shutdown_peers().await;
            if let Some(job_id) = &job_id {
                self.persist_recheck_job_progress(
                    job_id,
                    self.piece_map.piece_count,
                    verified_bytes,
                    &invalid_pieces,
                    JOB_STATE_FAILED,
                    Some("failed to persist torrent state after recheck"),
                )
                .await;
            }
            return RecheckOutcome::Failed(format!(
                "failed to persist torrent state after recheck: {error}"
            ));
        }
        if let Some(job_id) = &job_id {
            self.persist_recheck_job_progress(
                job_id,
                self.piece_map.piece_count,
                verified_bytes,
                &invalid_pieces,
                JOB_STATE_COMPLETED,
                Some("recheck completed"),
            )
            .await;
        }
        self.webseed_wake_notify.notify_one();
        RecheckOutcome::Complete
    }

    async fn pending_recheck_control(
        &mut self,
        cmd_rx: &mut mpsc::Receiver<TorrentCmd>,
        pending_command: &mut Option<TorrentCmd>,
        active_job_id: &mut Option<String>,
    ) -> Option<RecheckOutcome> {
        loop {
            match cmd_rx.try_recv() {
                Ok(TorrentCmd::Pause { reply }) => {
                    let previous_paused = self.paused;
                    let previous_restore_state = self.recheck_restore_state;
                    self.paused = true;
                    self.recheck_restore_state = Some(TorrentState::Paused);
                    self.cancel_tracker_announces();
                    self.shutdown_peers().await;
                    return Some(RecheckOutcome::Paused {
                        reply,
                        previous_paused,
                        previous_restore_state,
                        state_persisted: false,
                    });
                }
                Ok(TorrentCmd::Shutdown) => {
                    self.paused = true;
                    self.cancel_tracker_announces();
                    self.shutdown_peers().await;
                    self.announce_stopped_with_control_deadline().await;
                    return Some(RecheckOutcome::Shutdown);
                }
                Ok(TorrentCmd::Resume { reply }) => {
                    self.paused = false;
                    self.recheck_restore_state = None;
                    // A paused torrent normally has no tracker workers left;
                    // rechecking it keeps the actor inside this control path,
                    // so the regular `prepare_resume` helper is not reached
                    // when the job is resumed here.
                    self.restart_tracker_session();
                    if let Some(reply) = reply {
                        // Recheck already owns the durable `Checking` state;
                        // acknowledge the control request without waiting for
                        // the current verification pass to finish.
                        let _ = reply.send(Ok(()));
                    }
                }
                Ok(TorrentCmd::Reannounce) => {
                    self.schedule_active_tracker_tier_now();
                }
                Ok(TorrentCmd::ReloadFilePolicy { reply }) => {
                    let result = self.apply_file_policy_from_db().await;
                    if let Err(error) = &result {
                        warn!(
                            component = "torrent",
                            operation = "reload_file_policy",
                            torrent = %self.info_hash_hex,
                            result = "error",
                            error = %error,
                            "failed to reload persisted file policy during recheck; retaining the active policy"
                        );
                    }
                    if let Some(reply) = reply {
                        let _ = reply.send(result);
                    }
                }
                Ok(TorrentCmd::UpdateLimits { limits, reply }) => {
                    let result = self.apply_torrent_limits(&limits).await;
                    if let Err(error) = &result {
                        warn!(
                            component = "torrent",
                            operation = "update_limits",
                            torrent = %self.info_hash_hex,
                            result = "error",
                            error = %error,
                            "failed to apply persisted torrent limits during recheck"
                        );
                    }
                    if let Some(reply) = reply {
                        let _ = reply.send(result);
                    }
                }
                Ok(TorrentCmd::UpdateTrackers { trackers, reply }) => {
                    let result = self.apply_tracker_urls(trackers).await;
                    if let Err(error) = &result {
                        warn!(
                            component = "torrent",
                            operation = "update_trackers",
                            torrent = %self.info_hash_hex,
                            result = "error",
                            error = %error,
                            "failed to apply updated tracker URLs during recheck"
                        );
                    }
                    if let Some(reply) = reply {
                        let _ = reply.send(result);
                    }
                }
                Ok(TorrentCmd::UpdatePeerExchange(enabled)) => {
                    self.pex_enabled = enabled;
                }
                Ok(TorrentCmd::Recheck { job_id }) => {
                    if let Some(job_id) = job_id {
                        if active_job_id.is_none() {
                            // Startup/resume rechecks normally have no durable
                            // job. If an explicit recheck is queued while one
                            // of those scans is still running, adopt its job
                            // identity so the scan completes the job instead
                            // of silently discarding the command.
                            *active_job_id = Some(job_id);
                        } else if active_job_id.as_deref() != Some(job_id.as_str()) {
                            debug!(
                                torrent = %self.info_hash_hex,
                                active_job_id = ?active_job_id,
                                queued_job_id = %job_id,
                                "ignoring recheck command for a different active job"
                            );
                        }
                    }
                }
                Ok(TorrentCmd::CancelJob { job_id }) => {
                    if active_job_id.as_deref() != Some(job_id.as_str()) {
                        debug!(
                            torrent = %self.info_hash_hex,
                            job_id,
                            active_job_id = ?active_job_id,
                            "ignoring cancellation for an inactive recheck job"
                        );
                        continue;
                    }
                    debug!(
                        torrent = %self.info_hash_hex,
                        job_id,
                        "cancelling recheck job"
                    );
                    return Some(RecheckOutcome::Cancelled);
                }
                Ok(TorrentCmd::NewPeers(_)) => {}
                Ok(TorrentCmd::PriorityPeers(_)) => {}
                Ok(TorrentCmd::BanPeer(peer)) => {
                    self.evict_peer(peer).await;
                }
                Ok(TorrentCmd::EvictBannedPeers) => {
                    self.evict_banned_peers().await;
                }
                Ok(TorrentCmd::GetPeers { reply }) => {
                    let _ = reply.send(Vec::new());
                }
                Ok(TorrentCmd::GetPeerSnapshotCount { reply }) => {
                    let _ = reply.send(0);
                }
                Ok(TorrentCmd::GetPeerSnapshots { reply, .. }) => {
                    let _ = reply.send(Ok(Vec::new()));
                }
                Ok(TorrentCmd::GetWebseeds { reply }) => {
                    let _ = reply.send(self.webseed_snapshots());
                }
                Ok(TorrentCmd::GetRuntimeStats { reply }) => {
                    let _ = reply.send(self.runtime_stats());
                }
                Ok(TorrentCmd::GetPeerSummary { reply }) => {
                    let _ = reply.send(self.peer_stats());
                }
                Ok(TorrentCmd::AcceptPeer { .. }) => {}
                Ok(TorrentCmd::AcceptUtpPeer { .. }) => {}
                Ok(TorrentCmd::QuiesceForStorageMove { reply }) => {
                    let was_paused = self.paused;
                    self.paused = true;
                    self.cancel_tracker_announces();
                    self.shutdown_peers().await;
                    if let Err(error) = self.set_state_checked(TorrentState::Paused).await {
                        self.paused = was_paused;
                        if !was_paused {
                            self.restart_tracker_session();
                        }
                        let _ = reply.send(Err(format!(
                            "failed to persist torrent quiesce state: {error}"
                        )));
                        continue;
                    }
                    let _ = reply.send(Ok(was_paused));
                    await_stopped_announce_or_queue_command(self, cmd_rx, pending_command).await;
                    return Some(RecheckOutcome::Paused {
                        reply: None,
                        previous_paused: was_paused,
                        previous_restore_state: self.recheck_restore_state,
                        state_persisted: true,
                    });
                }
                Ok(TorrentCmd::ResumeAfterStorageMove {
                    new_save_root,
                    resume_paused,
                    reply,
                }) => {
                    if let Some(new_root) = new_save_root {
                        self.save_root = new_root.clone();
                        self.storage = MountScheduler::new_for_path(
                            StorageRootId::new(),
                            &new_root,
                            &SchedulerConfig {
                                profile: StorageProfile::Unknown,
                                resources: Some(self.resources.clone()),
                                storage_io: self.storage.io_config().clone(),
                                ..Default::default()
                            },
                        );
                        lock_prepared_files(&self.prepared_files).clear();
                    }
                    self.paused = resume_paused;
                    self.recheck_restore_state = resume_paused.then_some(TorrentState::Paused);
                    if !resume_paused {
                        self.restart_tracker_session();
                        self.webseed_wake_notify.notify_one();
                    }
                    let _ = reply.send(Ok(()));
                }
                Err(tokio::sync::mpsc::error::TryRecvError::Empty) => return None,
                Err(tokio::sync::mpsc::error::TryRecvError::Disconnected) => {
                    return Some(RecheckOutcome::Shutdown);
                }
            }
        }
    }

    async fn restore_fastresume(&mut self) -> bool {
        let mut state = match self.fastresume.load(&self.info_hash_hex) {
            Ok(state) => state,
            Err(rt_fastresume::FastresumeError::NotFound) => {
                debug!(
                    component = "fastresume",
                    operation = "load",
                    torrent = %self.info_hash_hex,
                    result = "not_found",
                    "no fastresume state"
                );
                return false;
            }
            Err(e) => {
                warn!(
                    component = "fastresume",
                    operation = "load",
                    torrent = %self.info_hash_hex,
                    result = "error",
                    error = %e,
                    "failed to load fastresume state"
                );
                return false;
            }
        };

        if let Err(e) = state.validate(&self.meta.info_hash, self.meta.pieces.len() as u32) {
            warn!(
                component = "fastresume",
                operation = "validate",
                torrent = %self.info_hash_hex,
                result = "error",
                error = %e,
                "discarding incompatible fastresume state"
            );
            return false;
        }

        let settings = self.crash_safety.settings();
        let location = self.crash_safety.for_location(&self.save_root);
        let previous_run = self.crash_safety.previous_run();
        let saved_this_run = state.durability.saved_by_run_id != 0
            && state.durability.saved_by_run_id == self.crash_safety.run_id();
        let state_was_clean = state.clean_shutdown;
        if previous_run.may_be_host_crash() && !saved_this_run {
            let inputs = RecoveryInputs {
                previous_run,
                crash_reference_unix: self.crash_safety.assessment().crash_reference_unix,
                now_unix: crash_safety::unix_seconds(),
                policy: crash_safety::recovery_policy(location.resolved.host_crash_recovery),
                recent_window_secs: settings.recent_write_window_secs,
                mount_trust: location.trust,
                weak_mount_escalation: settings.weak_mount_escalation,
                state_synced: state.durability.synced,
                last_data_write_unix: state.durability.last_data_write_unix,
                completed_unix: self.registry_completed_at().await,
                state_saved_this_run: saved_this_run,
            };
            if let RecoveryAction::Recheck(reason) = decide_recovery(&inputs) {
                warn!(
                    component = "fastresume",
                    operation = "crash_recovery",
                    torrent = %self.info_hash_hex,
                    previous_run = previous_run.as_str(),
                    reason = reason.as_str(),
                    mount_trust = location.trust.as_str(),
                    "discarding resume state after a possible host crash; the torrent will be rechecked"
                );
                self.crash_safety.record_recovery_recheck(reason);
                self.recovery_recheck_reason = Some(reason);
                self.append_torrent_event(
                    "crash_recovery_recheck",
                    "resume state discarded after an unclean host shutdown; rechecking",
                    serde_json::json!({
                        "level": "warn",
                        "reason": reason.as_str(),
                        "previous_run": previous_run.as_str(),
                        "mount_trust": location.trust.as_str(),
                    }),
                )
                .await;
                return false;
            }
        }

        if !state.clean_shutdown {
            match state.apply_unclean_shutdown_watermark() {
                Some(downgraded) => {
                    warn!(
                        torrent = %self.info_hash_hex,
                        downgraded,
                        "fastresume had unclean shutdown; applying bounded dirty-piece recheck watermark"
                    );
                }
                None => {
                    warn!(
                        torrent = %self.info_hash_hex,
                        "discarding unclean fastresume state without durability watermark"
                    );
                    return false;
                }
            }
        }

        let hints = collect_file_hints(&self.save_root, &self.meta);
        let invalidated = state.apply_file_hints(hints, &self.piece_map);
        if invalidated > 0 {
            warn!(
                torrent = %self.info_hash_hex,
                invalidated,
                "fastresume file hints changed"
            );
        }

        if should_audit_allocation(
            crash_safety::audit_policy(location.resolved.structural_audit),
            previous_run,
            state_was_clean,
            saved_this_run,
        ) {
            let (downgraded, unsupported_files) = self.audit_allocation(&mut state).await;
            self.crash_safety
                .record_audit(u64::from(downgraded), unsupported_files);
            if downgraded > 0 {
                warn!(
                    component = "fastresume",
                    operation = "allocation_audit",
                    torrent = %self.info_hash_hex,
                    downgraded,
                    "pieces overlapping unwritten or hole extents were downgraded for re-verification"
                );
                self.append_torrent_event(
                    "allocation_audit_downgraded",
                    "pieces overlapping unwritten or hole extents will be re-verified",
                    serde_json::json!({ "level": "warn", "pieces": downgraded }),
                )
                .await;
            }
        }
        self.last_data_write_unix.store(
            state.durability.last_data_write_unix,
            std::sync::atomic::Ordering::Relaxed,
        );

        for (piece, piece_state) in state.pieces.iter().copied().enumerate() {
            match piece_state {
                PieceState::Valid => {
                    self.picker.mark_have(piece);
                    let actions = self.transfer_ledger.mark_have(piece as u32);
                    self.apply_transfer_actions(actions);
                    self.transfer_piece_memory_leases.remove(&(piece as u32));
                }
                PieceState::Invalid | PieceState::Missing | PieceState::Unknown => {
                    self.picker.reject_piece(piece);
                    let (_, actions) = self.transfer_ledger.piece_failed_with_actions(piece as u32);
                    self.apply_transfer_actions(actions);
                    self.transfer_piece_memory_leases.remove(&(piece as u32));
                }
            }
        }
        for partial in &state.partial_pieces {
            self.restore_partial_transfer_state(partial.piece, &partial.received_blocks);
        }

        {
            let mut reg = self.registry.write().await;
            if let Some(mut entry) = reg.get_mut(&self.info_hash_hex) {
                entry.stats.uploaded = state.uploaded_bytes;
                entry.stats.downloaded = state.downloaded_bytes;
                entry.total_length = self.meta.total_length();
                entry.amount_left = self.reported_bytes_left();
                entry.finalizing = self.is_finalizing();
            };
        }

        // Fastresume is the piece/block trust source; the SQLite row is a
        // runtime/API projection. Startup recheck and the state publication
        // below rebuild that projection from validated payload state instead
        // of treating a stale database amount_left as proof of content.

        if state.file_hints.is_empty() {
            self.save_fastresume(false).await;
        }

        info!(
            torrent = %self.info_hash_hex,
            valid = state.valid_piece_count(),
            unknown = state.unknown_piece_count(),
            "fastresume restored"
        );
        true
    }

    #[cfg(test)]
    async fn write_block(&mut self, block: &BlockEvent) -> anyhow::Result<()> {
        self.write_block_inner(block, None).await
    }

    fn transfer_io_context(&self) -> TransferIoContext {
        TransferIoContext {
            meta: Arc::clone(&self.meta),
            piece_map: Arc::clone(&self.piece_map),
            save_root: self.save_root.clone(),
            storage: self.storage.clone(),
            prepared_files: Arc::clone(&self.prepared_files),
            prepared_file_locks: Arc::clone(&self.prepared_file_locks),
            resources: self.resources.clone(),
        }
    }

    async fn write_leased_block(&mut self, event: &LeasedBlockEvent) -> anyhow::Result<()> {
        self.write_block_inner(&event.block, event._memory_lease.clone())
            .await
    }

    async fn write_block_inner(
        &mut self,
        block: &BlockEvent,
        shared_payload_lease: Option<Arc<MemoryLease>>,
    ) -> anyhow::Result<()> {
        let block_len = u32::try_from(block.data.len())
            .map_err(|_| anyhow::anyhow!("peer block length does not fit in u32"))?;
        self.piece_map.validate_request_block(BlockExtent::new(
            block.piece,
            block.offset,
            block_len,
        ))?;
        let piece_map = Arc::clone(&self.piece_map);
        let regions = piece_map.request_regions(block.piece, block.offset, block_len)?;
        let mut data_offset = 0usize;

        for region in regions {
            let region_len = usize::try_from(region.length)
                .map_err(|_| anyhow::anyhow!("piece region length does not fit in memory"))?;
            let start = data_offset;
            let end = start
                .checked_add(region_len)
                .ok_or_else(|| anyhow::anyhow!("piece region data offset overflow"))?;
            let region_data = block
                .data
                .get(start..end)
                .ok_or_else(|| anyhow::anyhow!("peer block does not cover mapped piece regions"))?;
            if region.pad {
                if region_data.iter().any(|byte| *byte != 0) {
                    anyhow::bail!("peer block contains non-zero bytes for BEP 47 padding");
                }
                data_offset = end;
                continue;
            }
            let path = region.path.resolve(&self.save_root);
            self.prepare_file_once(region.file_index, &path, region.file_length)
                .await?;
            data_offset = end;
            match shared_payload_lease.as_ref() {
                Some(lease) => {
                    scheduled_write_with_shared_payload_lease(
                        &self.storage,
                        IoClass::PeerWrite,
                        &path,
                        region.file_offset,
                        block.data.slice(start..end),
                        true,
                        Arc::clone(lease),
                    )
                    .await?;
                }
                None => {
                    self.resources.record_payload_copy(
                        PayloadCopyPath::PeerFileSegment,
                        region_data.len() as u64,
                    );
                    scheduled_write(
                        &self.storage,
                        IoClass::PeerWrite,
                        &path,
                        region.file_offset,
                        bytes::Bytes::copy_from_slice(region_data),
                        true,
                    )
                    .await?;
                }
            }
        }

        if data_offset != block.data.len() {
            anyhow::bail!("mapped piece regions do not cover the peer block");
        }
        self.note_data_write();
        Ok(())
    }

    #[allow(dead_code)]
    async fn write_completed_piece(&mut self, piece: u32) -> anyhow::Result<()> {
        let (data, payload_lease) = self
            .piece_assemblies
            .get(&piece)
            .filter(|assembly| assembly.is_complete())
            .and_then(|assembly| {
                Some((
                    assembly.completed_data.as_ref()?.clone(),
                    assembly._memory_lease.clone(),
                ))
            })
            .ok_or_else(|| anyhow::anyhow!("piece {piece} is not fully assembled"))?;
        let regions = self.piece_map.piece_to_file_regions(piece)?;
        for region in regions {
            if region.pad {
                continue;
            }
            let (path, file_length) = self
                .meta
                .files
                .iter()
                .find(|file| file.index == region.file_index)
                .map(|file| (file.path.resolve(&self.save_root), file.length))
                .ok_or_else(|| anyhow::anyhow!("file index {} out of range", region.file_index))?;
            self.prepare_file_once(region.file_index, &path, file_length)
                .await?;
            let start = usize::try_from(region.piece_offset)
                .map_err(|_| anyhow::anyhow!("piece region offset does not fit in memory"))?;
            let region_len = usize::try_from(region.length)
                .map_err(|_| anyhow::anyhow!("piece region length does not fit in memory"))?;
            let end = start
                .checked_add(region_len)
                .ok_or_else(|| anyhow::anyhow!("piece region data offset overflow"))?;
            anyhow::ensure!(
                data.get(start..end).is_some(),
                "piece assembly does not cover mapped region"
            );
            let region_data = data.slice(start..end);
            match payload_lease.as_ref() {
                Some(lease) => {
                    scheduled_write_with_shared_payload_lease(
                        &self.storage,
                        IoClass::PeerWrite,
                        &path,
                        region.file_offset,
                        region_data,
                        true,
                        Arc::clone(lease),
                    )
                    .await?;
                }
                None => {
                    scheduled_write(
                        &self.storage,
                        IoClass::PeerWrite,
                        &path,
                        region.file_offset,
                        region_data,
                        true,
                    )
                    .await?;
                }
            }
        }
        self.note_data_write();
        Ok(())
    }

    async fn prepare_file_once(
        &mut self,
        file_index: u32,
        path: &std::path::Path,
        len: u64,
    ) -> anyhow::Result<()> {
        prepare_file_once_with_locks(
            &self.storage,
            &self.prepared_files,
            &self.prepared_file_locks,
            file_index,
            path,
            len,
        )
        .await?;
        Ok(())
    }

    async fn verify_piece(&mut self, piece: u32) -> VerifyResult {
        let verifier = PieceVerifier::new(
            &self.save_root,
            &self.storage,
            &self.piece_map,
            &self.meta.pieces,
        );
        match &self.hybrid_v2 {
            Some(meta) => match meta.piece_expectation(piece) {
                Some(expectation) => verifier.verify_hybrid_piece(piece, &expectation).await,
                None => VerifyResult::Missing {
                    file_index: 0,
                    reason: format!("no authenticated v2 file range for hybrid piece {piece}"),
                },
            },
            None => verifier.verify_piece(piece).await,
        }
    }

    #[cfg(test)]
    async fn verify_completed_piece(&mut self, piece: u32) -> VerifyResult {
        if let Some(assembly) = self
            .piece_assemblies
            .get(&piece)
            .filter(|assembly| assembly.is_complete())
        {
            self.completed_piece_verify_from_memory =
                self.completed_piece_verify_from_memory.saturating_add(1);
            let Some(expected) = self.meta.pieces.get(piece as usize) else {
                return VerifyResult::Missing {
                    file_index: 0,
                    reason: format!("no hash for piece {piece}"),
                };
            };
            let Some(data) = assembly.completed_data.as_ref().cloned() else {
                return VerifyResult::Missing {
                    file_index: 0,
                    reason: format!("completed piece {piece} has no immutable payload"),
                };
            };
            let payload_lease = assembly._memory_lease.clone();
            if let Some(hybrid_v2) = &self.hybrid_v2 {
                let Some(expectation) = hybrid_v2.piece_expectation(piece) else {
                    return VerifyResult::Missing {
                        file_index: 0,
                        reason: format!("no authenticated v2 file range for hybrid piece {piece}"),
                    };
                };
                let Ok(piece_length) = usize::try_from(self.meta.piece_length) else {
                    return VerifyResult::Missing {
                        file_index: expectation.file_index,
                        reason: "hybrid piece length does not fit memory address space".to_owned(),
                    };
                };
                let Ok(v2_content_len) = usize::try_from(expectation.content_len) else {
                    return VerifyResult::Missing {
                        file_index: expectation.file_index,
                        reason: "hybrid content length does not fit memory address space"
                            .to_owned(),
                    };
                };
                let hashes = match payload_lease.as_ref() {
                    Some(lease) => {
                        self.storage
                            .hash_hybrid_piece_retry_queue_full_with_shared_payload_lease(
                                data,
                                v2_content_len,
                                piece_length,
                                Arc::clone(lease),
                            )
                            .await
                    }
                    None => {
                        self.storage
                            .hash_hybrid_piece_retry_queue_full(data, v2_content_len, piece_length)
                            .await
                    }
                };
                return match hashes {
                    Ok(hashes) if hashes.v1_sha1 == *expected => {
                        let actual_v2 = match expectation.piece_leaf_count {
                            Some(_) => hashes.v2_piece_root,
                            None => hashes.v2_file_root,
                        };
                        if actual_v2 == expectation.expected_root {
                            return VerifyResult::Valid;
                        }
                        VerifyResult::Invalid
                    }
                    Ok(_) => VerifyResult::Invalid,
                    Err(error) => VerifyResult::Missing {
                        file_index: expectation.file_index,
                        reason: error.to_string(),
                    },
                };
            }
            let hash = match payload_lease.as_ref() {
                Some(lease) => {
                    self.storage
                        .hash_sha1_retry_queue_full_with_shared_payload_lease(
                            data,
                            Arc::clone(lease),
                        )
                        .await
                }
                None => self.storage.hash_sha1_retry_queue_full(data).await,
            };
            match hash {
                Ok(actual) if &actual == expected => return VerifyResult::Valid,
                Ok(_) => return VerifyResult::Invalid,
                Err(e) => {
                    return VerifyResult::Missing {
                        file_index: 0,
                        reason: e.to_string(),
                    }
                }
            }
        }
        self.completed_piece_verify_from_disk =
            self.completed_piece_verify_from_disk.saturating_add(1);
        self.verify_piece(piece).await
    }

    fn piece_length(&self, piece: u32) -> anyhow::Result<u32> {
        if piece as usize >= self.meta.pieces.len() {
            anyhow::bail!("piece {piece} out of range");
        }
        let last = self.meta.pieces.len().saturating_sub(1) as u32;
        if piece == last {
            let total = self.meta.total_length();
            let rem = total % self.meta.piece_length;
            Ok(if rem == 0 {
                self.meta.piece_length as u32
            } else {
                rem as u32
            })
        } else {
            Ok(self.meta.piece_length as u32)
        }
    }

    async fn set_state_checked(&mut self, state: TorrentState) -> Result<(), String> {
        let (previous, row, state_event) = {
            let mut reg = self.registry.write().await;
            let Some(mut entry) = reg.get_mut(&self.info_hash_hex) else {
                return Err(format!(
                    "torrent {} is missing from the registry",
                    self.info_hash_hex
                ));
            };
            let previous = entry.clone();
            let previous_state = entry.state;
            if let Err(error) = entry.transition(state) {
                warn!(
                    component = "torrent",
                    operation = "transition_state",
                    torrent = %self.info_hash_hex,
                    state = %state,
                    result = "rejected",
                    error = %error,
                    "rejected invalid torrent state transition"
                );
                return Err(error.to_string());
            }
            entry.total_length = self.meta.total_length();
            entry.amount_left = self.reported_bytes_left();
            entry.finalizing = self.is_finalizing();
            if state == TorrentState::Seeding && entry.completed_at.is_none() {
                entry.amount_left = 0;
                entry.finalizing = false;
                entry.completed_at = Some(
                    SystemTime::now()
                        .duration_since(UNIX_EPOCH)
                        .unwrap_or_default()
                        .as_secs(),
                );
            }
            let row = crate::engine::row_from_v1_meta(&entry, &self.meta);
            let state_event = (previous_state != state).then(|| rt_db::SessionEventRow {
                event_id: None,
                occurred_at: db_i64(unix_now()),
                info_hash: Some(self.info_hash_hex.clone()),
                kind: "torrent_state_changed".to_owned(),
                message: Some("torrent runtime state changed".to_owned()),
                payload: serde_json::json!({
                    "from": previous_state.as_str(),
                    "to": state.as_str(),
                    "total_length": entry.total_length,
                    "amount_left": entry.amount_left,
                })
                .to_string(),
            });
            (previous, row, state_event)
        };
        let retention = self.event_retention;
        let persistence = self
            .db
            .run("persist_torrent_state", move |db| {
                let tx = db.transaction().map_err(|error| error.to_string())?;
                let updated =
                    rt_db::update_runtime_in_tx(&tx, &row).map_err(|error| error.to_string())?;
                if !updated {
                    return Err(format!(
                        "torrent {} is missing from the database",
                        row.info_hash
                    ));
                }
                if let Some(event) = state_event.as_ref() {
                    rt_db::append_session_event_in_tx(&tx, event)
                        .map_err(|error| error.to_string())?;
                    rt_db::prune_session_events_in_tx(&tx, retention)
                        .map_err(|error| error.to_string())?;
                }
                tx.commit().map_err(|error| error.to_string())
            })
            .await;
        if let Err(error) = persistence {
            if let Some(mut entry) = self.registry.write().await.get_mut(&self.info_hash_hex) {
                restore_runtime_projection(&mut entry, &previous);
            }
            warn!(
                component = "db",
                operation = "persist_torrent_state",
                torrent = %self.info_hash_hex,
                result = "error",
                error = %error,
                "failed to persist torrent state"
            );
            return Err(error);
        } else {
            // The timer is runtime state derived from the durable state. Do
            // not start/stop it before the transition and its database row
            // have both committed: a rejected transition or failed write
            // must leave seed-limit enforcement observing the old state.
            if state == TorrentState::Seeding {
                self.seeding_started_at.get_or_insert_with(Instant::now);
            } else {
                self.seeding_started_at = None;
            }
            self.transfer_stats_dirty = false;
        }
        Ok(())
    }

    async fn persist_progress(&mut self) {
        // This row is a coalesced runtime projection, not a payload
        // checkpoint. Piece trust is committed separately by fastresume only
        // after storage barrier evidence; restore derives this projection
        // again from validated fastresume/recheck state.
        let (previous, row) = {
            let mut reg = self.registry.write().await;
            let Some(mut entry) = reg.get_mut(&self.info_hash_hex) else {
                return;
            };
            let previous = entry.clone();
            entry.total_length = self.meta.total_length();
            entry.amount_left = self.reported_bytes_left();
            entry.finalizing = self.is_finalizing();
            let row = crate::engine::row_from_v1_meta(&entry, &self.meta);
            (previous, row)
        };
        let persistence = self
            .db
            // `run_batched`: the worker may commit this alongside other
            // torrents' queued progress writes in one shared transaction
            // instead of one fsync'd commit per torrent per tick — this is
            // the actual write-throughput ceiling at high torrent counts,
            // since every `TorrentTask` ticks and persists independently.
            .run_batched("persist_torrent_progress", move |tx| {
                let updated =
                    rt_db::update_runtime_in_tx(tx, &row).map_err(|error| error.to_string())?;
                if !updated {
                    return Err(format!(
                        "torrent {} is missing from the database",
                        row.info_hash
                    ));
                }
                Ok(())
            })
            .await;
        if let Err(error) = persistence {
            if let Some(mut entry) = self.registry.write().await.get_mut(&self.info_hash_hex) {
                restore_progress_projection(&mut entry, &previous);
            }
            warn!(
                component = "db",
                operation = "persist_torrent_progress",
                torrent = %self.info_hash_hex,
                result = "error",
                error = %error,
                "failed to persist torrent progress"
            );
        } else {
            self.transfer_stats_dirty = false;
        }
    }

    async fn persist_progress_throttled(&mut self, force: bool) {
        const PROGRESS_PERSIST_INTERVAL: Duration = Duration::from_secs(5);
        let now = Instant::now();
        if !force {
            match self.last_progress_persist {
                Some(last) if now.duration_since(last) < PROGRESS_PERSIST_INTERVAL => return,
                None => {
                    // Start the checkpoint interval on the first partial
                    // completion. Persisting here would make the transfer
                    // actor await a database commit and payload barrier
                    // before it can process the next peer command or block.
                    self.last_progress_persist = Some(now);
                    return;
                }
                Some(_) => {}
            }
        }
        self.last_progress_persist = Some(now);
        self.persist_progress().await;
        self.save_fastresume(false).await;
    }

    async fn persist_recheck_job_progress(
        &mut self,
        job_id: &str,
        next_piece: u32,
        verified_bytes: u64,
        invalid_pieces: &RecheckInvalidPieces,
        state: &str,
        message: Option<&str>,
    ) {
        let now = unix_now();
        let done = i64::from(next_piece.min(self.piece_map.piece_count));
        let byte_offset = self.verified_byte_offset(next_piece);
        let verified_bytes = db_i64(verified_bytes);
        let job_id = job_id.to_owned();
        let state = state.to_owned();
        let message = message.map(str::to_owned);
        let invalid_piece_count = invalid_pieces.total;
        let invalid_pieces = invalid_pieces.values.clone();
        let invalid_pieces_truncated = invalid_piece_count > rt_db::MAX_JOB_INVALID_PIECES;
        let log_job_id = job_id.clone();
        let log_state = state.clone();
        let persistence = self
            .db
            .run("persist_recheck_progress", move |db| {
                let mut job = rt_db::get_job(db, &job_id).map_err(|error| error.to_string())?;
                // A cancellation/failure/completion written by the engine
                // control path wins over any progress message already in
                // flight. Without this fence, a late actor write could
                // resurrect a terminal recheck job on the next snapshot.
                if job.finished_at.is_some()
                    || matches!(
                        job.state.as_str(),
                        JOB_STATE_CANCELLED | JOB_STATE_COMPLETED | JOB_STATE_FAILED
                    )
                {
                    return Ok(());
                }
                if job.state == JOB_STATE_CANCELLING
                    && state != JOB_STATE_CANCELLED
                    && state != JOB_STATE_COMPLETED
                {
                    // The engine has durably recorded a cancellation intent.
                    // Do not let a progress or completion write resurrect
                    // the job while the actor is still unwinding the scan.
                    return Ok(());
                }
                let cancellation_completed_after_request =
                    job.state == JOB_STATE_CANCELLING && state == JOB_STATE_COMPLETED;
                let state = if cancellation_completed_after_request {
                    JOB_STATE_CANCELLED.to_owned()
                } else {
                    state
                };
                let message = if cancellation_completed_after_request {
                    Some("recheck cancellation arrived after verification completed".to_owned())
                } else {
                    message
                };
                job.state = state.clone();
                job.done = done;
                job.checkpoint = done;
                job.piece_index = Some(done);
                job.byte_offset = Some(byte_offset);
                job.verified_bytes = verified_bytes;
                job.invalid_pieces = invalid_pieces.clone();
                job.updated_at = db_i64(now);
                if matches!(
                    state.as_str(),
                    JOB_STATE_CANCELLED | JOB_STATE_COMPLETED | JOB_STATE_FAILED
                ) {
                    job.finished_at = Some(db_i64(now));
                }
                let event = rt_db::JobEventRow {
                    event_id: None,
                    job_id: job_id.clone(),
                    occurred_at: db_i64(now),
                    kind: match state.as_str() {
                        JOB_STATE_CANCELLED => "check_cancelled",
                        JOB_STATE_COMPLETED => "check_completed",
                        JOB_STATE_FAILED => "check_failed",
                        _ => "check_progress",
                    }
                    .to_owned(),
                    message,
                    payload: serde_json::json!({
                        "piece_index": job.piece_index,
                        "verified_bytes": job.verified_bytes,
                        "invalid_piece_count": invalid_piece_count,
                        "invalid_pieces_truncated": invalid_pieces_truncated,
                        "invalid_pieces": job.invalid_pieces,
                        "state": state,
                    })
                    .to_string(),
                };
                let tx = db.transaction().map_err(|error| error.to_string())?;
                rt_db::upsert_job_in_tx(&tx, &job).map_err(|error| error.to_string())?;
                rt_db::append_job_event_in_tx(&tx, &event).map_err(|error| error.to_string())?;
                tx.commit().map_err(|error| error.to_string())
            })
            .await;
        if let Err(e) = persistence {
            warn!(
                component = "db",
                operation = "persist_recheck_progress_and_event",
                job_id = %log_job_id,
                state = %log_state,
                result = "error",
                error = %e,
                "failed to persist recheck progress and event atomically"
            );
        }
    }

    fn verified_byte_offset(&self, next_piece: u32) -> i64 {
        let bytes = (next_piece as u64).saturating_mul(self.meta.piece_length);
        db_i64(bytes.min(self.meta.total_length()))
    }

    /// Bytes left as shown to trackers and API consumers. A finished download
    /// still waiting for durability or read-back verification reports one byte,
    /// so nothing treats it as complete before its data is safe.
    fn reported_bytes_left(&self) -> u64 {
        let pending_verification_bytes = self
            .pending_transfer_pieces
            .iter()
            .filter(|(_, work)| {
                work.verify_ready || work.verify_in_flight || work.aggregate_write_ready
            })
            .filter_map(|(&piece, _)| self.piece_length(piece).ok())
            .map(u64::from)
            .fold(0u64, u64::saturating_add);
        let left = self
            .picker
            .bytes_left()
            .saturating_add(pending_verification_bytes);
        if left == 0 && self.is_finalizing() {
            1
        } else {
            left
        }
    }

    /// The download is complete on disk but held until its data is durable
    /// and any read-back verification has passed. Published to the registry as
    /// `TorrentEntry::finalizing` next to every `amount_left` update.
    fn is_finalizing(&self) -> bool {
        self.picker.bytes_left() == 0
            && (self.completion_gate.is_some() || self.completion_verifying)
    }

    fn note_data_write(&self) {
        self.last_data_write_unix.store(
            crash_safety::unix_seconds(),
            std::sync::atomic::Ordering::Relaxed,
        );
    }

    async fn registry_completed_at(&mut self) -> Option<u64> {
        self.registry
            .read()
            .await
            .get(&self.info_hash_hex)
            .and_then(|entry| entry.completed_at)
    }

    /// Append a per-torrent event to the session event log. Best effort: a
    /// failed append is logged and never affects the torrent.
    async fn append_torrent_event(
        &mut self,
        kind: &'static str,
        message: &str,
        payload: serde_json::Value,
    ) {
        let event = rt_db::SessionEventRow {
            event_id: None,
            occurred_at: db_i64(unix_now()),
            info_hash: Some(self.info_hash_hex.clone()),
            kind: kind.to_owned(),
            message: Some(message.to_owned()),
            payload: payload.to_string(),
        };
        let retention = self.event_retention;
        let result = self
            .db
            .run("append_torrent_event", move |db| {
                let tx = db.transaction().map_err(|error| error.to_string())?;
                rt_db::append_session_event_in_tx(&tx, &event)
                    .map_err(|error| error.to_string())?;
                rt_db::prune_session_events_in_tx(&tx, retention)
                    .map_err(|error| error.to_string())?;
                tx.commit().map_err(|error| error.to_string())
            })
            .await;
        if let Err(error) = result {
            debug!(
                component = "db",
                operation = "append_torrent_event",
                torrent = %self.info_hash_hex,
                kind,
                error = %error,
                "could not record torrent event"
            );
        }
    }

    /// The last piece just verified: decide how the download completes.
    ///
    /// With the completion gate (default) the torrent is held at "one byte
    /// left" until the payload is durable and any configured read-back
    /// verification has passed; only then does it become `Seeding`, tell the
    /// tracker `completed`, and stamp `completed_at`.
    async fn on_download_complete(&mut self) {
        let location = self.crash_safety.for_location(&self.save_root);
        if !location.resolved.completion_gate
            && location.completion_verify == rt_config::CompletionVerifyMode::Off
        {
            // Gate disabled by the operator for this location: the historical
            // behavior.
            self.persist_progress_throttled(true).await;
            self.save_fastresume(false).await;
            self.finish_completion().await;
            return;
        }
        if self.completion_gate.is_none() {
            self.completion_gate = Some(CompletionGate::new(Arc::clone(&self.crash_safety)));
            // Publish the one-byte-remaining projection before anything slow.
            self.persist_progress().await;
        }
        if let GateStep::Verify(plan) = self.advance_completion_gate().await {
            self.completion_verify_plan = Some(plan);
        }
    }

    /// Try to satisfy the completion gate: run the payload barrier, then
    /// either release the completion or hand off to read-back verification.
    async fn advance_completion_gate(&mut self) -> GateStep {
        if !self.picker.is_complete() {
            // A piece was rejected (recheck, failed verification): the
            // download is not finished after all.
            self.completion_gate = None;
            self.persist_progress().await;
            return GateStep::Dropped;
        }
        let attempts = match self.completion_gate.as_mut() {
            None => return GateStep::Dropped,
            Some(gate) if Instant::now() < gate.next_attempt => return GateStep::Pending,
            Some(gate) => {
                gate.attempts += 1;
                gate.attempts
            }
        };
        if attempts > 1 {
            self.crash_safety.record_gate_retry();
        }
        let outcome = self.save_fastresume_with(false, true).await;
        if !outcome.releases_completion() {
            if let Some(gate) = self.completion_gate.as_mut() {
                gate.schedule_retry();
            }
            warn!(
                component = "torrent",
                operation = "completion_gate",
                torrent = %self.info_hash_hex,
                attempts,
                barrier = ?outcome.barrier,
                persisted = outcome.persisted,
                "download complete but its data is not yet durable; holding completion and retrying"
            );
            if attempts == 1 {
                self.append_torrent_event(
                    "completion_deferred",
                    "download complete but not yet durable; completion is held until storage confirms",
                    serde_json::json!({
                        "level": "warn",
                        "barrier": format!("{:?}", outcome.barrier),
                        "fastresume_persisted": outcome.persisted,
                    }),
                )
                .await;
            }
            return GateStep::Pending;
        }

        let location = self.crash_safety.for_location(&self.save_root);
        match location.completion_verify {
            rt_config::CompletionVerifyMode::Off => {
                self.finish_completion().await;
                GateStep::Released
            }
            rt_config::CompletionVerifyMode::Sample => GateStep::Verify(VerifyPlan::Sample),
            rt_config::CompletionVerifyMode::Full => GateStep::Verify(VerifyPlan::Full),
        }
    }

    /// Release a completed download: tell the tracker and become `Seeding`.
    async fn finish_completion(&mut self) {
        if let Some(gate) = self.completion_gate.take() {
            let attempts = gate.attempts;
            let waited_ms = gate.started.elapsed().as_millis() as u64;
            gate.release();
            if attempts > 1 {
                self.append_torrent_event(
                    "completion_released",
                    "completion released after storage confirmed the data is durable",
                    serde_json::json!({ "attempts": attempts, "waited_ms": waited_ms }),
                )
                .await;
            }
        }
        self.tracker_event = TrackerEvent::Completed;
        self.schedule_trackers_now();
        match self.set_state_checked(TorrentState::Seeding).await {
            Ok(()) => info!(
                component = "torrent",
                operation = "complete_download",
                torrent = %self.info_hash_hex,
                result = "ok",
                "download complete"
            ),
            Err(error) => {
                // `set_state_checked` rolled the registry back to Downloading
                // when its durable write failed. Keep the runtime on that same
                // active state; marking only the actor as paused would leave
                // the public projection claiming downloading while no task work
                // was possible.
                self.paused = false;
                self.recheck_restore_state = None;
                self.restart_tracker_session();
                Box::pin(self.shutdown_peers()).await;
                warn!(
                    component = "torrent",
                    operation = "complete_download",
                    torrent = %self.info_hash_hex,
                    result = "error",
                    error = %error,
                    "failed to persist seeding state; retaining downloading state"
                );
            }
        }
    }

    fn crash_safety_work_pending(&self) -> bool {
        self.completion_gate.is_some()
            || self.completion_verify_plan.is_some()
            || self.escalate_full_recheck
    }

    /// Advance queued crash-safety work that needs the command receiver: the
    /// completion gate's retry, the read-back verification it hands off to, and
    /// a full recheck escalated by a failed sample. Returns `false` when the
    /// task must stop (shutdown or an unrecoverable recheck failure).
    async fn drive_crash_safety(
        &mut self,
        cmd_rx: &mut mpsc::Receiver<TorrentCmd>,
        pending_command: &mut Option<TorrentCmd>,
    ) -> bool {
        if self.paused {
            return true;
        }
        if self.completion_gate.is_some() {
            if let GateStep::Verify(plan) = self.advance_completion_gate().await {
                self.completion_verify_plan = Some(plan);
            }
        }
        if let Some(plan) = self.completion_verify_plan.take() {
            self.begin_completion_verification(plan).await;
        } else if self.escalate_full_recheck {
            self.escalate_full_recheck = false;
        } else {
            return true;
        }
        match self
            .run_recheck_with_receiver(cmd_rx, pending_command, None)
            .await
        {
            RecheckOutcome::Shutdown => false,
            RecheckOutcome::Failed(error) => {
                warn!(
                    component = "torrent",
                    operation = "completion_verify",
                    torrent = %self.info_hash_hex,
                    result = "error",
                    error = %error,
                    "verification recheck failed; stopping task"
                );
                false
            }
            RecheckOutcome::Complete
            | RecheckOutcome::Paused { .. }
            | RecheckOutcome::Cancelled => true,
        }
    }

    /// Set up the recheck that reads a finished download back from disk.
    async fn begin_completion_verification(&mut self, plan: VerifyPlan) {
        if let Some(gate) = self.completion_gate.take() {
            gate.release();
        }
        let sample_percent = self
            .crash_safety
            .for_location(&self.save_root)
            .resolved
            .completion_verify_sample_percent;
        self.recheck_subset = match plan {
            VerifyPlan::Full => None,
            VerifyPlan::Sample => {
                let files: Vec<(u32, u64, bool)> = self
                    .meta
                    .files
                    .iter()
                    .map(|file| (file.index, file.length, file.pad))
                    .collect();
                let mut seed_bytes = [0u8; 8];
                for (slot, byte) in seed_bytes.iter_mut().zip(self.meta.info_hash.iter()) {
                    *slot = *byte;
                }
                select_completion_sample(
                    &self.piece_map,
                    &files,
                    sample_percent,
                    u64::from_le_bytes(seed_bytes),
                )
            }
        };
        self.completion_verifying = true;
        // Best effort: make the read-back come from the device, not RAM.
        let mut dropped = 0usize;
        for file in &self.meta.files {
            let path = file.path.resolve(&self.save_root);
            if self.storage.drop_page_cache(&path).await {
                dropped += 1;
            }
        }
        debug!(
            component = "torrent",
            operation = "completion_verify",
            torrent = %self.info_hash_hex,
            plan = ?plan,
            sampled_pieces = self.recheck_subset.as_ref().map(Vec::len),
            page_cache_dropped_files = dropped,
            "starting read-back verification of the completed download"
        );
    }

    /// Record what a recheck found: completion-verification results and, for a
    /// torrent that had already been reported complete, an integrity
    /// regression (with the affected paths so an operator or automation can
    /// act on copies made before the damage was known).
    async fn report_recheck_outcome(
        &mut self,
        invalid: &RecheckInvalidPieces,
        valid: usize,
        previously_completed: bool,
        verification_run: bool,
        sampled: bool,
        trigger: &'static str,
    ) {
        let checked = valid.saturating_add(invalid.total);
        if verification_run {
            self.crash_safety
                .record_completion_verify(checked as u64, invalid.total as u64);
            if invalid.total == 0 {
                self.append_torrent_event(
                    "completion_verified",
                    "completed download was read back from disk and verified",
                    serde_json::json!({
                        "mode": if sampled { "sample" } else { "full" },
                        "pieces_checked": checked,
                    }),
                )
                .await;
            } else {
                // Storage returned data that does not match what was written.
                // A failed sample is evidence enough to check everything.
                self.escalate_full_recheck = sampled;
                self.append_torrent_event(
                    "completion_verify_failed",
                    "read-back verification found data that does not match; the bad pieces will be downloaded again",
                    serde_json::json!({
                        "level": "error",
                        "mode": if sampled { "sample" } else { "full" },
                        "pieces_checked": checked,
                        "invalid_pieces": invalid.total,
                    }),
                )
                .await;
            }
        }
        if previously_completed && invalid.total > 0 {
            let sample: Vec<i64> = invalid
                .values
                .iter()
                .copied()
                .take(MAX_REGRESSION_SAMPLE_PIECES)
                .collect();
            let mut files: Vec<String> = Vec::new();
            for piece in &sample {
                let Ok(regions) = self.piece_map.piece_to_file_regions(*piece as u32) else {
                    continue;
                };
                for region in regions {
                    let Some(file) = self
                        .meta
                        .files
                        .iter()
                        .find(|file| file.index == region.file_index)
                    else {
                        continue;
                    };
                    let path = file.path.resolve(&self.save_root).display().to_string();
                    if files.len() < MAX_REGRESSION_FILES && !files.contains(&path) {
                        files.push(path);
                    }
                }
            }
            self.crash_safety.record_integrity_regression();
            warn!(
                component = "torrent",
                operation = "integrity_regression",
                torrent = %self.info_hash_hex,
                trigger,
                invalid_pieces = invalid.total,
                "a torrent already reported complete has pieces that no longer match; repairing in place"
            );
            self.append_torrent_event(
                "integrity_regression",
                "a completed torrent has pieces that no longer verify; missing data will be downloaded again in place",
                serde_json::json!({
                    "level": "error",
                    "trigger": trigger,
                    "invalid_pieces": invalid.total,
                    "sample_pieces": sample,
                    "affected_files": files,
                    "note": "repair rewrites the existing files in place, so hardlinks to them are healed; copies made earlier are not",
                }),
            )
            .await;
        }
    }

    /// Downgrade `Valid` pieces that overlap a hole or unwritten extent of any
    /// file, so they are re-hashed instead of trusted. Returns the pieces
    /// downgraded and the files whose filesystem could not report allocation.
    async fn audit_allocation(&mut self, state: &mut FastresumeState) -> (u32, u64) {
        let files: Vec<(u32, PathBuf, u64)> = self
            .meta
            .files
            .iter()
            .filter(|file| !file.pad && file.length > 0)
            .map(|file| (file.index, file.path.resolve(&self.save_root), file.length))
            .collect();
        if files.is_empty() {
            return (0, 0);
        }
        let piece_map = Arc::clone(&self.piece_map);
        let audited =
            tokio::task::spawn_blocking(move || audit_files_blocking(&piece_map, files)).await;
        match audited {
            Ok((ranges, unsupported)) => (state.distrust_piece_ranges(&ranges), unsupported),
            Err(error) => {
                warn!(
                    component = "fastresume",
                    operation = "allocation_audit",
                    torrent = %self.info_hash_hex,
                    error = %error,
                    "allocation audit task failed; continuing without it"
                );
                (0, 0)
            }
        }
    }

    async fn save_fastresume(&mut self, full_verify: bool) -> SaveOutcome {
        self.save_fastresume_with(full_verify, false).await
    }

    /// The final save before this task exits (orderly shutdown, demotion to
    /// dormant). It always runs a real payload barrier, even in `fast`
    /// durability mode: the run marker will call a clean exit "clean", and a
    /// clean exit must mean the data is on disk, not merely in the page cache
    /// of a machine that might lose power a moment later.
    async fn save_fastresume_for_exit(&mut self) -> SaveOutcome {
        self.save_fastresume_with(false, true).await
    }

    /// Write the fastresume record. With `force_sync`, the payload fsync
    /// barrier runs even in `fast` durability mode (the completion gate needs
    /// a real barrier regardless of mode).
    async fn save_fastresume_with(&mut self, full_verify: bool, force_sync: bool) -> SaveOutcome {
        let durable_assembly_pieces = self.flush_piece_assemblies_to_disk().await;
        let (uploaded, downloaded) = self.transfer_snapshot().await;
        let mut state = FastresumeState::new_empty(
            &self.meta.info_hash,
            self.meta.pieces.len() as u32,
            ImportPolicy::RequireVerification,
        );
        for (piece, piece_state) in state.pieces.iter_mut().enumerate() {
            *piece_state = if self.picker.have_piece(piece) {
                PieceState::Valid
            } else {
                PieceState::Unknown
            };
        }
        state.partial_pieces = self
            .picker
            .partial_pieces_limited(MAX_FASTRESUME_BLOCKS_PER_PARTIAL_PIECE)
            .into_iter()
            .filter(|(piece, _)| {
                !self.pending_transfer_pieces.get(piece).is_some_and(|work| {
                    work.verify_ready || work.verify_in_flight || work.aggregate_write_ready
                }) && (!self.piece_assemblies.contains_key(piece)
                    || durable_assembly_pieces.contains(piece))
            })
            .map(|(piece, received_blocks)| PartialPieceState {
                piece,
                received_blocks,
            })
            .collect();
        state.uploaded_bytes = uploaded;
        state.downloaded_bytes = downloaded;
        if self.dirty_pieces_since_barrier.is_overflowed() {
            // An empty watermark with clean_shutdown=false is intentional:
            // the loader treats it as unverifiable and performs a full
            // recheck instead of trusting an incomplete dirty-piece list.
            warn!(
                component = "fastresume",
                operation = "save",
                torrent = %self.info_hash_hex,
                result = "watermark_overflow",
                maximum = MAX_RUNTIME_DIRTY_PIECES,
                "dirty-piece watermark exceeded its live bound; an unclean save will require a full recheck"
            );
        } else {
            state.set_dirty_pieces_since_barrier(
                self.dirty_pieces_since_barrier.pieces.iter().copied(),
            );
        }
        let (mut barrier, evidence) = self.run_barrier(force_sync).await;
        let mut evidence = if barrier == BarrierOutcome::Synced {
            evidence
        } else {
            drop(evidence);
            None
        };
        match barrier {
            BarrierOutcome::Synced if evidence.is_some() => {
                self.dirty_pieces_since_barrier.clear();
            }
            BarrierOutcome::Synced => {
                // Never let an impossible missing proof turn a successful
                // status into trusted fast-resume state.
                state.mark_saved_without_data_sync();
                state.clean_shutdown = false;
                barrier = BarrierOutcome::Failed;
            }
            // No data fsync happened (by configuration, or because this
            // filesystem cannot). The state is still good after a clean
            // shutdown or a process crash, but the loader must not trust it
            // after a host crash.
            BarrierOutcome::SkippedFast | BarrierOutcome::Unsupported => {
                state.complete_without_data_sync();
                self.dirty_pieces_since_barrier.clear();
            }
            BarrierOutcome::Failed => {
                state.clean_shutdown = false;
            }
        }
        state.durability.boot_id = self.crash_safety.boot_id().map(str::to_owned);
        state.durability.saved_by_run_id = self.crash_safety.run_id();
        state.durability.last_data_write_unix = self
            .last_data_write_unix
            .load(std::sync::atomic::Ordering::Relaxed);
        state.file_hints = collect_file_hints(&self.save_root, &self.meta);
        if full_verify {
            state.last_full_verify = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs();
        }

        let save_result = match evidence.take() {
            Some(evidence) => {
                self.fastresume
                    .save_async_with_durability_evidence(state, evidence)
                    .await
            }
            None => self.fastresume.save_async(state).await,
        };
        let persisted = match save_result {
            Ok(()) => true,
            Err(e) => {
                warn!(
                    component = "fastresume",
                    operation = "save",
                    torrent = %self.info_hash_hex,
                    result = "error",
                    error = %e,
                    "failed to save fastresume state"
                );
                false
            }
        };
        SaveOutcome { barrier, persisted }
    }

    /// Flush payload data before a fastresume record may claim it.
    ///
    /// `fast` mode skips this unless `force` (the completion gate) demands it.
    /// A filesystem that cannot fsync at all is detected once, remembered, and
    /// reported as `Unsupported` instead of failing every save forever.
    async fn run_barrier(
        &mut self,
        force: bool,
    ) -> (
        BarrierOutcome,
        Option<rt_storage::DurabilityBarrierEvidence>,
    ) {
        if self.fsync_unsupported {
            return (BarrierOutcome::Unsupported, None);
        }
        if !force && self.storage.io_config().durability_mode == rt_storage::DurabilityMode::Fast {
            return (BarrierOutcome::SkippedFast, None);
        }
        match self.storage.sync_all_open_files_with_evidence().await {
            Ok(evidence) => (BarrierOutcome::Synced, Some(evidence)),
            Err(e) if e.is_operation_unsupported() => {
                self.fsync_unsupported = true;
                self.crash_safety.note_fsync_unsupported(&self.save_root);
                warn!(
                    component = "storage",
                    operation = "sync_before_fastresume",
                    torrent = %self.info_hash_hex,
                    result = "unsupported",
                    error = %e,
                    "this filesystem cannot fsync; durability is best effort and the mount is treated as weak"
                );
                (BarrierOutcome::Unsupported, None)
            }
            Err(e) => {
                warn!(
                    component = "storage",
                    operation = "sync_before_fastresume",
                    torrent = %self.info_hash_hex,
                    result = "error",
                    error = %e,
                    "failed to sync torrent files before fastresume save"
                );
                (BarrierOutcome::Failed, None)
            }
        }
    }

    /// Make partial in-memory assemblies durable before advertising their
    /// received block indexes in fastresume. A clean fastresume record that
    /// points at bytes which only existed in RAM would make the next process
    /// trust a partial piece that the disk does not contain.
    async fn flush_piece_assemblies_to_disk(&mut self) -> HashSet<u32> {
        let mut durable = HashSet::new();
        let pieces = self.piece_assemblies.keys().copied().collect::<Vec<_>>();
        for piece in pieces {
            let blocks = match self
                .piece_assemblies
                .get(&piece)
                .expect("piece key was collected from the assembly map")
                .received_blocks(&self.resources, piece)
            {
                Ok(blocks) => blocks,
                Err(error) => {
                    warn!(
                        component = "fastresume",
                        operation = "flush_piece_assembly",
                        torrent = %self.info_hash_hex,
                        piece,
                        result = "error",
                        error = %error,
                        "could not reserve memory for partial-piece flush"
                    );
                    continue;
                }
            };
            let mut success = true;
            for (offset, data) in blocks {
                if let Err(error) = self.write_leased_block(&data).await {
                    warn!(
                        component = "fastresume",
                        operation = "flush_piece_assembly",
                        torrent = %self.info_hash_hex,
                        piece,
                        offset,
                        result = "error",
                        error = %error,
                        "could not flush an in-memory partial piece before fastresume save"
                    );
                    success = false;
                    break;
                }
            }
            if success {
                durable.insert(piece);
            }
        }
        durable
    }
}

/// Resolve at `deadline`; callers guard on the deadline being set.
async fn sleep_until_download_rate(deadline: Option<Instant>) {
    if let Some(deadline) = deadline {
        tokio::time::sleep_until(TokioInstant::from_std(deadline)).await;
    }
}

fn reset_webseed_sleep(sleep: &mut Pin<Box<Sleep>>, delay: Duration) {
    sleep.as_mut().reset(tokio::time::Instant::now() + delay);
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum OutgoingTransportPolicy {
    Auto,
    TcpOnly,
    PreferUtp,
    UtpOnly,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum PeerSource {
    Tracker,
    Dht,
    PeerExchange,
    Manual,
}

pub(crate) fn outgoing_transport_policy_configured() -> OutgoingTransportPolicy {
    if let Ok(value) = std::env::var("TNG_UTP_OUTGOING") {
        return parse_outgoing_transport_policy(&value);
    }
    if std::env::var_os("TNG_ENABLE_UTP_OUTGOING").is_some() {
        return OutgoingTransportPolicy::PreferUtp;
    }
    OutgoingTransportPolicy::Auto
}

fn parse_outgoing_transport_policy(value: &str) -> OutgoingTransportPolicy {
    match value.trim().to_ascii_lowercase().as_str() {
        "" | "auto" | "default" => OutgoingTransportPolicy::Auto,
        "0" | "false" | "no" | "off" | "tcp" | "tcp-only" => OutgoingTransportPolicy::TcpOnly,
        "1" | "true" | "yes" | "prefer" | "prefer-utp" | "utp-prefer" => {
            OutgoingTransportPolicy::PreferUtp
        }
        "only" | "utp" | "utp-only" => OutgoingTransportPolicy::UtpOnly,
        _ => OutgoingTransportPolicy::Auto,
    }
}

pub(crate) fn outgoing_transport_policy_for_peer(
    configured: OutgoingTransportPolicy,
    source: PeerSource,
    private: bool,
) -> OutgoingTransportPolicy {
    if private {
        return OutgoingTransportPolicy::TcpOnly;
    }
    match configured {
        OutgoingTransportPolicy::Auto => match source {
            PeerSource::Tracker => OutgoingTransportPolicy::TcpOnly,
            PeerSource::Dht | PeerSource::PeerExchange | PeerSource::Manual => {
                OutgoingTransportPolicy::PreferUtp
            }
        },
        explicit => explicit,
    }
}

/// Collect on-disk size/mtime/inode hints for every file in `meta`.
///
/// Per-file, not all-or-nothing: a file that can't be stat'd (missing,
/// permission error, a BEP47 padding file real clients never materialize,
/// ...) is simply omitted from the result rather than aborting the whole
/// collection. `apply_file_hints` already treats a missing hint as "this
/// file changed" and invalidates only *that* file's pieces — one bad file
/// must not poison fastresume trust for every other file in the torrent.
fn collect_file_hints(root: &std::path::Path, meta: &TorrentMetaV1) -> Vec<FileHint> {
    meta.files
        .iter()
        .filter(|file| !file.pad)
        .filter_map(|file| {
            let path = file.path.resolve(root);
            let metadata = match rt_storage::metadata_no_follow(&path) {
                Ok(metadata) => metadata,
                Err(e) => {
                    debug!(
                        component = "fastresume",
                        operation = "collect_file_hints",
                        file_index = file.index,
                        path = %path.display(),
                        error = %e,
                        "could not stat file; omitting its hint"
                    );
                    return None;
                }
            };
            let modified = metadata
                .modified()
                .ok()
                .and_then(|time| time.duration_since(UNIX_EPOCH).ok())
                .map(|duration| duration.as_secs())
                .unwrap_or(0);

            #[cfg(unix)]
            let inode = {
                use std::os::unix::fs::MetadataExt;
                metadata.ino()
            };
            #[cfg(not(unix))]
            let inode = 0;

            Some(FileHint {
                file_index: file.index,
                size: metadata.len(),
                mtime_secs: modified,
                inode,
            })
        })
        .collect()
}

fn tracker_tiers_from_meta(meta: &TorrentMetaV1) -> Vec<Vec<TrackerState>> {
    let mut seen = std::collections::HashSet::new();
    let mut tiers = Vec::new();

    if !meta.announce_list.is_empty() {
        for tier in &meta.announce_list {
            let trackers: Vec<TrackerState> = tier
                .iter()
                .filter_map(|url| {
                    if seen.insert(url.clone()) {
                        Some(TrackerState::new(url.clone()))
                    } else {
                        None
                    }
                })
                .collect();
            if !trackers.is_empty() {
                tiers.push(trackers);
            }
        }
    }

    if let Some(url) = &meta.announce {
        if seen.insert(url.clone()) {
            tiers.insert(0, vec![TrackerState::new(url.clone())]);
        }
    }

    tiers
}

pub(crate) fn tracker_tiers_from_urls(urls: &[String]) -> Vec<Vec<TrackerState>> {
    let mut seen = HashSet::new();
    let trackers = urls
        .iter()
        .filter_map(|url| {
            if url.is_empty() || !seen.insert(url.clone()) {
                None
            } else {
                Some(TrackerState::new(url.clone()))
            }
        })
        .collect::<Vec<_>>();
    if trackers.is_empty() {
        Vec::new()
    } else {
        vec![trackers]
    }
}

/// Restore the small amount of tracker session state that must survive an
/// actor restart. Tracker IDs are opaque BEP 3 bytes and cannot be recovered
/// from the metainfo; losing them makes the next HTTP announce a new tracker
/// session. A persisted next deadline is restored as well so startup does
/// not create an announce storm for every resumed torrent. The query itself
/// is issued through `DbExecutor` before this pure projection runs.
pub(crate) fn restore_tracker_state_from_rows(
    tiers: &mut [Vec<TrackerState>],
    rows: &[rt_db::TorrentTrackerRow],
) {
    let persisted = rows
        .iter()
        .map(|row| (row.url.clone(), row))
        .collect::<HashMap<_, _>>();
    let now = Instant::now();
    let now_unix = db_i64(unix_now());
    for tier in tiers {
        for tracker in tier {
            let Some(row) = persisted.get(&tracker.url) else {
                continue;
            };
            tracker.tracker_id = row.tracker_id.clone();
            tracker.next_announce = row.next_announce_at.map(|deadline| {
                let delay = deadline.saturating_sub(now_unix).max(0) as u64;
                now + Duration::from_secs(delay)
            });
        }
    }
}

pub(crate) fn private_peer_source_allowed(
    is_private: bool,
    allowed_private_peers: &HashSet<SocketAddr>,
    peer: SocketAddr,
) -> bool {
    !is_private
        || allowed_private_peers.contains(&peer)
        || (private_peer_port_fallback_allowed(peer.ip())
            && allowed_private_peers
                .iter()
                .any(|allowed| allowed.ip() == peer.ip()))
}

pub(crate) fn private_peer_port_fallback_allowed(ip: IpAddr) -> bool {
    match ip {
        IpAddr::V4(ip) => {
            let octets = ip.octets();
            ip.is_loopback()
                || ip.is_private()
                || ip.is_link_local()
                // PERF-110 uses RFC 2544's reserved benchmarking block for
                // isolated peers. It is non-routable like RFC 1918 for the
                // same-IP source-port fallback used by private torrents.
                || (octets[0] == 198 && matches!(octets[1], 18 | 19))
        }
        IpAddr::V6(ip) => {
            ip.is_loopback() || is_ipv6_unique_local(ip) || is_ipv6_unicast_link_local(ip)
        }
    }
}

fn is_ipv6_unique_local(ip: std::net::Ipv6Addr) -> bool {
    ip.segments()[0] & 0xfe00 == 0xfc00
}

fn is_ipv6_unicast_link_local(ip: std::net::Ipv6Addr) -> bool {
    ip.segments()[0] & 0xffc0 == 0xfe80
}

fn record_peer_transfer(peer: &mut PeerHandle, upload: bool, bytes: u64) {
    let now = Instant::now();
    if upload {
        peer.uploaded = peer.uploaded.saturating_add(bytes);
        peer.upload_rate_window = peer.upload_rate_window.saturating_add(bytes);
        let elapsed = now.saturating_duration_since(peer.upload_rate_window_started);
        if elapsed < Duration::from_secs(1) {
            return;
        }
        peer.upload_rate = peer.upload_rate_window as f64 / elapsed.as_secs_f64().max(0.001);
        peer.upload_rate_window = 0;
        peer.upload_rate_window_started = now;
    } else {
        peer.downloaded = peer.downloaded.saturating_add(bytes);
        peer.download_rate_window = peer.download_rate_window.saturating_add(bytes);
        let elapsed = now.saturating_duration_since(peer.download_rate_window_started);
        if elapsed < Duration::from_secs(1) {
            return;
        }
        peer.download_rate = peer.download_rate_window as f64 / elapsed.as_secs_f64().max(0.001);
        peer.download_rate_window = 0;
        peer.download_rate_window_started = now;
    }
}

fn peer_rate(rate: f64, last_sample: Instant) -> i64 {
    if Instant::now().saturating_duration_since(last_sample) > Duration::from_secs(15) {
        0
    } else {
        rate.max(0.0).round() as i64
    }
}

fn peer_client_label(peer: &PeerHandle) -> String {
    if peer.ut_metadata_id.is_some() {
        "BEP10 peer".to_owned()
    } else {
        "BitTorrent peer".to_owned()
    }
}

fn webseed_block_url(meta: &TorrentMetaV1, webseed: &str) -> Option<Url> {
    let parsed = Url::parse(webseed).ok()?;
    if !matches!(parsed.scheme(), "http" | "https") {
        return None;
    }
    let first_file = meta.files.first()?;
    let components = first_file.path.components();
    if !webseed.ends_with('/')
        && components.len() > 1
        && components
            .first()
            .is_some_and(|component| component == &meta.name)
        && parsed
            .path_segments()
            .and_then(|mut segments| segments.next_back())
            .is_some_and(|last| last == meta.name)
    {
        let mut url = parsed;
        {
            let mut segments = url.path_segments_mut().ok()?;
            for component in &components[1..] {
                segments.push(component);
            }
        }
        return Some(url);
    }
    if webseed.ends_with('/') {
        parsed.join(&meta.name).ok()
    } else {
        Some(parsed)
    }
}

// A block spanning many tiny files would otherwise fan out into thousands of
// HTTP requests. Skip oversized webseed ranges to cap request amplification.
const MAX_WEBSEED_RANGES_PER_BLOCK: usize = 64;

struct WebseedBlockRange<'a> {
    file: &'a TorrentFileV1,
    file_offset: u64,
    block_offset: usize,
    length: usize,
}

fn webseed_block_ranges(
    meta: &TorrentMetaV1,
    request: BlockRequest,
) -> Option<Vec<WebseedBlockRange<'_>>> {
    if meta.piece_length == 0 || request.length == 0 || request.length > MAX_BLOCK_SIZE {
        return None;
    }
    if u64::from(request.begin).checked_add(u64::from(request.length))? > meta.piece_length {
        return None;
    }
    let block_start = u64::from(request.piece)
        .checked_mul(meta.piece_length)?
        .checked_add(u64::from(request.begin))?;
    let block_end = block_start.checked_add(u64::from(request.length))?;
    let requested_len = usize::try_from(request.length).ok()?;
    let first = meta.files.partition_point(|file| {
        file.offset
            .checked_add(file.length)
            .is_some_and(|file_end| file_end <= block_start)
    });
    let mut ranges = Vec::new();
    let mut covered_until = block_start;

    for file in &meta.files[first..] {
        if file.offset >= block_end {
            break;
        }
        let file_end = file.offset.checked_add(file.length)?;
        let overlap_start = block_start.max(file.offset);
        let overlap_end = block_end.min(file_end);
        if overlap_start >= overlap_end {
            continue;
        }
        if overlap_start != covered_until || ranges.len() >= MAX_WEBSEED_RANGES_PER_BLOCK {
            return None;
        }
        ranges.push(WebseedBlockRange {
            file,
            file_offset: overlap_start.checked_sub(file.offset)?,
            block_offset: usize::try_from(overlap_start.checked_sub(block_start)?).ok()?,
            length: usize::try_from(overlap_end.checked_sub(overlap_start)?).ok()?,
        });
        covered_until = overlap_end;
    }

    (covered_until == block_end
        && ranges.iter().map(|range| range.length).sum::<usize>() == requested_len)
        .then_some(ranges)
}

fn webseed_file_url(meta: &TorrentMetaV1, file: &TorrentFileV1, webseed: &str) -> Option<Url> {
    if meta.is_single_file() {
        return webseed_block_url(meta, webseed);
    }
    let parsed = Url::parse(webseed).ok()?;
    if !matches!(parsed.scheme(), "http" | "https") {
        return None;
    }
    let components = file.path.components();
    if components.first() != Some(&meta.name) || components.len() < 2 {
        return None;
    }

    let mut url = parsed;
    let base_has_trailing_slash = url.path().ends_with('/');
    let root_is_explicit = url
        .path_segments()
        .and_then(|mut segments| segments.next_back())
        .is_some_and(|last| last == meta.name);
    let mut segments = url.path_segments_mut().ok()?;
    segments.pop_if_empty();
    if base_has_trailing_slash || !root_is_explicit {
        segments.push(&meta.name);
    }
    for component in &components[1..] {
        segments.push(component);
    }
    drop(segments);
    Some(url)
}

pub(crate) fn webseed_file_byte_range(
    file_offset: u64,
    length: usize,
) -> anyhow::Result<(u64, u64)> {
    if length == 0 || length > MAX_BLOCK_SIZE as usize {
        anyhow::bail!("webseed file range length {length} is invalid");
    }
    let end = file_offset
        .checked_add(u64::try_from(length - 1)?)
        .ok_or_else(|| anyhow::anyhow!("webseed file range end overflow"))?;
    Ok((file_offset, end))
}

pub(crate) fn validate_webseed_range_response(
    status: StatusCode,
    headers: &reqwest::header::HeaderMap,
    expected_start: u64,
    expected_end: u64,
) -> anyhow::Result<()> {
    if status != StatusCode::PARTIAL_CONTENT {
        // A 200 response may contain the complete file from byte zero even
        // though the server ignored our Range header. Accepting and
        // truncating that body would write the wrong bytes for every
        // non-zero block.
        anyhow::bail!("webseed did not honor byte range: HTTP {status}");
    }
    let content_range = headers
        .get(CONTENT_RANGE)
        .ok_or_else(|| anyhow::anyhow!("webseed 206 response is missing Content-Range"))?
        .to_str()
        .map_err(|_| anyhow::anyhow!("webseed Content-Range is not valid ASCII"))?;
    let range = content_range
        .strip_prefix("bytes ")
        .and_then(|value| value.split_once('/'))
        .and_then(|(range, _total)| range.split_once('-'));
    let Some((start, end)) = range else {
        anyhow::bail!("webseed returned malformed Content-Range: {content_range}");
    };
    let start = start.parse::<u64>().map_err(|_| {
        anyhow::anyhow!("webseed returned malformed Content-Range: {content_range}")
    })?;
    let end = end.parse::<u64>().map_err(|_| {
        anyhow::anyhow!("webseed returned malformed Content-Range: {content_range}")
    })?;
    if start != expected_start || end != expected_end {
        anyhow::bail!(
            "webseed returned byte range {start}-{end}, expected {expected_start}-{expected_end}"
        );
    }
    Ok(())
}

#[derive(Debug, Default, PartialEq, Eq)]
struct UtPexPeers {
    added: Vec<SocketAddr>,
    dropped: Vec<SocketAddr>,
}

/// Parses BEP 11 compact IPv4/IPv6 `added`, `added6`, `dropped`, and
/// `dropped6` lists. The dropped set remains advisory at the task boundary:
/// it removes stale retry candidates but never forcibly disconnects an
/// otherwise healthy local connection.
fn parse_ut_pex_peers(payload: &[u8]) -> anyhow::Result<UtPexPeers> {
    let value = Decoder::new(payload)
        .with_max_nodes(MAX_UT_PEX_BENCODE_NODES)
        .decode()?;
    let BValue::Dict(pairs) = value else {
        anyhow::bail!("ut_pex payload must be a dict");
    };
    let parse_field = |key: &[u8], width: usize| -> anyhow::Result<Vec<SocketAddr>> {
        let Some(bytes) = pairs
            .iter()
            .find(|(candidate, _)| *candidate == key)
            .and_then(|(_, value)| value.as_bytes())
        else {
            return Ok(Vec::new());
        };
        if bytes.len() % width != 0 {
            anyhow::bail!("ut_pex {key:?} peers length is not a multiple of {width}");
        }
        let count = bytes.len() / width;
        if count > MAX_UT_PEX_PEERS {
            anyhow::bail!("ut_pex {key:?} peer list exceeds {MAX_UT_PEX_PEERS} entries");
        }
        let mut peers = Vec::with_capacity(count);
        if width == 6 {
            for chunk in bytes.as_chunks::<6>().0 {
                let port = u16::from_be_bytes([chunk[4], chunk[5]]);
                if port != 0 {
                    peers.push(SocketAddr::V4(SocketAddrV4::new(
                        Ipv4Addr::new(chunk[0], chunk[1], chunk[2], chunk[3]),
                        port,
                    )));
                }
            }
        } else {
            for chunk in bytes.as_chunks::<18>().0 {
                let port = u16::from_be_bytes([chunk[16], chunk[17]]);
                if port != 0 {
                    let octets: [u8; 16] = chunk[0..16].try_into().expect("chunk is 18 bytes");
                    peers.push(SocketAddr::V6(SocketAddrV6::new(
                        Ipv6Addr::from(octets),
                        port,
                        0,
                        0,
                    )));
                }
            }
        }
        Ok(peers)
    };
    let added = parse_field(b"added", 6)?;
    let added6 = parse_field(b"added6", 18)?;
    let dropped = parse_field(b"dropped", 6)?;
    let dropped6 = parse_field(b"dropped6", 18)?;
    if added.len() + added6.len() + dropped.len() + dropped6.len() > MAX_UT_PEX_PEERS {
        anyhow::bail!("ut_pex peer list exceeds {MAX_UT_PEX_PEERS} entries");
    }
    Ok(UtPexPeers {
        added: added.into_iter().chain(added6).collect(),
        dropped: dropped.into_iter().chain(dropped6).collect(),
    })
}

fn reconcile_peer_availability<A: PieceAvailability + ?Sized, B: PieceAvailability + ?Sized>(
    availability: &mut Availability,
    old: &A,
    new: &B,
) {
    let piece_count = availability.piece_count();
    for piece in 0..piece_count {
        match (old.has_piece(piece), new.has_piece(piece)) {
            (false, true) => availability.add_have(piece),
            (true, false) => availability.remove_have(piece),
            _ => {}
        }
    }
}

fn remove_peer_availability(availability: &mut Availability, peer_has: &PieceBitmap) {
    for piece in 0..availability.piece_count() {
        if peer_has.get(piece).unwrap_or(false) {
            availability.remove_have(piece);
        }
    }
}

fn tracker_event_after_success(current: TrackerEvent, sent: TrackerEvent) -> TrackerEvent {
    // A newer lifecycle event may have been queued while this request was in
    // flight (for example, the torrent can finish while its Started announce
    // is waiting on the tracker). Only consume the event represented by the
    // response; otherwise a successful Started response can erase a pending
    // Completed notification.
    if current == sent && matches!(sent, TrackerEvent::Started | TrackerEvent::Completed) {
        TrackerEvent::Empty
    } else {
        current
    }
}

fn tracker_event_after_incomplete_recheck(current: TrackerEvent) -> TrackerEvent {
    // A Started event may still be pending for a newly resumed session. A
    // Completed or Stopped event, however, no longer describes an active
    // incomplete torrent after the recheck and must not be sent later.
    match current {
        TrackerEvent::Started => TrackerEvent::Started,
        TrackerEvent::Empty | TrackerEvent::Completed | TrackerEvent::Stopped => {
            TrackerEvent::Empty
        }
    }
}

fn consume_stopped_announce(stopped_announced: &mut bool) -> bool {
    if *stopped_announced {
        false
    } else {
        *stopped_announced = true;
        true
    }
}

fn unix_now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn instant_to_unix(instant: Option<Instant>, now: Instant) -> Option<i64> {
    let current = db_i64(unix_now());
    instant.map(|instant| {
        if instant >= now {
            current.saturating_add(db_i64(instant.duration_since(now).as_secs()))
        } else {
            current.saturating_sub(db_i64(now.duration_since(instant).as_secs()))
        }
    })
}

fn tracker_status_label(status: &TrackerStatus) -> &'static str {
    match status {
        TrackerStatus::NeverAnnounced => "never_announced",
        TrackerStatus::Announcing => "announcing",
        TrackerStatus::Working => "working",
        TrackerStatus::Warning(_) => "warning",
        TrackerStatus::Error(_) => "error",
        TrackerStatus::Disabled => "disabled",
    }
}

fn tracker_failure_reason(status: &TrackerStatus) -> Option<String> {
    match status {
        TrackerStatus::Error(err) => Some(err.to_string()),
        _ => None,
    }
}

fn tracker_warning_message(status: &TrackerStatus) -> Option<String> {
    match status {
        TrackerStatus::Warning(message) => Some(message.clone()),
        _ => None,
    }
}

fn peer_event_if_active(paused: bool, event: PeerEvent) -> Option<PeerEvent> {
    (!paused).then_some(event)
}

async fn send_peer_event(peer_event_tx: &mpsc::Sender<PeerEvent>, event: PeerEvent) -> bool {
    matches!(
        timeout(PEER_EVENT_SEND_TIMEOUT, peer_event_tx.send(event)).await,
        Ok(Ok(()))
    )
}

async fn send_choke_event(
    peer_event_tx: &mpsc::Sender<PeerEvent>,
    peer: SocketAddr,
    id: PeerId,
    download_generation: u64,
    fast_negotiated: bool,
    choked_requests: Vec<BlockRequest>,
    outstanding: &mut Vec<OutstandingRequest>,
) -> bool {
    if send_peer_event(
        peer_event_tx,
        PeerEvent::Choked {
            peer,
            id,
            download_generation,
            fast_negotiated,
            outstanding: choked_requests.clone(),
        },
    )
    .await
    {
        true
    } else {
        // The actor still owns these reservations because the Choked event
        // was not delivered. Keep them for the terminal disconnect fallback.
        if !fast_negotiated {
            outstanding.extend(
                choked_requests
                    .into_iter()
                    .map(|request| OutstandingRequest::new(request, None)),
            );
        }
        false
    }
}

/// Terminal peer events must eventually reach the actor while its channel is
/// still open. Dropping a disconnect because the dedicated queue is full
/// strands the active peer entry, its picker reservations, and its global
/// peer permit. The peer task is owned by the torrent actor, so shutdown can
/// abort this wait if the actor itself is no longer making progress.
async fn send_peer_disconnect_event(
    peer_event_tx: &mpsc::Sender<PeerEvent>,
    event: PeerEvent,
) -> bool {
    peer_event_tx.send(event).await.is_ok()
}

/// Open a TCP connection, complete BEP 3 handshake, receive Piece messages.
async fn run_outgoing_peer_with_policy(
    addr: SocketAddr,
    peer_id: PeerId,
    info_hash: [u8; 20],
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_cmd_rx: mpsc::Receiver<PeerCommand>,
    mut upload: UploadContext,
    policy: OutgoingTransportPolicy,
) -> anyhow::Result<PeerLoopExit> {
    match policy {
        OutgoingTransportPolicy::Auto => {
            run_outgoing_peer(addr, peer_id, info_hash, peer_event_tx, peer_cmd_rx, upload).await
        }
        OutgoingTransportPolicy::TcpOnly => {
            run_outgoing_peer(addr, peer_id, info_hash, peer_event_tx, peer_cmd_rx, upload).await
        }
        OutgoingTransportPolicy::UtpOnly => {
            run_outgoing_utp_peer(addr, peer_id, info_hash, peer_event_tx, peer_cmd_rx, upload)
                .await
        }
        OutgoingTransportPolicy::PreferUtp => {
            match connect_utp_with_deadline(&upload.upload_rate.network_budget, addr).await {
                Ok(stream) => match prepare_outgoing_utp_peer(addr, info_hash, &mut upload, stream)
                    .await
                {
                    Ok((peer_io, fast, plane)) => {
                        upload.fast_negotiated = fast;
                        upload.plane = plane;
                        if plane == Plane::V2
                            && !send_peer_event(
                                &peer_event_tx,
                                PeerEvent::PlaneSelected {
                                    peer: addr,
                                    id: peer_id,
                                    plane,
                                },
                            )
                            .await
                        {
                            anyhow::bail!("torrent task stopped before binding hybrid peer plane");
                        }
                        Ok(run_peer_loop(
                            addr,
                            peer_id,
                            peer_io,
                            peer_event_tx,
                            peer_cmd_rx,
                            upload,
                            false,
                        )
                        .await)
                    }
                    Err(e) => {
                        debug!(
                            component = "peer",
                            operation = "setup_utp",
                            peer = %addr,
                            result = "fallback",
                            error = %e,
                            "uTP peer setup failed; falling back to TCP"
                        );
                        run_outgoing_peer(
                            addr,
                            peer_id,
                            info_hash,
                            peer_event_tx,
                            peer_cmd_rx,
                            upload,
                        )
                        .await
                    }
                },
                Err(e) => {
                    debug!(
                        component = "peer",
                        operation = "connect_utp",
                        peer = %addr,
                        result = "fallback",
                        error = %e,
                        "uTP peer path failed; falling back to TCP"
                    );
                    run_outgoing_peer(addr, peer_id, info_hash, peer_event_tx, peer_cmd_rx, upload)
                        .await
                }
            }
        }
    }
}

async fn run_outgoing_peer(
    addr: SocketAddr,
    peer_id: PeerId,
    info_hash: [u8; 20],
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_cmd_rx: mpsc::Receiver<PeerCommand>,
    mut upload: UploadContext,
) -> anyhow::Result<PeerLoopExit> {
    let stream = tokio::time::timeout(Duration::from_secs(10), TcpStream::connect(addr)).await??;
    stream.set_nodelay(true)?;

    let mut framed = Framed::with_capacity(
        stream,
        PeerCodec::with_resources(upload.resources.clone()),
        1,
    );

    let our_hs = Handshake {
        info_hash,
        peer_id: crate::peer_id::our_peer_id(),
        reserved: if upload.hybrid_v2_wire_hash().is_some() {
            ExtensionFlags::with_v2_support()
        } else {
            ExtensionFlags::with_extension_protocol_and_fast()
        },
    };
    // Send our handshake as raw bytes before the codec takes over.
    {
        use tokio::io::AsyncWriteExt;
        let inner = framed.get_mut();
        timeout(PEER_SOCKET_WRITE_TIMEOUT, inner.write_all(&our_hs.encode()))
            .await
            .map_err(|_| anyhow::anyhow!("peer handshake write timed out"))??;
    }

    let (remote_supports_extension, remote_supports_fast, plane) = {
        use tokio::io::AsyncReadExt;
        let mut hs_buf = [0u8; 68];
        tokio::time::timeout(
            Duration::from_secs(10),
            framed.get_mut().read_exact(&mut hs_buf),
        )
        .await??;
        let remote_hs = Handshake::parse(&hs_buf)?;
        if remote_hs.peer_id == crate::peer_id::our_peer_id() {
            anyhow::bail!("peer handshake identifies this client");
        }
        let plane = upload.outgoing_plane(info_hash, &remote_hs)?;
        (
            remote_hs.reserved.supports_extension_protocol(),
            remote_hs.reserved.supports_fast_extension(),
            plane,
        )
    };

    upload.plane = plane;
    if plane == Plane::V2
        && !send_peer_event(
            &peer_event_tx,
            PeerEvent::PlaneSelected {
                peer: addr,
                id: peer_id,
                plane,
            },
        )
        .await
    {
        anyhow::bail!("torrent task stopped before binding hybrid peer plane");
    }
    let mut peer_io = PeerIo::Tcp(framed);
    send_extension_handshake(
        &mut peer_io,
        upload.metadata.as_ref(),
        upload.is_private,
        upload.pex_enabled,
        remote_supports_extension,
    )
    .await?;
    upload.fast_negotiated = remote_supports_fast;
    send_have_state(
        &mut peer_io,
        &upload.have_pieces,
        &upload.resources,
        remote_supports_fast,
    )
    .await?;
    peer_io.send(Message::Interested).await?;

    Ok(run_peer_loop(
        addr,
        peer_id,
        peer_io,
        peer_event_tx,
        peer_cmd_rx,
        upload,
        false,
    )
    .await)
}

async fn run_outgoing_utp_peer(
    addr: SocketAddr,
    peer_id: PeerId,
    info_hash: [u8; 20],
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_cmd_rx: mpsc::Receiver<PeerCommand>,
    upload: UploadContext,
) -> anyhow::Result<PeerLoopExit> {
    let stream = connect_utp_with_deadline(&upload.upload_rate.network_budget, addr).await?;
    run_established_utp_peer(
        addr,
        peer_id,
        info_hash,
        peer_event_tx,
        peer_cmd_rx,
        upload,
        stream,
    )
    .await
}

async fn prepare_outgoing_utp_peer(
    _addr: SocketAddr,
    info_hash: [u8; 20],
    upload: &mut UploadContext,
    mut stream: UtpStream,
) -> anyhow::Result<(PeerIo, bool, Plane)> {
    let our_hs = Handshake {
        info_hash,
        peer_id: crate::peer_id::our_peer_id(),
        reserved: if upload.hybrid_v2_wire_hash().is_some() {
            ExtensionFlags::with_v2_support()
        } else {
            ExtensionFlags::with_extension_protocol_and_fast()
        },
    };
    timeout(
        PEER_SOCKET_WRITE_TIMEOUT,
        stream.write_all(&our_hs.encode()),
    )
    .await
    .map_err(|_| anyhow::anyhow!("peer handshake write timed out"))??;

    let mut hs_buf = [0u8; 68];
    tokio::time::timeout(Duration::from_secs(10), stream.read_exact(&mut hs_buf)).await??;
    let remote_hs = Handshake::parse(&hs_buf)?;
    if remote_hs.peer_id == crate::peer_id::our_peer_id() {
        anyhow::bail!("peer handshake identifies this client");
    }
    let plane = upload.outgoing_plane(info_hash, &remote_hs)?;
    upload.plane = plane;
    let remote_supports_extension = remote_hs.reserved.supports_extension_protocol();
    let remote_supports_fast = remote_hs.reserved.supports_fast_extension();

    let mut peer_io = PeerIo::Utp(Box::new(UtpPeerIo::new(stream, upload.resources.clone())));
    send_extension_handshake(
        &mut peer_io,
        upload.metadata.as_ref(),
        upload.is_private,
        upload.pex_enabled,
        remote_supports_extension,
    )
    .await?;
    send_have_state(
        &mut peer_io,
        &upload.have_pieces,
        &upload.resources,
        remote_supports_fast,
    )
    .await?;
    peer_io.send(Message::Interested).await?;
    Ok((peer_io, remote_supports_fast, plane))
}

async fn run_established_utp_peer(
    addr: SocketAddr,
    peer_id: PeerId,
    info_hash: [u8; 20],
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_cmd_rx: mpsc::Receiver<PeerCommand>,
    mut upload: UploadContext,
    stream: UtpStream,
) -> anyhow::Result<PeerLoopExit> {
    let (peer_io, fast, plane) =
        prepare_outgoing_utp_peer(addr, info_hash, &mut upload, stream).await?;
    upload.fast_negotiated = fast;
    upload.plane = plane;
    if plane == Plane::V2
        && !send_peer_event(
            &peer_event_tx,
            PeerEvent::PlaneSelected {
                peer: addr,
                id: peer_id,
                plane,
            },
        )
        .await
    {
        anyhow::bail!("torrent task stopped before binding hybrid peer plane");
    }

    Ok(run_peer_loop(
        addr,
        peer_id,
        peer_io,
        peer_event_tx,
        peer_cmd_rx,
        upload,
        false,
    )
    .await)
}

#[allow(clippy::too_many_arguments)]
async fn run_incoming_peer(
    stream: TcpStream,
    addr: SocketAddr,
    peer_id: PeerId,
    info_hash: [u8; 20],
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_cmd_rx: mpsc::Receiver<PeerCommand>,
    mut upload: UploadContext,
    remote_supports_extension: bool,
    remote_supports_fast: bool,
) -> anyhow::Result<PeerLoopExit> {
    stream.set_nodelay(true)?;
    let mut framed = Framed::with_capacity(
        stream,
        PeerCodec::with_resources(upload.resources.clone()),
        1,
    );

    let wire_info_hash = upload
        .peer_wire_hash(info_hash, upload.plane)
        .ok_or_else(|| anyhow::anyhow!("incoming peer plane has no hybrid wire hash"))?;
    let our_hs = Handshake {
        info_hash: wire_info_hash,
        peer_id: crate::peer_id::our_peer_id(),
        reserved: if upload.hybrid_v2_wire_hash().is_some() {
            ExtensionFlags::with_v2_support()
        } else {
            ExtensionFlags::with_extension_protocol_and_fast()
        },
    };
    {
        use tokio::io::AsyncWriteExt;
        timeout(
            PEER_SOCKET_WRITE_TIMEOUT,
            framed.get_mut().write_all(&our_hs.encode()),
        )
        .await
        .map_err(|_| anyhow::anyhow!("peer handshake write timed out"))??;
    }

    let mut peer_io = PeerIo::Tcp(framed);
    send_extension_handshake(
        &mut peer_io,
        upload.metadata.as_ref(),
        upload.is_private,
        upload.pex_enabled,
        remote_supports_extension,
    )
    .await?;
    upload.fast_negotiated = remote_supports_fast;
    send_have_state(
        &mut peer_io,
        &upload.have_pieces,
        &upload.resources,
        remote_supports_fast,
    )
    .await?;
    peer_io.send(Message::Interested).await?;
    Ok(run_peer_loop(
        addr,
        peer_id,
        peer_io,
        peer_event_tx,
        peer_cmd_rx,
        upload,
        false,
    )
    .await)
}

#[allow(clippy::too_many_arguments)]
async fn run_incoming_utp_peer(
    mut stream: UtpStream,
    addr: SocketAddr,
    peer_id: PeerId,
    info_hash: [u8; 20],
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_cmd_rx: mpsc::Receiver<PeerCommand>,
    mut upload: UploadContext,
    remote_supports_extension: bool,
    remote_supports_fast: bool,
) -> anyhow::Result<PeerLoopExit> {
    let wire_info_hash = upload
        .peer_wire_hash(info_hash, upload.plane)
        .ok_or_else(|| anyhow::anyhow!("incoming uTP peer plane has no hybrid wire hash"))?;
    let our_hs = Handshake {
        info_hash: wire_info_hash,
        peer_id: crate::peer_id::our_peer_id(),
        reserved: if upload.hybrid_v2_wire_hash().is_some() {
            ExtensionFlags::with_v2_support()
        } else {
            ExtensionFlags::with_extension_protocol_and_fast()
        },
    };
    timeout(
        PEER_SOCKET_WRITE_TIMEOUT,
        stream.write_all(&our_hs.encode()),
    )
    .await
    .map_err(|_| anyhow::anyhow!("peer handshake write timed out"))??;

    let mut peer_io = PeerIo::Utp(Box::new(UtpPeerIo::new(stream, upload.resources.clone())));
    send_extension_handshake(
        &mut peer_io,
        upload.metadata.as_ref(),
        upload.is_private,
        upload.pex_enabled,
        remote_supports_extension,
    )
    .await?;
    upload.fast_negotiated = remote_supports_fast;
    send_have_state(
        &mut peer_io,
        &upload.have_pieces,
        &upload.resources,
        remote_supports_fast,
    )
    .await?;
    peer_io.send(Message::Interested).await?;
    Ok(run_peer_loop(
        addr,
        peer_id,
        peer_io,
        peer_event_tx,
        peer_cmd_rx,
        upload,
        false,
    )
    .await)
}

pub(crate) enum PeerIo {
    Tcp(Framed<TcpStream, PeerCodec>),
    Utp(Box<UtpPeerIo>),
}

pub(crate) struct UtpPeerIo {
    stream: UtpStream,
    decoder: UtpFrameDecoder,
    write_buffer: UtpWireBuffer,
}

impl UtpPeerIo {
    pub(crate) fn new(stream: UtpStream, resources: ResourceGovernor) -> Self {
        Self {
            stream,
            decoder: UtpFrameDecoder::new(resources),
            write_buffer: UtpWireBuffer::default(),
        }
    }
}

impl PeerIo {
    pub(crate) async fn send(&mut self, msg: Message) -> anyhow::Result<()> {
        timeout(PEER_SOCKET_WRITE_TIMEOUT, async {
            match self {
                PeerIo::Tcp(framed) => framed.send(msg).await.map_err(Into::into),
                PeerIo::Utp(io) => io.send(msg).await,
            }
        })
        .await
        .map_err(|_| anyhow::anyhow!("peer socket write timed out"))?
    }

    async fn send_piece(
        &mut self,
        piece: u32,
        begin: u32,
        data: bytes::Bytes,
    ) -> anyhow::Result<()> {
        timeout(PEER_SOCKET_WRITE_TIMEOUT, async {
            match self {
                PeerIo::Tcp(framed) => {
                    // Preserve wire order with any control frame still held
                    // in Framed before bypassing its copying encoder.
                    framed.flush().await?;
                    let message_len = 9usize
                        .checked_add(data.len())
                        .and_then(|len| u32::try_from(len).ok())
                        .ok_or_else(|| anyhow::anyhow!("piece frame length exceeds u32"))?;
                    let mut header = [0u8; 13];
                    header[..4].copy_from_slice(&message_len.to_be_bytes());
                    header[4] = 7;
                    header[5..9].copy_from_slice(&piece.to_be_bytes());
                    header[9..13].copy_from_slice(&begin.to_be_bytes());
                    write_piece_vectored(framed.get_mut(), &header, &data).await?;
                    Ok(())
                }
                PeerIo::Utp(io) => io.send(Message::Piece { piece, begin, data }).await,
            }
        })
        .await
        .map_err(|_| anyhow::anyhow!("peer socket write timed out"))?
    }

    /// Write a bounded set of already-ready Piece messages. TCP writes their
    /// legal per-request frames in one vectored sequence; uTP keeps its
    /// existing framed-send path. The returned count includes only frames
    /// that were completely written if an error occurs.
    async fn send_pieces(
        &mut self,
        pieces: &[(u32, u32, &bytes::Bytes)],
    ) -> Result<usize, (usize, anyhow::Error)> {
        if pieces.is_empty() {
            return Ok(0);
        }
        debug!(
            target: "torrentng::upload_batches",
            operation = "ready_frame_group",
            frames = pieces.len(),
            payload_bytes = pieces.iter().map(|(_, _, data)| data.len() as u64).sum::<u64>(),
            "writing ready peer Piece frames"
        );
        if pieces.len() == 1 {
            let (piece, begin, data) = pieces[0];
            return self
                .send_piece(piece, begin, data.clone())
                .await
                .map(|()| 1)
                .map_err(|error| (0, error));
        }

        match self {
            PeerIo::Tcp(framed) => {
                match timeout(PEER_SOCKET_WRITE_TIMEOUT, framed.flush()).await {
                    Ok(Ok(())) => {}
                    Ok(Err(error)) => return Err((0, error.into())),
                    Err(_) => {
                        return Err((0, anyhow::anyhow!("peer socket write timed out")));
                    }
                }
                write_piece_frames_vectored(framed.get_mut(), pieces)
                    .await
                    .map_err(|(completed, error)| (completed, error.into()))
            }
            PeerIo::Utp(io) => {
                for (index, (piece, begin, data)) in pieces.iter().enumerate() {
                    match timeout(
                        PEER_SOCKET_WRITE_TIMEOUT,
                        io.send(Message::Piece {
                            piece: *piece,
                            begin: *begin,
                            data: (*data).clone(),
                        }),
                    )
                    .await
                    {
                        Ok(Ok(())) => {}
                        Ok(Err(error)) => return Err((index, error)),
                        Err(_) => {
                            return Err((index, anyhow::anyhow!("peer socket write timed out")));
                        }
                    }
                }
                Ok(pieces.len())
            }
        }
    }

    pub(crate) async fn next(&mut self) -> anyhow::Result<Option<Message>> {
        match self {
            PeerIo::Tcp(framed) => match framed.next().await {
                Some(result) => result.map(Some).map_err(Into::into),
                None => Ok(None),
            },
            PeerIo::Utp(io) => io.next().await,
        }
    }

    fn try_next_ready(&mut self) -> Option<anyhow::Result<Option<Message>>> {
        self.next().now_or_never()
    }
}

async fn write_piece_vectored<W>(
    stream: &mut W,
    header: &[u8; 13],
    payload: &[u8],
) -> std::io::Result<()>
where
    W: tokio::io::AsyncWrite + Unpin,
{
    use tokio::io::AsyncWriteExt;

    let mut header_offset = 0;
    let mut payload_offset = 0;
    while header_offset < header.len() || payload_offset < payload.len() {
        let header_slice = &header[header_offset..];
        let payload_slice = &payload[payload_offset..];
        let buffers = [IoSlice::new(header_slice), IoSlice::new(payload_slice)];
        debug!(
            target: "torrentng::upload_batches",
            operation = "socket_write",
            frames = 1,
            payload_remaining = payload_slice.len(),
            vectored_slices = buffers.len(),
            "writing peer Piece frame"
        );
        let written = stream.write_vectored(&buffers).await?;
        if written == 0 {
            return Err(std::io::Error::new(
                std::io::ErrorKind::WriteZero,
                "failed to write peer piece frame",
            ));
        }
        let header_written = written.min(header_slice.len());
        header_offset += header_written;
        payload_offset += written - header_written;
    }
    Ok(())
}

async fn write_piece_frames_vectored<W>(
    stream: &mut W,
    pieces: &[(u32, u32, &bytes::Bytes)],
) -> Result<usize, (usize, std::io::Error)>
where
    W: tokio::io::AsyncWrite + Unpin,
{
    use tokio::io::AsyncWriteExt;

    if pieces.len() > MAX_UPLOAD_READ_BATCH_BLOCKS {
        return Err((
            0,
            std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                "too many Piece frames in one upload batch",
            ),
        ));
    }
    let mut headers = [[0u8; 13]; MAX_UPLOAD_READ_BATCH_BLOCKS];
    for (index, (piece, begin, data)) in pieces.iter().enumerate() {
        let message_len = 9usize
            .checked_add(data.len())
            .and_then(|len| u32::try_from(len).ok())
            .ok_or_else(|| {
                (
                    0,
                    std::io::Error::new(
                        std::io::ErrorKind::InvalidInput,
                        "piece frame length exceeds u32",
                    ),
                )
            })?;
        let header = &mut headers[index];
        header[..4].copy_from_slice(&message_len.to_be_bytes());
        header[4] = 7;
        header[5..9].copy_from_slice(&piece.to_be_bytes());
        header[9..13].copy_from_slice(&begin.to_be_bytes());
    }

    let deadline = TokioInstant::now() + PEER_SOCKET_WRITE_TIMEOUT;
    let mut cursors = [(0usize, 0usize); MAX_UPLOAD_READ_BATCH_BLOCKS];
    loop {
        let completed = cursors
            .iter()
            .take(pieces.len())
            .zip(pieces)
            .take_while(|((header, payload), (_, _, data))| *header == 13 && *payload == data.len())
            .count();
        if completed == pieces.len() {
            return Ok(completed);
        }

        let write_result = {
            let mut buffers: [IoSlice<'_>; MAX_UPLOAD_READ_BATCH_BLOCKS * 2] =
                std::array::from_fn(|_| IoSlice::new(&[]));
            let mut buffer_count = 0;
            for (index, (_, _, data)) in pieces.iter().enumerate().skip(completed) {
                let (header_offset, payload_offset) = cursors[index];
                if header_offset < headers[index].len() {
                    buffers[buffer_count] = IoSlice::new(&headers[index][header_offset..]);
                    buffer_count += 1;
                }
                if payload_offset < data.len() {
                    buffers[buffer_count] = IoSlice::new(&data[payload_offset..]);
                    buffer_count += 1;
                }
            }
            let payload_remaining = pieces
                .iter()
                .enumerate()
                .skip(completed)
                .map(|(index, (_, _, data))| data.len().saturating_sub(cursors[index].1))
                .sum::<usize>();
            debug!(
                target: "torrentng::upload_batches",
                operation = "socket_write",
                frames = pieces.len() - completed,
                payload_remaining,
                vectored_slices = buffer_count,
                "writing ready peer Piece frames"
            );
            tokio::time::timeout_at(deadline, stream.write_vectored(&buffers[..buffer_count])).await
        };
        let written = match write_result {
            Ok(Ok(written)) => written,
            Ok(Err(error)) => {
                let completed = cursors
                    .iter()
                    .take(pieces.len())
                    .zip(pieces)
                    .take_while(|((header, payload), (_, _, data))| {
                        *header == 13 && *payload == data.len()
                    })
                    .count();
                return Err((completed, error));
            }
            Err(_) => {
                let completed = cursors
                    .iter()
                    .take(pieces.len())
                    .zip(pieces)
                    .take_while(|((header, payload), (_, _, data))| {
                        *header == 13 && *payload == data.len()
                    })
                    .count();
                return Err((
                    completed,
                    std::io::Error::new(
                        std::io::ErrorKind::TimedOut,
                        "peer socket write timed out",
                    ),
                ));
            }
        };
        if written == 0 {
            let completed = cursors
                .iter()
                .take(pieces.len())
                .zip(pieces)
                .take_while(|((header, payload), (_, _, data))| {
                    *header == 13 && *payload == data.len()
                })
                .count();
            return Err((
                completed,
                std::io::Error::new(
                    std::io::ErrorKind::WriteZero,
                    "failed to write peer Piece frames",
                ),
            ));
        }

        let mut remaining = written;
        for (index, (_, _, data)) in pieces.iter().enumerate() {
            if remaining == 0 {
                break;
            }
            let (header_offset, payload_offset) = &mut cursors[index];
            let header_written = remaining.min(headers[index].len() - *header_offset);
            *header_offset += header_written;
            remaining -= header_written;
            let payload_written = remaining.min(data.len() - *payload_offset);
            *payload_offset += payload_written;
            remaining -= payload_written;
        }
        debug_assert_eq!(remaining, 0);
    }
}

impl UtpPeerIo {
    async fn send(&mut self, msg: Message) -> anyhow::Result<()> {
        let encoded = self.write_buffer.encode(&self.decoder, &msg)?;
        self.stream.write_all(encoded).await?;
        Ok(())
    }

    async fn next(&mut self) -> anyhow::Result<Option<Message>> {
        self.decoder.next_message(&mut self.stream).await
    }
}

/// Reusable uTP write storage. Unlike TCP's `Framed` write buffer, the uTP
/// stream path previously allocated a new `Vec<u8>` for every message. Keep
/// one bounded frame buffer per connection and retain its resource lease for
/// as long as the allocation is retained.
pub(crate) struct UtpWireBuffer {
    buffer: BytesMut,
    lease: Option<MemoryLease>,
}

impl Default for UtpWireBuffer {
    fn default() -> Self {
        Self {
            buffer: BytesMut::new(),
            lease: None,
        }
    }
}

impl UtpWireBuffer {
    pub(crate) fn encode<'a>(
        &'a mut self,
        decoder: &UtpFrameDecoder,
        msg: &Message,
    ) -> anyhow::Result<&'a [u8]> {
        let encoded_len = msg
            .encoded_len()
            .ok_or_else(|| anyhow::anyhow!("peer message exceeds the wire length limit"))?;
        self.ensure_capacity(decoder, encoded_len)?;
        self.buffer.clear();
        msg.encode_into(&mut self.buffer)?;
        Ok(self.buffer.as_ref())
    }

    fn ensure_capacity(
        &mut self,
        decoder: &UtpFrameDecoder,
        required: usize,
    ) -> anyhow::Result<()> {
        if self.buffer.capacity() < required {
            // Acquire the next frame allowance before replacing the existing
            // buffer. This preserves the admission check if a peer requests a
            // larger frame, while the old allocation remains reusable when
            // the new reservation is denied.
            let mut lease = decoder.reserve_outbound_buffer(required)?;
            let old_buffer = std::mem::replace(&mut self.buffer, BytesMut::new());
            let old_lease = self.lease.take();
            drop(old_buffer);
            drop(old_lease);

            let buffer = BytesMut::with_capacity(required);
            let capacity = u64::try_from(buffer.capacity())
                .map_err(|_| anyhow::anyhow!("uTP peer write buffer capacity overflow"))?;
            if capacity > lease.bytes() && !lease.try_grow(capacity - lease.bytes()) {
                anyhow::bail!("uTP peer write buffer allocation denied");
            }
            self.buffer = buffer;
            self.lease = Some(lease);
        } else {
            let capacity = u64::try_from(self.buffer.capacity())
                .map_err(|_| anyhow::anyhow!("uTP peer write buffer capacity overflow"))?;
            match &mut self.lease {
                Some(lease) if lease.bytes() < capacity => {
                    if !lease.try_grow(capacity - lease.bytes()) {
                        anyhow::bail!("uTP peer write buffer allocation denied");
                    }
                }
                None => {
                    self.lease = Some(decoder.reserve_outbound_buffer(self.buffer.capacity())?);
                }
                _ => {}
            }
        }
        Ok(())
    }
}

/// Incremental length-prefix decoding for uTP's byte stream. Unlike
/// `read_exact` into a local buffer, this keeps a partial frame across a
/// cancelled `next()` future. The peer loop intentionally cancels that future
/// whenever a command, upload completion, or timer wins its `select!`.
pub(crate) struct UtpFrameDecoder {
    buffer: Vec<u8>,
    resources: ResourceGovernor,
    // The decoder retains its backing allocation across frame boundaries so
    // it can preserve a partial frame when `next()` is cancelled. Keep a
    // lease for that capacity, plus one same-sized allowance for the parsed
    // message copy made by `Message::parse` while the wire frame is handled.
    memory_leases: Vec<MemoryLease>,
    reserved_bytes: u64,
}

impl Default for UtpFrameDecoder {
    fn default() -> Self {
        Self::new(ResourceGovernor::new(Default::default()))
    }
}

impl UtpFrameDecoder {
    pub(crate) fn new(resources: ResourceGovernor) -> Self {
        Self {
            buffer: Vec::new(),
            resources,
            memory_leases: Vec::new(),
            reserved_bytes: 0,
        }
    }

    fn is_empty(&self) -> bool {
        self.buffer.is_empty()
    }

    pub(crate) fn reserve_outbound_buffer(&self, bytes: usize) -> anyhow::Result<MemoryLease> {
        let bytes = u64::try_from(bytes)
            .map_err(|_| anyhow::anyhow!("peer message memory estimate does not fit in u64"))?;
        self.resources
            .try_acquire(MemoryClass::PeerBuffer, bytes)
            .ok_or_else(|| anyhow::anyhow!("peer message allocation of {bytes} bytes denied"))
    }

    pub(crate) async fn next_message(
        &mut self,
        stream: &mut UtpStream,
    ) -> anyhow::Result<Option<Message>> {
        loop {
            if let Some(message) = self.take_frame()? {
                return Ok(Some(message));
            }
            let chunk = match stream.recv().await {
                Ok(chunk) => chunk,
                Err(rt_utp::UtpError::Closed) => {
                    if self.is_empty() {
                        return Ok(None);
                    }
                    anyhow::bail!("uTP peer closed in the middle of a message")
                }
                Err(err) => return Err(err.into()),
            };
            if chunk.is_empty() {
                if self.is_empty() {
                    return Ok(None);
                }
                anyhow::bail!("uTP peer closed in the middle of a message");
            }
            self.push(&chunk)?;
        }
    }

    fn push(&mut self, chunk: &[u8]) -> anyhow::Result<()> {
        if chunk.is_empty() {
            return Ok(());
        }

        // Read only the length prefix before appending the rest of an input
        // chunk. A declared 2 MiB frame must be admitted before its backing
        // allocation grows; otherwise every uTP peer could retain one legal
        // maximum-sized partial frame outside the PeerBuffer governor.
        if self.buffer.len() < 4 {
            let header_len = (4 - self.buffer.len()).min(chunk.len());
            self.reserve_capacity(self.buffer.len().saturating_add(header_len))?;
            self.buffer.extend_from_slice(&chunk[..header_len]);
            if self.buffer.len() == 4 {
                self.reserve_declared_frame()?;
            }
            if header_len < chunk.len() {
                self.append_chunk(&chunk[header_len..])?;
            }
            return Ok(());
        }

        self.reserve_declared_frame()?;
        self.append_chunk(chunk)?;
        Ok(())
    }

    fn take_frame(&mut self) -> anyhow::Result<Option<Message>> {
        if self.buffer.len() < 4 {
            return Ok(None);
        }
        self.reserve_declared_frame()?;
        let len = self.frame_length();
        let frame_len = 4usize
            .checked_add(len as usize)
            .expect("bounded peer frame length must fit usize");
        if self.buffer.len() < frame_len {
            return Ok(None);
        }
        // Parse directly from the retained frame before draining it. The
        // message parser already copies the payload variants that must outlive
        // this buffer (Piece, Bitfield, and Extended); materializing a second
        // full payload Vec here made the peak roughly three frame sizes while
        // the decoder only admitted two.
        let message = Message::parse(&self.buffer[4..frame_len])?;
        self.buffer.drain(..frame_len);
        Ok(Some(message))
    }

    fn append_chunk(&mut self, chunk: &[u8]) -> anyhow::Result<()> {
        let required = self
            .buffer
            .len()
            .checked_add(chunk.len())
            .ok_or_else(|| anyhow::anyhow!("peer frame buffer length overflow"))?;
        self.reserve_capacity(required)?;
        self.buffer.extend_from_slice(chunk);
        Ok(())
    }

    fn reserve_declared_frame(&mut self) -> anyhow::Result<()> {
        let len = self.frame_length();
        if len > rt_peer_wire::message::MAX_MESSAGE_LEN {
            anyhow::bail!("peer message too large: {len}");
        }
        let frame_len = 4usize
            .checked_add(len as usize)
            .expect("bounded peer frame length must fit usize");
        self.reserve_capacity(frame_len)
    }

    fn reserve_capacity(&mut self, required: usize) -> anyhow::Result<()> {
        if required <= self.buffer.capacity() {
            return Ok(());
        }
        let required_bytes = u64::try_from(required)
            .map_err(|_| anyhow::anyhow!("peer frame buffer length does not fit in u64"))?
            .saturating_mul(2);
        if required_bytes <= self.reserved_bytes {
            self.buffer
                .try_reserve_exact(required - self.buffer.capacity())
                .map_err(|error| anyhow::anyhow!("peer frame buffer allocation failed: {error}"))?;
            return Ok(());
        }
        let additional = required_bytes.saturating_sub(self.reserved_bytes);
        let lease = self
            .resources
            .try_acquire(MemoryClass::PeerBuffer, additional)
            .ok_or_else(|| {
                anyhow::anyhow!("peer frame buffer allocation of {required_bytes} bytes denied")
            })?;
        self.buffer
            .try_reserve_exact(required - self.buffer.capacity())
            .map_err(|error| anyhow::anyhow!("peer frame buffer allocation failed: {error}"))?;
        self.memory_leases.push(lease);
        self.reserved_bytes = required_bytes;
        Ok(())
    }

    fn frame_length(&self) -> u32 {
        let header = [
            self.buffer[0],
            self.buffer[1],
            self.buffer[2],
            self.buffer[3],
        ];
        u32::from_be_bytes(header)
    }
}

#[derive(Debug)]
struct PeerLoopExit {
    result: anyhow::Result<()>,
    /// Requests that were accepted by the torrent actor but had not yet
    /// produced a Piece event when the peer loop ended. The production
    /// wrapper forwards these to the actor's dedicated terminal channel so
    /// picker reservations are released even on a socket/error path.
    outstanding: Vec<BlockRequest>,
}

struct PeerLoopStart {
    addr: SocketAddr,
    peer_id: PeerId,
    peer_io: PeerIo,
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_cmd_rx: mpsc::Receiver<PeerCommand>,
    upload: UploadContext,
    send_terminal_event_on_peer_channel: bool,
}

async fn run_peer_loop(
    addr: SocketAddr,
    peer_id: PeerId,
    peer_io: PeerIo,
    peer_event_tx: mpsc::Sender<PeerEvent>,
    peer_cmd_rx: mpsc::Receiver<PeerCommand>,
    upload: UploadContext,
    // Production wrappers use the dedicated terminal channel after this
    // loop returns. The direct loop path can opt into the ordinary event
    // channel when it owns no separate terminal delivery path.
    send_terminal_event_on_peer_channel: bool,
) -> PeerLoopExit {
    run_peer_loop_with_upload_future(
        PeerLoopStart {
            addr,
            peer_id,
            peer_io,
            peer_event_tx,
            peer_cmd_rx,
            upload,
            send_terminal_event_on_peer_channel,
        },
        upload_read_batch_future,
    )
    .await
}

async fn run_peer_loop_with_upload_future<MakeUploadReadFuture, F>(
    PeerLoopStart {
        addr,
        peer_id,
        mut peer_io,
        peer_event_tx,
        mut peer_cmd_rx,
        mut upload,
        send_terminal_event_on_peer_channel,
    }: PeerLoopStart,
    make_upload_read_future: MakeUploadReadFuture,
) -> PeerLoopExit
where
    MakeUploadReadFuture:
        Fn(UploadBatch<UploadReadSpec>, Arc<UploadReadContext>) -> F + Copy + Send + 'static,
    F: std::future::Future<Output = UploadBatch<UploadReadCompletion>> + Send + 'static,
{
    let mut outstanding = Vec::<OutstandingRequest>::new();
    let upload_service = upload.upload_rate.network_budget.upload_service();
    let upload_obligations = match upload_service.register(
        upload.upload_rate.peer,
        upload.fast_negotiated,
        MAX_UPLOAD_WORK,
    ) {
        Ok(connection) => connection,
        Err(error) => {
            return PeerLoopExit {
                result: Err(anyhow::anyhow!(
                    "registering shared upload service: {error:?}"
                )),
                outstanding: drain_outstanding(&mut outstanding),
            };
        }
    };
    // These fields are stable for the peer's lifetime. Keep one shared
    // context for every in-flight block instead of cloning the path, storage
    // scheduler, resource governor, rate handle, and read-admission handle
    // each time the peer loop refills its upload queue.
    let upload_read_context = Arc::new(UploadReadContext {
        save_root: upload.save_root.clone(),
        piece_map: upload.piece_map.clone(),
        hybrid_v2: upload.hybrid_v2.clone(),
        plane: upload.plane,
        storage: upload.storage.clone(),
        resources: upload.resources.clone(),
        upload_control: upload.upload_control.clone(),
        upload_rate: upload.upload_rate.clone(),
        read_admission: upload_obligations.read_admission(),
    });
    // BEP 10 extension ids are negotiated per peer. The id in our outgoing
    // handshake is the id this loop receives from the peer; responses must
    // use the peer's advertised id rather than our local id.
    let mut remote_ut_metadata_id = None;
    let mut download_choked = true;
    let mut upload_choked = true;
    let mut timeout_tick = interval(Duration::from_secs(5));
    let mut last_activity = Instant::now();
    // Disk reads are scheduled through the bounded mount scheduler, but the
    // peer loop must not await one read inline: a slow device otherwise
    // prevents it from processing choke/shutdown/input messages. Keep their
    // futures in the select loop instead of spawning a Tokio task per block.
    let mut upload_reads = UploadReadTasks::<F>::default();
    let mut upload_dispatch_pending = false;
    let mut upload_intake_messages = 0usize;
    let mut upload_pipeline_width = 1usize;
    let mut upload_coalescing_expired = false;
    let upload_coalescing_flush = sleep(UPLOAD_READ_COALESCE_MAX_DELAY);
    tokio::pin!(upload_coalescing_flush);
    let mut deferred_peer_message: Option<anyhow::Result<Option<Message>>> = None;
    // Protocol obligations are process-owned by generation-safe connection
    // identity. The socket loop retains the only writer and upload-read futures.
    let mut upload_request_drops = 0u64;
    let mut download_generation = 0u64;
    let mut upload_accounting_batch = UploadAccountingBatch::default();
    let upload_accounting_flush = sleep(UPLOAD_ACCOUNTING_MAX_DELAY);
    tokio::pin!(upload_accounting_flush);

    let result: anyhow::Result<()> = async {
        'peer: loop {
        // Poll the decoder once while upload dispatch is pending. Any complete
        // frames already in the socket buffer are processed first, up to a
        // small hard cap. Staggered refills from a pipelined peer may collect
        // until the bounded deadline; a serial requester dispatches at once.
        if deferred_peer_message.is_none()
            && upload_dispatch_pending
            && upload_intake_messages < MAX_READY_UPLOAD_INTAKE_MESSAGES
        {
            deferred_peer_message = peer_io.try_next_ready();
        }
        let dispatch_upload_reads_now = upload_dispatch_pending
            && deferred_peer_message.is_none()
            && (upload_choked
                || upload.plane != Plane::V1
                || upload_intake_messages >= upload_pipeline_width
                || upload_coalescing_expired);
        tokio::select! {
            cmd = peer_cmd_rx.recv() => {
                let Some(cmd) = cmd else {
                    // A dropped command sender means the owner can no
                    // longer control this peer. Do not leave the socket and
                    // its global peer permit alive until the idle timeout.
                    break;
                };
                last_activity = Instant::now();
                match cmd {
                    PeerCommand::Request {
                        request: req,
                        download_generation: request_generation,
                        memory_lease,
                        rate_grant,
                        source_permit,
                    } => {
                        if download_choked || request_generation != download_generation {
                            // The engine may have queued a request just
                            // before the remote choke event reached it. Do
                            // not put that request on the wire; the engine's
                            // Choked event releases its reservation.
                            continue;
                        }
                        let canonical_block = BlockExtent::new(req.piece, req.begin, req.length);
                        let Some(wire_block) = upload.canonical_to_wire_block(canonical_block)
                        else {
                            if upload.plane != Plane::V2
                                || !upload.v1_block_is_padding_only(canonical_block)
                            {
                                outstanding.push(OutstandingRequest::with_rate_grant(
                                    req,
                                    req,
                                    Some(memory_lease),
                                    rate_grant,
                                    source_permit,
                                ));
                                anyhow::bail!(
                                    "hybrid v2 peer request has no matching wire content range"
                                );
                            }

                            // BEP 47 padding has no v2 wire request. Synthesize
                            // its canonical zero block locally so a v2 peer
                            // can complete the same v1 piece assembly.
                            drop(rate_grant);
                            drop(source_permit);
                            let block = LeasedBlockEvent::with_optional_lease(
                                BlockEvent {
                                    piece: req.piece,
                                    offset: req.begin,
                                    data: bytes::Bytes::from(vec![0; req.length as usize]),
                                },
                                Some(memory_lease),
                                Some(0),
                            )?
                            .with_network_bytes(0);
                            if !send_peer_event(
                                &peer_event_tx,
                                PeerEvent::Piece {
                                    peer: addr,
                                    id: peer_id,
                                    block,
                                },
                            )
                            .await
                            {
                                break;
                            }
                            continue;
                        };
                        let wire_req = BlockRequest {
                            piece: wire_block.piece,
                            begin: wire_block.begin,
                            length: wire_block.length,
                        };
                        if let Err(error) = peer_io
                            .send(Message::Request {
                                piece: wire_req.piece,
                                begin: wire_req.begin,
                                length: wire_req.length,
                            })
                        .await
                        {
                            // The torrent actor reserved this block before
                            // enqueueing the command. Preserve it for the
                            // terminal disconnect event when the socket
                            // rejects the write, otherwise the picker can
                            // strand the block as permanently requested.
                            outstanding.push(OutstandingRequest::with_rate_grant(
                                req,
                                wire_req,
                                Some(memory_lease),
                                rate_grant,
                                source_permit,
                            ));
                            return Err(error);
                        }
                        outstanding.push(OutstandingRequest::with_rate_grant(
                            req,
                            wire_req,
                            Some(memory_lease),
                            rate_grant,
                            source_permit,
                        ));
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::RequestSent {
                                peer: addr,
                                id: peer_id,
                                request: req,
                            },
                        )
                        .await
                        {
                            break;
                        }
                    }
                    PeerCommand::Cancel { request } => {
                        if outstanding.iter().any(|outstanding| {
                            outstanding.req.piece == request.piece
                                && outstanding.req.begin == request.begin
                                && outstanding.req.length == request.length
                        }) {
                            let Some(wire_block) = upload.canonical_to_wire_block(
                                BlockExtent::new(request.piece, request.begin, request.length),
                            ) else {
                                continue;
                            };
                            peer_io
                                .send(Message::Cancel {
                                    piece: wire_block.piece,
                                    begin: wire_block.begin,
                                    length: wire_block.length,
                                })
                                .await?;
                        }
                    }
                    PeerCommand::Have(piece) => {
                        upload.have_pieces.set(piece as usize, true);
                        peer_io.send(Message::Have(piece)).await?;
                    }
                    PeerCommand::Choke => {
                        upload.upload_control.cancel();
                        upload_choked = true;
                        peer_io.send(Message::Choke).await?;
                        for reject in upload_obligations.on_local_choke() {
                            send_upload_obligation_reject(&mut peer_io, &upload, reject).await?;
                        }
                        upload_dispatch_pending = false;
                        upload_intake_messages = 0;
                        upload_pipeline_width = 1;
                        start_upload_reads(
                            &mut upload_reads,
                            &upload_obligations,
                            &upload,
                            &upload_read_context,
                            make_upload_read_future,
                        )?;
                        if !upload.fast_negotiated {
                            // A local choke invalidates reads that were
                            // admitted under the previous upload state. Drop
                            // them now so a slow disk cannot retain peer
                            // memory until the per-read timeout.
                            abort_upload_reads(&mut upload_reads);
                        }
                    }
                    PeerCommand::Unchoke => {
                        upload.upload_control.cancel();
                        upload_choked = false;
                        upload_obligations.on_local_unchoke();
                        peer_io.send(Message::Unchoke).await?;
                        upload_dispatch_pending = false;
                        upload_intake_messages = 0;
                        upload_pipeline_width = 1;
                        start_upload_reads(
                            &mut upload_reads,
                            &upload_obligations,
                            &upload,
                            &upload_read_context,
                            make_upload_read_future,
                        )?;
                    }
                    PeerCommand::Shutdown => {
                        upload.upload_control.cancel();
                        upload.shutdown_control.cancel();
                        upload_obligations.close();
                        break;
                    }
                }
            }
            msg_result = async {
                match deferred_peer_message.take() {
                    Some(result) => result,
                    None => peer_io.next().await,
                }
            }, if !dispatch_upload_reads_now => {
                let Some(msg) = msg_result? else {
                    break;
                };
                if upload_dispatch_pending {
                    upload_intake_messages =
                        upload_intake_messages.saturating_add(1);
                }
                last_activity = Instant::now();
                let (msg, _message_memory_lease) = msg.into_accounted_parts()?;
                match msg {
                    Message::Bitfield(bits) => {
                        if let Err(error) = validate_bitfield_shape(&bits, upload.have_pieces.len()) {
                            debug!(
                                component = "peer",
                                operation = "parse_bitfield",
                                peer = %addr,
                                result = "error",
                                error = %error,
                                "ignoring invalid bitfield"
                            );
                            continue;
                        }
                        // The previous upload-side bitmap remains live until
                        // the actor replaces it, so reserve the incoming map
                        // before allocating it and account for both copies
                        // during this handoff.
                        let memory_lease = match reserve_peer_bitfield_len(
                            &upload.resources,
                            upload.have_pieces.len(),
                        ) {
                            Ok(lease) => lease,
                            Err(error) => {
                                debug!(
                                    component = "peer",
                                    operation = "reserve_bitfield_memory",
                                    peer = %addr,
                                    result = "denied",
                                    error = %error,
                                    "disconnecting peer because its bitfield exceeds the memory budget"
                                );
                                break;
                            }
                        };
                        let pieces = PieceBitmap::from_validated_bitfield(
                            &bits,
                            upload.have_pieces.len(),
                        );
                        // The packed bitmap is now the event's only copy. Do
                        // not retain the wire buffer while waiting for the
                        // bounded actor mailbox.
                        drop(bits);
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::Bitfield {
                                peer: addr,
                                id: peer_id,
                                pieces,
                                _memory_lease: memory_lease,
                            },
                        )
                        .await
                        {
                            break;
                        }
                    }
                    Message::Have(piece) => {
                        if piece as usize >= upload.have_pieces.len() {
                            debug!(
                                component = "peer",
                                operation = "handle_have",
                                peer = %addr,
                                piece,
                                result = "ignored",
                                reason = "out_of_range",
                                "ignoring out-of-range have"
                            );
                            continue;
                        }
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::Have {
                                peer: addr,
                                id: peer_id,
                                piece,
                            },
                        )
                        .await
                        {
                            break;
                        }
                    }
                    // BEP 6 Fast extension: HaveAll/HaveNone stand in for a
                    // full or empty Bitfield. Feed the same availability
                    // path a real Bitfield would use so downstream piece
                    // selection/interest logic does not need to know the
                    // difference.
                    Message::HaveAll => {
                        let memory_lease = match reserve_peer_bitfield_len(
                            &upload.resources,
                            upload.have_pieces.len(),
                        ) {
                            Ok(lease) => lease,
                            Err(error) => {
                                debug!(
                                    component = "peer",
                                    operation = "reserve_bitfield_memory",
                                    peer = %addr,
                                    result = "denied",
                                    error = %error,
                                    "disconnecting peer because its fast-extension have-state exceeds the memory budget"
                                );
                                break;
                            }
                        };
                        let pieces = PieceBitmap::all_true(upload.have_pieces.len());
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::Bitfield {
                                peer: addr,
                                id: peer_id,
                                pieces,
                                _memory_lease: memory_lease,
                            },
                        )
                        .await
                        {
                            break;
                        }
                    }
                    Message::HaveNone => {
                        let memory_lease = match reserve_peer_bitfield_len(
                            &upload.resources,
                            upload.have_pieces.len(),
                        ) {
                            Ok(lease) => lease,
                            Err(error) => {
                                debug!(
                                    component = "peer",
                                    operation = "reserve_bitfield_memory",
                                    peer = %addr,
                                    result = "denied",
                                    error = %error,
                                    "disconnecting peer because its fast-extension have-state exceeds the memory budget"
                                );
                                break;
                            }
                        };
                        let pieces = PieceBitmap::new(upload.have_pieces.len());
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::Bitfield {
                                peer: addr,
                                id: peer_id,
                                pieces,
                                _memory_lease: memory_lease,
                            },
                        )
                        .await
                        {
                            break;
                        }
                    }
                    Message::Piece { piece, begin, data } => {
                        let data_len = data.len() as u32;
                        let wire_extent = BlockExtent::new(piece, begin, data_len);
                        let Some(mut requested) =
                            take_matching_outstanding(&mut outstanding, piece, begin, data_len)
                        else {
                            warn!(
                                peer = %addr,
                                piece,
                                begin,
                                length = data_len,
                                "dropping unsolicited or mismatched piece block"
                            );
                            continue;
                        };
                        let Some((canonical_extent, canonical_data)) =
                            upload.expand_wire_block(wire_extent, &data)
                        else {
                            outstanding.push(requested);
                            anyhow::bail!(
                                "peer piece response does not map to the selected hybrid content plane"
                            );
                        };
                        let expected_canonical = BlockExtent::new(
                            requested.req.piece,
                            requested.req.begin,
                            requested.req.length,
                        );
                        if canonical_extent != expected_canonical {
                            outstanding.push(requested);
                            anyhow::bail!(
                                "peer piece response mapped to a different canonical request"
                            );
                        }
                        let response_delay_nanos = Instant::now()
                            .saturating_duration_since(requested.sent_at)
                            .as_nanos()
                            .min(u128::from(u64::MAX))
                            as u64;
                        // The matching request reserved its rate grant before
                        // it went on wire. Charge the bytes that arrived and
                        // keep the protocol loop free while the actor waits for
                        // storage admission.
                        if let Some(grant) = requested.rate_grant.take() {
                            grant.settle(u64::from(data_len));
                        }
                        let block = match LeasedBlockEvent::with_optional_lease(
                            BlockEvent {
                                piece: canonical_extent.piece,
                                offset: canonical_extent.begin,
                                data: canonical_data,
                            },
                            requested.memory_lease.take(),
                            Some(response_delay_nanos),
                        ) {
                            Ok(block) => block.with_network_bytes(u64::from(data_len)),
                            Err(error) => {
                                outstanding.push(OutstandingRequest::new(requested.req, None));
                                debug!(
                                    component = "peer",
                                    operation = "retain_piece_payload",
                                    peer = %addr,
                                    piece,
                                    begin,
                                    result = "rejected",
                                    error = %error,
                                    "disconnecting peer because received payload exceeded its reservation"
                                );
                                break;
                            }
                        };
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::Piece {
                                peer: addr,
                                id: peer_id,
                                block,
                            },
                        )
                        .await
                        {
                            // The payload and its lease are dropped with the
                            // undelivered event. Keep only the coordinate so
                            // the terminal disconnect event releases the
                            // actor's picker reservation.
                            outstanding.push(OutstandingRequest::new(requested.req, None));
                            break; // torrent task gone
                        }
                    }
                    Message::Reject {
                        piece,
                        begin,
                        length,
                    } => {
                        let Some(requested) =
                            take_matching_outstanding(&mut outstanding, piece, begin, length)
                        else {
                            debug!(
                                component = "peer",
                                operation = "handle_reject",
                                peer = %addr,
                                piece,
                                begin,
                                length,
                                result = "ignored",
                                reason = "unsolicited",
                                "ignoring reject for a request that is not outstanding"
                            );
                            continue;
                        };
                        let rejected = requested.req;
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::RequestRejected {
                                peer: addr,
                                id: peer_id,
                                rejected,
                            },
                        )
                        .await
                        {
                            outstanding.push(OutstandingRequest::new(rejected, None));
                            break;
                        }
                    }
                    // BEP 6 Fast extension: this is an optional request
                    // hint. The picker still follows ordinary choke state,
                    // so accepting the message keeps interoperable peers
                    // alive without bypassing request admission controls.
                    Message::AllowedFast(_) => {}
                    Message::Unchoke => {
                        download_choked = false;
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::Unchoked {
                                peer: addr,
                                id: peer_id,
                                download_generation,
                            },
                        )
                        .await
                        {
                            break;
                        }
                    }
                    Message::Interested => {
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::Interested {
                                peer: addr,
                                id: peer_id,
                            },
                        )
                        .await
                        {
                            break;
                        }
                    }
                    Message::NotInterested => {
                        if !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::NotInterested {
                                peer: addr,
                                id: peer_id,
                            },
                        )
                        .await
                        {
                            break;
                        }
                    }
                    Message::Request { piece, begin, length } => {
                        let wire_block = BlockExtent::new(piece, begin, length);
                        let Some(block) = upload.wire_to_canonical_block(wire_block) else {
                            reject_upload_request(
                                &mut peer_io,
                                &upload,
                                UploadRequest::from_wire(wire_block),
                            )
                            .await?;
                            continue;
                        };
                        let request = UploadRequest::new(block, wire_block);
                        let have_piece = upload
                            .have_pieces
                            .get(block.piece as usize)
                            .unwrap_or(false);
                        let decision = upload_obligations.admit(block, have_piece);
                        if matches!(
                            decision,
                            InboundDecision::Reject(InboundRejectReason::QueueFull)
                                | InboundDecision::Drop(InboundRejectReason::QueueFull)
                        ) {
                            upload_request_drops = upload_request_drops.saturating_add(1);
                            if upload_request_drops == 1 || upload_request_drops.is_multiple_of(256)
                            {
                                debug!(
                                    component = "peer",
                                    operation = "queue_upload_request",
                                    peer = %addr,
                                    result = "refused",
                                    reason = "upload_queue_saturated",
                                    dropped = upload_request_drops,
                                    "refusing excess upload requests without terminating peer"
                                );
                            }
                        }
                        match decision {
                            InboundDecision::Queue => {
                                upload_pipeline_width = upload_pipeline_width.max(
                                    upload_reads.pending_request_count()
                                        .saturating_add(upload_obligations.queued_len())
                                        .min(MAX_READY_UPLOAD_INTAKE_MESSAGES),
                                );
                                if !upload_dispatch_pending {
                                    upload_dispatch_pending = true;
                                    upload_intake_messages = 1;
                                    upload_coalescing_expired = false;
                                    upload_coalescing_flush.as_mut().reset(
                                        TokioInstant::now() + UPLOAD_READ_COALESCE_MAX_DELAY,
                                    );
                                }
                            }
                            InboundDecision::Reject(_) => {
                                reject_upload_request(&mut peer_io, &upload, request).await?;
                            }
                            InboundDecision::Drop(_) | InboundDecision::Duplicate => {}
                        }
                    }
                    Message::Cancel { piece, begin, length } => {
                        let wire_block = BlockExtent::new(piece, begin, length);
                        let Some(block) = upload.wire_to_canonical_block(wire_block) else {
                            continue;
                        };
                        if let Some(reject) = upload_obligations.on_cancel(block) {
                            send_upload_obligation_reject(&mut peer_io, &upload, reject).await?;
                        }
                    }
                    Message::Choke => {
                        download_choked = true;
                        download_generation = download_generation.wrapping_add(1);
                        let choked_requests = take_choked_requests(
                            &mut outstanding,
                            upload.fast_negotiated,
                        );
                        if !send_choke_event(
                            &peer_event_tx,
                            addr,
                            peer_id,
                            download_generation,
                            upload.fast_negotiated,
                            choked_requests,
                            &mut outstanding,
                        )
                        .await
                        {
                            break;
                        }
                        warn!(
                            component = "peer",
                            operation = "handle_choke",
                            peer = %addr,
                            result = "choked",
                            "choked"
                        );
                    }
                    Message::KeepAlive => {}
                    Message::Extended { ext_id: EXT_HANDSHAKE_ID, payload } => {
                        match ExtensionHandshake::parse(&payload) {
                            Ok(handshake) => {
                                remote_ut_metadata_id = handshake.ut_metadata_id();
                                if !send_peer_event(
                                    &peer_event_tx,
                                    PeerEvent::ExtendedHandshake {
                                        peer: addr,
                                        id: peer_id,
                                        ut_metadata_id: handshake.ut_metadata_id(),
                                        ut_pex_id: handshake.ut_pex_id(),
                                        metadata_size: handshake.metadata_size,
                                        reqq: handshake.reqq,
                                    },
                                )
                                .await
                                {
                                    break;
                                }
                            }
                            Err(e) => {
                                debug!(
                                    component = "peer",
                                    operation = "parse_extension_handshake",
                                    peer = %addr,
                                    result = "error",
                                    error = %e,
                                    "ignoring invalid extension handshake"
                                );
                            }
                        }
                    }
                    Message::Extended { ext_id: LOCAL_UT_METADATA_ID, payload } => {
                        match UtMetadataMessage::parse(&payload) {
                            Ok(UtMetadataMessage::Request { piece }) => {
                                let Some(remote_ut_metadata_id) = remote_ut_metadata_id else {
                                    debug!(
                                        component = "peer",
                                        operation = "send_ut_metadata",
                                        peer = %addr,
                                        result = "ignored",
                                        reason = "remote_extension_id_unknown",
                                        "ignoring metadata request before peer extension negotiation"
                                    );
                                    continue;
                                };
                                let response = upload
                                    .metadata
                                    .as_ref()
                                    .map(|metadata| metadata_response(piece, metadata))
                                    .unwrap_or(UtMetadataMessage::Reject { piece });
                                peer_io.send(Message::Extended {
                                    ext_id: remote_ut_metadata_id,
                                    payload: response.encode(),
                                }).await?;
                            }
                            Ok(_) => {}
                            Err(e) => {
                                debug!(
                                    component = "peer",
                                    operation = "parse_ut_metadata",
                                    peer = %addr,
                                    result = "error",
                                    error = %e,
                                    "ignoring invalid ut_metadata message"
                                );
                            }
                        }
                    }
                    Message::Extended { ext_id: LOCAL_UT_PEX_ID, payload } => {
                        if !upload.pex_enabled || upload.is_private {
                            continue;
                        }
                        match parse_ut_pex_peers(&payload) {
                            Ok(pex) if !pex.added.is_empty() || !pex.dropped.is_empty() => {
                                let memory_bytes = pex
                                    .added
                                    .capacity()
                                    .saturating_add(pex.dropped.capacity())
                                    .saturating_mul(std::mem::size_of::<SocketAddr>());
                                let memory_lease = match reserve_peer_event_bytes(
                                    &upload.resources,
                                    memory_bytes,
                                ) {
                                    Ok(lease) => lease,
                                    Err(error) => {
                                        debug!(
                                            component = "peer",
                                            operation = "reserve_pex_event_memory",
                                            peer = %addr,
                                            result = "denied",
                                            error = %error,
                                            "disconnecting peer because its peer-exchange payload exceeds the memory budget"
                                        );
                                        break;
                                    }
                                };
                                if !send_peer_event(
                                    &peer_event_tx,
                                    PeerEvent::PeerExchange {
                                        peer: addr,
                                        id: peer_id,
                                        peers: pex.added,
                                        dropped: pex.dropped,
                                        _memory_lease: memory_lease,
                                    },
                                )
                                .await
                                {
                                    break;
                                }
                            }
                            Ok(_) => {}
                            Err(e) => {
                                debug!(
                                    component = "peer",
                                    operation = "parse_ut_pex",
                                    peer = %addr,
                                    result = "error",
                                    error = %e,
                                    "ignoring invalid ut_pex message"
                                );
                            }
                        }
                    }
                    _ => {}
                }
            }
            upload_result = upload_reads.next(), if !upload_reads.is_empty() => {
                let Some(upload_completions) = upload_result else {
                    continue;
                };
                let mut ready_uploads = UploadBatch::new();
                for upload_completion in upload_completions {
                    upload_reads.finish_request();
                    let (request, result, rate_interrupted) = match upload_completion {
                        UploadReadCompletion::Completed {
                            request,
                            result,
                            rate_interrupted,
                        } => (request, result, rate_interrupted),
                        UploadReadCompletion::Panicked { request } => {
                            warn!(
                                component = "peer",
                                operation = "read_upload_block",
                                peer = %addr,
                                piece = request.piece,
                                begin = request.begin,
                                result = "future_panicked",
                                "upload block read future panicked; closing peer"
                            );
                            // End this connection so the accepted obligation and
                            // every sibling read are released together.
                            upload_obligations.close();
                            break 'peer;
                        }
                    };
                    let block_extent = request.canonical_block();
                    match result {
                        Ok(_block) if rate_interrupted => {
                            // Rate admission runs within the bounded read future, so
                            // a slow limit cannot stop this loop from consuming
                            // peer input or control messages. If the peer remains
                            // unchoked, retry valid demand after the control wake;
                            // otherwise terminate it according to Fast semantics.
                            if upload_choked {
                                if upload_obligations.may_send(&block_extent) {
                                    if !upload_obligations.requeue_front(block_extent) {
                                        anyhow::bail!("v1 allowed-fast upload could not be requeued");
                                    }
                                } else {
                                    finish_upload_obligation(
                                        &mut peer_io,
                                        &upload,
                                        &upload_obligations,
                                        block_extent,
                                        InboundServed::Discarded,
                                    )
                                    .await?;
                                }
                            } else if !upload_obligations.requeue_front(block_extent) {
                                anyhow::bail!("v1 upload obligation could not be requeued");
                            }
                        }
                        Ok(upload_block) if upload_obligations.may_send(&block_extent) => {
                            ready_uploads.push((request, upload_block));
                        }
                        Ok(_) => {
                            // A local choke or shutdown may have arrived while
                            // the read was in flight. Drop the leased block and
                            // resolve this request without affecting its siblings.
                            finish_upload_obligation(
                                &mut peer_io,
                                &upload,
                                &upload_obligations,
                                block_extent,
                                InboundServed::Discarded,
                            )
                            .await?;
                        }
                        Err(error) => {
                            warn!(
                                component = "peer",
                                operation = "read_upload_block",
                                peer = %addr,
                                piece = request.piece,
                                begin = request.begin,
                                length = request.length,
                                result = "error",
                                error = %error,
                                "failed to read upload block"
                            );
                            finish_upload_obligation(
                                &mut peer_io,
                                &upload,
                                &upload_obligations,
                                block_extent,
                                InboundServed::Failed,
                            )
                            .await?;
                        }
                    }
                }

                if !ready_uploads.is_empty() {
                    let frames = ready_uploads
                        .iter()
                        .map(|(request, block)| {
                            (request.wire_piece, request.wire_begin, &block.data)
                        })
                        .collect::<UploadBatch<_>>();
                    let (completed_frames, send_error) = match peer_io.send_pieces(&frames).await {
                        Ok(completed) => (completed, None),
                        Err((completed, error)) => (completed, Some(error)),
                    };
                    drop(frames);
                    let completed_frames = completed_frames.min(ready_uploads.len());
                    let mut upload_event_due = false;
                    for (request, mut block) in ready_uploads
                        .into_iter()
                        .take(completed_frames)
                    {
                        let bytes = block.data.len() as u64;
                        if let Some(grant) = block.rate_grant.take() {
                            grant.settle(bytes);
                        }
                        let first_unreported_block = upload_accounting_batch.is_empty();
                        atomic_saturating_add(
                            &upload.upload_accounting.pending_uploaded_bytes,
                            bytes,
                        );
                        let batch_ready = upload_accounting_batch.add(
                            bytes,
                            upload
                                .upload_accounting
                                .batch_bytes
                                .load(Ordering::Relaxed),
                        );
                        if first_unreported_block {
                            upload_accounting_flush.as_mut().reset(
                                TokioInstant::now() + UPLOAD_ACCOUNTING_MAX_DELAY,
                            );
                        }
                        if batch_ready {
                            upload_event_due = true;
                            upload_accounting_batch.clear();
                        }
                        finish_upload_obligation(
                            &mut peer_io,
                            &upload,
                            &upload_obligations,
                            request.canonical_block(),
                            InboundServed::Sent,
                        )
                        .await?;
                    }
                    if upload_event_due
                        && !send_peer_event(
                            &peer_event_tx,
                            PeerEvent::Uploaded {
                                peer: addr,
                                id: peer_id,
                            },
                        )
                        .await
                    {
                        break 'peer;
                    }
                    if upload_event_due {
                        upload_accounting_batch.clear();
                    }
                    if let Some(error) = send_error {
                        return Err(error);
                    }
                }

                if !upload_dispatch_pending {
                    upload_intake_messages = 0;
                    start_upload_reads(
                        &mut upload_reads,
                        &upload_obligations,
                        &upload,
                        &upload_read_context,
                        make_upload_read_future,
                    )?;
                }
            }
            _ = std::future::ready(()), if dispatch_upload_reads_now => {
                if upload_coalescing_expired
                    && upload_obligations.queued_len() <= 1
                    && upload_reads.pending_request_count() == 0
                {
                    // A peer may shrink its window after the initial burst.
                    // One solitary deadline flush restores immediate service.
                    upload_pipeline_width = 1;
                }
                upload_dispatch_pending = false;
                upload_intake_messages = 0;
                start_upload_reads(
                    &mut upload_reads,
                    &upload_obligations,
                    &upload,
                    &upload_read_context,
                    make_upload_read_future,
                )?;
            }
            _ = upload_coalescing_flush.as_mut(),
                if upload_dispatch_pending && !upload_coalescing_expired => {
                upload_coalescing_expired = true;
            }
            _ = timeout_tick.tick() => {
                if last_activity.elapsed() > PEER_IDLE_TIMEOUT {
                    anyhow::bail!("peer idle timeout");
                }
                let timed_out = take_timed_out_requests(&mut outstanding, Duration::from_secs(60));
                if !timed_out.is_empty()
                    && !send_peer_event(
                        &peer_event_tx,
                        PeerEvent::RequestTimedOut {
                            peer: addr,
                            id: peer_id,
                            timed_out: timed_out.clone(),
                        },
                    )
                    .await
                {
                    outstanding.extend(
                        timed_out
                            .into_iter()
                            .map(|request| OutstandingRequest::new(request, None)),
                    );
                    break;
                }
            }
            _ = upload_accounting_flush.as_mut(), if !upload_accounting_batch.is_empty() => {
                if !send_peer_event(
                    &peer_event_tx,
                    PeerEvent::Uploaded {
                        peer: addr,
                        id: peer_id,
                    },
                )
                .await
                {
                    break;
                }
                upload_accounting_batch.clear();
            }
        }
        }
        Ok(())
    }
    .await;

    // Keep this outside the result-producing block: socket, framing, and
    // event-delivery errors can leave that block through `?`, bypassing the
    // normal loop break. Drop in-flight reads immediately so their permits,
    // memory leases, and scheduler work do not survive peer exit.
    upload_obligations.close();
    abort_upload_reads(&mut upload_reads);

    let outstanding = drain_outstanding(&mut outstanding);
    if send_terminal_event_on_peer_channel {
        let _ = send_peer_event(
            &peer_event_tx,
            PeerEvent::Disconnected {
                peer: addr,
                id: peer_id,
                outstanding: outstanding.clone(),
            },
        )
        .await;
    }
    PeerLoopExit {
        result,
        outstanding,
    }
}

async fn send_extension_handshake(
    peer_io: &mut PeerIo,
    metadata: Option<&Arc<Vec<u8>>>,
    is_private: bool,
    pex_enabled: bool,
    remote_supports_extension: bool,
) -> anyhow::Result<()> {
    if remote_supports_extension {
        let handshake = extension_handshake_for_torrent(metadata, is_private, pex_enabled);
        peer_io
            .send(Message::Extended {
                ext_id: EXT_HANDSHAKE_ID,
                payload: handshake.encode(),
            })
            .await?;
    }
    Ok(())
}

fn extension_handshake_for_torrent(
    metadata: Option<&Arc<Vec<u8>>>,
    is_private: bool,
    pex_enabled: bool,
) -> ExtensionHandshake {
    let metadata_size = metadata.and_then(|bytes| u32::try_from(bytes.len()).ok());
    let mut handshake = ExtensionHandshake::new(metadata_size).with_reqq(MAX_UPLOAD_WORK);
    if metadata_size.is_some() {
        handshake = handshake.with_ut_metadata(LOCAL_UT_METADATA_ID);
    }
    if pex_enabled && !is_private {
        handshake = handshake.with_ut_pex(LOCAL_UT_PEX_ID);
    }
    handshake
}

fn metadata_response(piece: u32, metadata: &[u8]) -> UtMetadataMessage {
    let Some(start) = (piece as usize).checked_mul(METADATA_PIECE_SIZE) else {
        return UtMetadataMessage::Reject { piece };
    };
    if start >= metadata.len() {
        return UtMetadataMessage::Reject { piece };
    }
    let Some(end) = start
        .checked_add(METADATA_PIECE_SIZE)
        .map(|end| end.min(metadata.len()))
    else {
        return UtMetadataMessage::Reject { piece };
    };
    let Ok(total_size) = u32::try_from(metadata.len()) else {
        return UtMetadataMessage::Reject { piece };
    };
    UtMetadataMessage::Data {
        piece,
        total_size,
        data: metadata[start..end].to_vec(),
    }
}

#[derive(Debug)]
struct OutstandingRequest {
    /// Canonical v1 coordinate exposed to the torrent actor.
    req: BlockRequest,
    /// Coordinate used for matching replies on this connection's wire plane.
    wire_req: BlockRequest,
    sent_at: Instant,
    /// Expected response capacity remains charged until the block event takes
    /// ownership or this request reaches a terminal lifecycle path.
    memory_lease: Option<MemoryLease>,
    /// Download credit is reserved before the request goes on wire and is
    /// refunded if no matching payload arrives.
    rate_grant: Option<RateAdmissionGrant>,
    /// Shared process/torrent admission remains held until this wire request
    /// reaches a terminal response or cancellation path.
    _source_permit: Option<SourceRequestPermit>,
}

impl OutstandingRequest {
    fn new(req: BlockRequest, memory_lease: Option<MemoryLease>) -> Self {
        Self {
            req,
            wire_req: req,
            sent_at: Instant::now(),
            memory_lease,
            rate_grant: None,
            _source_permit: None,
        }
    }

    fn with_rate_grant(
        req: BlockRequest,
        wire_req: BlockRequest,
        memory_lease: Option<MemoryLease>,
        rate_grant: Option<RateAdmissionGrant>,
        source_permit: Option<SourceRequestPermit>,
    ) -> Self {
        Self {
            req,
            wire_req,
            sent_at: Instant::now(),
            memory_lease,
            rate_grant,
            _source_permit: source_permit,
        }
    }
}

async fn send_have_state(
    peer_io: &mut PeerIo,
    have_pieces: &PieceBitmap,
    resources: &ResourceGovernor,
    remote_supports_fast: bool,
) -> anyhow::Result<()> {
    let total = have_pieces.len();
    let have = have_pieces.count_ones();
    // BEP 6 Fast extension: a peer that has everything or nothing can skip
    // the full bitfield entirely. Only take this path with peers that
    // negotiated Fast-extension support during the handshake; peers that
    // did not must keep getting exactly today's behavior (a normal
    // Bitfield, or nothing at all when we have zero pieces).
    if remote_supports_fast {
        if total > 0 && have == total {
            peer_io.send(Message::HaveAll).await?;
            return Ok(());
        }
        if have == 0 {
            peer_io.send(Message::HaveNone).await?;
            return Ok(());
        }
    } else if have == 0 {
        return Ok(());
    }
    let _wire_memory_lease = reserve_peer_bitfield_wire_bytes(resources, have_pieces)?;
    let bitfield = have_pieces.to_bitfield();
    peer_io.send(Message::Bitfield(bitfield)).await?;
    Ok(())
}

#[cfg(test)]
async fn read_upload_block(
    upload: &UploadReadContext,
    request: UploadRequest,
    choke_critical: bool,
) -> anyhow::Result<LeasedUploadBlock> {
    read_upload_block_with_span(upload, request, choke_critical, None).await
}

async fn read_upload_block_with_span(
    upload: &UploadReadContext,
    request: UploadRequest,
    choke_critical: bool,
    span: Option<&UploadReadSpan>,
) -> anyhow::Result<LeasedUploadBlock> {
    let canonical = request.canonical_block();
    let length = canonical.length;
    if length == 0 || length > MAX_BLOCK_SIZE {
        anyhow::bail!("invalid upload block length {length}");
    }
    let _read_permit = upload
        .read_admission
        .acquire_read(canonical)
        .await
        .map_err(|error| anyhow::anyhow!("global upload read admission failed: {error:?}"))?;
    if span.is_none() {
        PieceGeometry::validate_served_block(&upload.piece_map, canonical)?;
    }
    let lease = reserve_peer_upload_bytes(&upload.resources, length)?;
    let deadline = Instant::now() + PEER_SOCKET_WRITE_TIMEOUT;
    let priority = if choke_critical {
        IoRequestPriority::choke_critical(deadline)
    } else {
        IoRequestPriority::deadline(deadline)
    };
    let canonical_data = if let Some(span) = span {
        anyhow::ensure!(
            upload.plane == Plane::V1 && span.length == length as usize,
            "cached upload span does not match its admitted request"
        );
        let path = upload
            .piece_map
            .file_by_ordinal(span.file_ordinal)
            .ok_or_else(|| anyhow::anyhow!("upload span file is outside its piece map"))?
            .path
            .resolve(&upload.save_root);
        let read = upload
            .storage
            .read_owned_at_with_priority(
                IoClass::PeerRead,
                &path,
                span.offset,
                span.length,
                priority,
            )
            .await?;
        anyhow::ensure!(
            read.len() == length as usize,
            "upload block read returned {} bytes, expected {}",
            read.len(),
            length
        );
        read.into_bytes()
    } else {
        let mut regions = upload
            .piece_map
            .request_regions(canonical.piece, canonical.begin, length)?
            .peekable();
        let first = regions
            .next()
            .ok_or_else(|| anyhow::anyhow!("upload request has no file regions"))?;
        if regions.peek().is_none() && !first.pad {
            let region = first;
            let path = region.path.resolve(&upload.save_root);
            let read = upload
                .storage
                .read_owned_at_with_priority(
                    IoClass::PeerRead,
                    &path,
                    region.file_offset,
                    region.length as usize,
                    priority,
                )
                .await?;
            anyhow::ensure!(
                read.len() == length as usize,
                "upload block read returned {} bytes, expected {}",
                read.len(),
                length
            );
            read.into_bytes()
        } else {
            let mut data = Vec::with_capacity(length as usize);
            for region in std::iter::once(first).chain(regions) {
                if region.pad {
                    data.resize(data.len() + region.length as usize, 0);
                    continue;
                }
                let path = region.path.resolve(&upload.save_root);
                let read = upload
                    .storage
                    .read_owned_at_with_priority(
                        IoClass::PeerRead,
                        &path,
                        region.file_offset,
                        region.length as usize,
                        priority,
                    )
                    .await?;
                data.extend_from_slice(read.as_slice());
            }
            if data.len() != length as usize {
                anyhow::bail!(
                    "upload block read assembled {} bytes, expected {}",
                    data.len(),
                    length
                );
            }
            bytes::Bytes::from(data)
        }
    };
    let (wire, data) = match upload.plane {
        Plane::V1 => (canonical, canonical_data),
        Plane::V2 => {
            let Some((wire, data)) = upload
                .hybrid_v2
                .as_ref()
                .and_then(|hybrid| hybrid.geometry.as_ref())
                .and_then(|geometry| geometry.project_v1_block_to_v2(canonical, canonical_data))
            else {
                anyhow::bail!("canonical upload block has no matching v2 content range");
            };
            (wire, data)
        }
    };
    anyhow::ensure!(
        wire == request.wire_block(),
        "projected upload block does not match its admitted wire request"
    );
    Ok(LeasedUploadBlock {
        data,
        _lease: UploadMemoryLease::Single { _lease: lease },
        _read_permit,
        rate_grant: None,
    })
}

/// Answer a request we will not serve. With Fast negotiated BEP 6 requires an
/// explicit Reject Request; without it the legacy behaviour (silence) stands.
async fn reject_upload_request(
    peer_io: &mut PeerIo,
    upload: &UploadContext,
    request: UploadRequest,
) -> anyhow::Result<()> {
    if upload.fast_negotiated {
        peer_io
            .send(Message::Reject {
                piece: request.wire_piece,
                begin: request.wire_begin,
                length: request.wire_length,
            })
            .await?;
    }
    Ok(())
}

async fn send_upload_obligation_reject(
    peer_io: &mut PeerIo,
    upload: &UploadContext,
    reject: InboundReject,
) -> anyhow::Result<()> {
    let block = upload
        .canonical_to_wire_block(reject.block)
        .ok_or_else(|| anyhow::anyhow!("upload rejection has no matching wire extent"))?;
    peer_io
        .send(Message::Reject {
            piece: block.piece,
            begin: block.begin,
            length: block.length,
        })
        .await?;
    Ok(())
}

async fn finish_upload_obligation(
    peer_io: &mut PeerIo,
    upload: &UploadContext,
    obligations: &SharedUploadPeer,
    block: BlockExtent,
    served: InboundServed,
) -> anyhow::Result<()> {
    if let Some(reject) = obligations.finish(block, served) {
        send_upload_obligation_reject(peer_io, upload, reject).await?;
    }
    Ok(())
}

fn upload_read_spec(
    upload: &UploadContext,
    read_context: &UploadReadContext,
    obligations: &SharedUploadPeer,
    block: BlockExtent,
    queued: bool,
) -> anyhow::Result<UploadReadSpec> {
    let choke_critical = obligations.is_choked()
        && if queued {
            obligations.is_allowed_fast(block.piece)
        } else {
            obligations.may_send(&block)
        };
    let Some(wire_block) = upload.canonical_to_wire_block(block) else {
        obligations.close();
        anyhow::bail!("accepted upload obligation has no matching wire extent");
    };
    let request = UploadRequest::new(block, wire_block);
    Ok(UploadReadSpec {
        request,
        span: upload_read_span(read_context, request),
        choke_critical,
    })
}

fn upload_read_span(upload: &UploadReadContext, request: UploadRequest) -> Option<UploadReadSpan> {
    let canonical = request.canonical_block();
    if upload.plane != Plane::V1 || request.wire_block() != canonical {
        return None;
    }
    let mut regions = upload
        .piece_map
        .request_regions(canonical.piece, canonical.begin, canonical.length)
        .ok()?;
    let region = regions.next()?;
    if regions.next().is_some() || region.pad || region.length != canonical.length {
        return None;
    }
    Some(UploadReadSpan {
        file_ordinal: region.file_ordinal,
        offset: region.file_offset,
        length: region.length as usize,
    })
}

fn can_append_upload_read(
    batch: &[UploadReadSpec],
    next: &UploadReadSpec,
    batch_bytes: usize,
) -> bool {
    let Some(last) = batch.last() else {
        return false;
    };
    let (Some(last_span), Some(next_span)) = (&last.span, &next.span) else {
        return false;
    };
    if batch.len() >= MAX_UPLOAD_READ_BATCH_BLOCKS
        || last.request.piece != next.request.piece
        || last.choke_critical != next.choke_critical
        || last_span.file_ordinal != next_span.file_ordinal
        || last_span.offset.checked_add(last_span.length as u64) != Some(next_span.offset)
    {
        return false;
    }
    batch_bytes
        .checked_add(next_span.length)
        .is_some_and(|bytes| bytes <= MAX_UPLOAD_READ_BATCH_BYTES)
}

async fn read_upload_batch_blocks(
    upload: &UploadReadContext,
    specs: &[UploadReadSpec],
) -> anyhow::Result<UploadBatch<LeasedUploadBlock>> {
    anyhow::ensure!(
        !specs.is_empty() && specs.len() <= MAX_UPLOAD_READ_BATCH_BLOCKS,
        "upload batch has an invalid request count"
    );
    if specs.len() == 1 || specs.iter().any(|spec| spec.span.is_none()) {
        let mut blocks = UploadBatch::new();
        for spec in specs {
            blocks.push(
                read_upload_block_with_span(
                    upload,
                    spec.request,
                    spec.choke_critical,
                    spec.span.as_ref(),
                )
                .await?,
            );
        }
        return Ok(blocks);
    }

    anyhow::ensure!(
        upload.plane == Plane::V1,
        "only v1 upload reads can be batched"
    );
    let first = &specs[0];
    let first_span = first.span.as_ref().expect("batch span checked above");
    let mut total_len = 0usize;
    for (index, spec) in specs.iter().enumerate() {
        let span = spec.span.as_ref().expect("batch span checked above");
        let block = spec.request.canonical_block();
        anyhow::ensure!(
            spec.request.wire_block() == block
                && block.length > 0
                && block.length <= MAX_BLOCK_SIZE
                && span.length == block.length as usize
                && spec.choke_critical == first.choke_critical,
            "upload batch contains an invalid or mismatched request"
        );
        if index > 0 {
            let previous = &specs[index - 1];
            let previous_span = previous.span.as_ref().expect("batch span checked above");
            anyhow::ensure!(
                block.piece == previous.request.piece
                    && span.file_ordinal == first_span.file_ordinal
                    && previous_span
                        .offset
                        .checked_add(previous_span.length as u64)
                        == Some(span.offset),
                "upload batch crossed a piece, file, or non-contiguous extent"
            );
        }
        total_len = total_len
            .checked_add(span.length)
            .ok_or_else(|| anyhow::anyhow!("upload batch length overflow"))?;
    }
    anyhow::ensure!(
        total_len <= MAX_UPLOAD_READ_BATCH_BYTES,
        "upload batch exceeds its bounded read size"
    );

    let mut blocks = [BlockExtent::new(0, 0, 1); MAX_UPLOAD_READ_BATCH_BLOCKS];
    for (block, spec) in blocks.iter_mut().zip(specs) {
        *block = spec.request.canonical_block();
    }
    let read_permits = upload
        .read_admission
        .acquire_read_batch(&blocks[..specs.len()])
        .await
        .map_err(|error| anyhow::anyhow!("global upload read admission failed: {error:?}"))?;
    let shared_lease = Arc::new(reserve_peer_upload_bytes(
        &upload.resources,
        u32::try_from(total_len).map_err(|_| anyhow::anyhow!("upload batch exceeds u32"))?,
    )?);

    let deadline = Instant::now() + PEER_SOCKET_WRITE_TIMEOUT;
    let priority = if first.choke_critical {
        IoRequestPriority::choke_critical(deadline)
    } else {
        IoRequestPriority::deadline(deadline)
    };
    let path = upload
        .piece_map
        .file_by_ordinal(first_span.file_ordinal)
        .ok_or_else(|| anyhow::anyhow!("upload batch file is outside its piece map"))?
        .path
        .resolve(&upload.save_root);
    let read = upload
        .storage
        .read_owned_at_with_priority(
            IoClass::PeerRead,
            &path,
            first_span.offset,
            total_len,
            priority,
        )
        .await?;
    anyhow::ensure!(
        read.len() == total_len,
        "batched upload read returned {} bytes, expected {}",
        read.len(),
        total_len
    );
    let backing = read.into_bytes();
    let mut offset = 0usize;
    let mut blocks = UploadBatch::new();
    for (spec, read_permit) in specs.iter().zip(read_permits) {
        let length = spec.request.length as usize;
        let end = offset + length;
        blocks.push(LeasedUploadBlock {
            data: backing.slice(offset..end),
            _lease: UploadMemoryLease::Shared {
                _lease: Arc::clone(&shared_lease),
            },
            _read_permit: read_permit,
            rate_grant: None,
        });
        offset = end;
    }
    debug_assert_eq!(offset, total_len);
    Ok(blocks)
}

async fn upload_read_batch_future(
    specs: UploadBatch<UploadReadSpec>,
    read_context: Arc<UploadReadContext>,
) -> UploadBatch<UploadReadCompletion> {
    let panicked_requests = specs
        .iter()
        .map(|spec| spec.request)
        .collect::<UploadBatch<_>>();
    let read = async move {
        // Keep only one collection of successful blocks. Error and timeout
        // paths carry one message until each obligation is resolved; success
        // no longer rebuilds the block list as a second Vec<Result<_>>.
        let (blocks, error) = match timeout(
            PEER_UPLOAD_READ_TIMEOUT,
            read_upload_batch_blocks(&read_context, &specs),
        )
        .await
        {
            Ok(Ok(blocks)) => (blocks, None),
            // Batch failure is atomic: never retry members while holding a
            // partial set of read permits.
            Ok(Err(error)) => (UploadBatch::new(), Some(format!("{error:#}"))),
            Err(_) => (
                UploadBatch::new(),
                Some(format!(
                    "upload block read exceeded its peer deadline ({}s)",
                    PEER_UPLOAD_READ_TIMEOUT.as_secs()
                )),
            ),
        };
        let mut blocks = blocks.into_iter();
        let control_generation = read_context.upload_control.generation();
        let mut completions = UploadBatch::new();
        for spec in specs {
            let result = match error.as_ref() {
                Some(message) => Err(anyhow::anyhow!(message.clone())),
                None => blocks
                    .next()
                    .ok_or_else(|| anyhow::anyhow!("upload batch lost a completed block")),
            };
            match result {
                Ok(mut block) => {
                    let bytes = block.data.len() as u64;
                    let (result, rate_interrupted) = match read_context
                        .upload_rate
                        .network_budget
                        .acquire_upload(
                            read_context.upload_rate.peer,
                            bytes,
                            &read_context.upload_control,
                            control_generation,
                        )
                        .await
                    {
                        Ok(Some(grant)) => {
                            block.rate_grant = Some(grant);
                            (Ok(block), false)
                        }
                        Ok(None) => (Ok(block), true),
                        Err(error) => (Err(error), false),
                    };
                    completions.push(UploadReadCompletion::Completed {
                        request: spec.request,
                        result,
                        rate_interrupted,
                    });
                }
                Err(error) => {
                    completions.push(UploadReadCompletion::Completed {
                        request: spec.request,
                        result: Err(error),
                        rate_interrupted: false,
                    });
                }
            }
        }
        completions
    };
    match std::panic::AssertUnwindSafe(read).catch_unwind().await {
        Ok(completions) => completions,
        Err(_) => panicked_requests
            .into_iter()
            .map(|request| UploadReadCompletion::Panicked { request })
            .collect(),
    }
}

fn start_upload_reads<MakeUploadReadFuture, F>(
    upload_reads: &mut UploadReadTasks<F>,
    obligations: &SharedUploadPeer,
    upload: &UploadContext,
    read_context: &Arc<UploadReadContext>,
    make_upload_read_future: MakeUploadReadFuture,
) -> anyhow::Result<()>
where
    MakeUploadReadFuture: Fn(UploadBatch<UploadReadSpec>, Arc<UploadReadContext>) -> F + Copy,
    F: std::future::Future<Output = UploadBatch<UploadReadCompletion>> + Send + 'static,
{
    while upload_reads.pending_request_count() < MAX_PENDING_UPLOAD_READS {
        let Some(block) = obligations.next_request() else {
            break;
        };
        let mut batch: UploadBatch<UploadReadSpec> = smallvec::smallvec![upload_read_spec(
            upload,
            read_context,
            obligations,
            block,
            false,
        )?];
        let mut batch_bytes = batch[0]
            .span
            .as_ref()
            .map_or(batch[0].request.length as usize, |span| span.length);
        let available_slots =
            MAX_PENDING_UPLOAD_READS.saturating_sub(upload_reads.pending_request_count());
        while batch.len() < available_slots
            && batch.len() < MAX_UPLOAD_READ_BATCH_BLOCKS
            && batch_bytes < MAX_UPLOAD_READ_BATCH_BYTES
        {
            let Some(next_block) = obligations.peek_request() else {
                break;
            };
            if obligations.is_choked() && !obligations.is_allowed_fast(next_block.piece) {
                break;
            }
            let next_spec = upload_read_spec(upload, read_context, obligations, next_block, true)?;
            if !can_append_upload_read(&batch, &next_spec, batch_bytes) {
                break;
            }
            let Some(dequeued) = obligations.next_request() else {
                break;
            };
            if dequeued != next_block {
                if !obligations.requeue_front(dequeued) {
                    obligations.close();
                    anyhow::bail!("upload request changed during bounded batch admission");
                }
                break;
            }
            batch_bytes += next_spec.span.as_ref().expect("batchable span").length;
            batch.push(next_spec);
        }
        let request_count = batch.len();
        debug!(
            target: "torrentng::upload_batches",
            operation = "storage_read",
            blocks = request_count,
            bytes = batch_bytes,
            queued_requests = obligations.queued_len(),
            in_flight_requests = upload_reads.pending_request_count(),
            "scheduled peer upload storage read batch"
        );
        upload_reads.push_batch(
            make_upload_read_future(batch, Arc::clone(read_context)),
            request_count,
        );
    }
    Ok(())
}

fn abort_upload_reads<F>(upload_reads: &mut UploadReadTasks<F>) {
    *upload_reads = UploadReadTasks::default();
}

fn validate_bitfield_shape(bits: &[u8], piece_count: usize) -> anyhow::Result<()> {
    let expected_len = piece_count.div_ceil(8);
    if bits.len() != expected_len {
        anyhow::bail!(
            "bitfield length {} does not match expected {}",
            bits.len(),
            expected_len
        );
    }
    if !piece_count.is_multiple_of(8) && !bits.is_empty() {
        let used_bits = piece_count % 8;
        let spare_mask = (1u8 << (8 - used_bits)) - 1;
        if bits[bits.len() - 1] & spare_mask != 0 {
            anyhow::bail!("bitfield has non-zero spare bits");
        }
    }
    Ok(())
}

#[cfg(test)]
fn bitfield_to_pieces(bits: &[u8], piece_count: usize) -> anyhow::Result<Vec<bool>> {
    validate_bitfield_shape(bits, piece_count)?;

    let mut pieces = Vec::with_capacity(piece_count);
    for byte in bits {
        for bit in (0..8).rev() {
            if pieces.len() == piece_count {
                return Ok(pieces);
            }
            pieces.push((byte & (1 << bit)) != 0);
        }
    }
    Ok(pieces)
}

#[cfg(test)]
fn pieces_to_bitfield(pieces: &[bool]) -> Vec<u8> {
    let mut bits = vec![0u8; pieces.len().div_ceil(8)];
    for (idx, has_piece) in pieces.iter().copied().enumerate() {
        if has_piece {
            bits[idx / 8] |= 0x80 >> (idx % 8);
        }
    }
    bits
}

fn super_seed_visible_pieces<A: PieceAvailability + ?Sized>(
    have_pieces: &A,
    piece_count: usize,
    peer_addr: SocketAddr,
) -> PieceBitmap {
    let available_count = (0..piece_count)
        .filter(|piece| have_pieces.has_piece(*piece))
        .count();
    let mut visible = PieceBitmap::new(piece_count);
    if available_count == 0 {
        return visible;
    }

    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    peer_addr.hash(&mut hasher);
    let target = (hasher.finish() as usize) % available_count;
    if let Some(selected) = (0..piece_count)
        .filter(|piece| have_pieces.has_piece(*piece))
        .nth(target)
    {
        visible.set(selected, true);
    }
    visible
}

fn take_matching_outstanding(
    outstanding: &mut Vec<OutstandingRequest>,
    piece: u32,
    begin: u32,
    length: u32,
) -> Option<OutstandingRequest> {
    let pos = outstanding.iter().position(|out| {
        out.wire_req.piece == piece && out.wire_req.begin == begin && out.wire_req.length == length
    })?;
    Some(outstanding.swap_remove(pos))
}

fn remove_requested_block(requested: &mut Vec<BlockRequest>, piece: u32, begin: u32) {
    if let Some(pos) = requested
        .iter()
        .position(|req| req.piece == piece && req.begin == begin)
    {
        requested.swap_remove(pos);
    }
}

fn take_timed_out_requests(
    outstanding: &mut Vec<OutstandingRequest>,
    timeout: Duration,
) -> Vec<BlockRequest> {
    let now = Instant::now();
    let mut timed_out = Vec::new();
    let mut idx = 0;
    while idx < outstanding.len() {
        if now.duration_since(outstanding[idx].sent_at) >= timeout {
            timed_out.push(outstanding.swap_remove(idx).req);
        } else {
            idx += 1;
        }
    }
    timed_out
}

fn drain_outstanding(outstanding: &mut Vec<OutstandingRequest>) -> Vec<BlockRequest> {
    outstanding.drain(..).map(|out| out.req).collect()
}

fn take_choked_requests(
    outstanding: &mut Vec<OutstandingRequest>,
    fast_negotiated: bool,
) -> Vec<BlockRequest> {
    if fast_negotiated {
        outstanding.iter().map(|request| request.req).collect()
    } else {
        drain_outstanding(outstanding)
    }
}

fn webseed_retry_delay(failures: u8) -> Duration {
    let shift = failures.saturating_sub(1).min(9) as u32;
    let multiplier = 1_u32.checked_shl(shift).unwrap_or(u32::MAX);
    WEBSEED_RETRY_BASE
        .checked_mul(multiplier)
        .unwrap_or(WEBSEED_RETRY_MAX)
        .min(WEBSEED_RETRY_MAX)
}

fn webseed_error_for_log(error: &anyhow::Error) -> String {
    rt_tracker::sanitize_tracker_message(&error.to_string())
}

#[cfg(test)]
mod tests {
    use rt_fastresume::PreviousRun;
    use rt_path::SafeRelPath;
    use sha1::{Digest, Sha1};

    use super::*;

    #[tokio::test]
    async fn vectored_piece_write_handles_partial_socket_writes() {
        use tokio::io::AsyncReadExt;

        let (mut writer, mut reader) = tokio::io::duplex(5);
        let header = [0, 0, 0, 12, 7, 0, 0, 0, 3, 0, 0, 0, 4];
        let payload = b"payload";
        let mut received = vec![0; header.len() + payload.len()];
        let (write_result, read_result) = tokio::join!(
            write_piece_vectored(&mut writer, &header, payload),
            reader.read_exact(&mut received),
        );

        write_result.unwrap();
        read_result.unwrap();
        assert_eq!(&received[..header.len()], &header);
        assert_eq!(&received[header.len()..], payload);
    }

    #[tokio::test]
    async fn batched_piece_write_preserves_frames_across_partial_socket_writes() {
        use tokio::io::AsyncReadExt;

        let first = bytes::Bytes::from_static(b"abcd");
        let second = bytes::Bytes::from_static(b"WXYZ");
        let pieces = [(7, 0, &first), (7, 4, &second)];
        let (mut writer, mut reader) = tokio::io::duplex(7);
        let mut received = vec![0; 2 * (13 + first.len())];
        let (write_result, read_result) = tokio::join!(
            write_piece_frames_vectored(&mut writer, &pieces),
            reader.read_exact(&mut received),
        );

        assert_eq!(write_result.unwrap(), 2);
        read_result.unwrap();
        assert_eq!(&received[..13], &[0, 0, 0, 13, 7, 0, 0, 0, 7, 0, 0, 0, 0]);
        assert_eq!(&received[13..17], b"abcd");
        assert_eq!(&received[17..30], &[0, 0, 0, 13, 7, 0, 0, 0, 7, 0, 0, 0, 4]);
        assert_eq!(&received[30..], b"WXYZ");
    }

    #[tokio::test]
    async fn batched_piece_write_reports_only_complete_frames_on_error() {
        use std::pin::Pin;
        use std::task::{Context, Poll};
        use tokio::io::AsyncWrite;

        struct FailingWriter {
            written: Vec<u8>,
            fail_after: usize,
            max_chunk: usize,
        }

        impl AsyncWrite for FailingWriter {
            fn poll_write(
                mut self: Pin<&mut Self>,
                _cx: &mut Context<'_>,
                buffer: &[u8],
            ) -> Poll<std::io::Result<usize>> {
                if self.written.len() >= self.fail_after {
                    return Poll::Ready(Err(std::io::Error::new(
                        std::io::ErrorKind::BrokenPipe,
                        "test write failure",
                    )));
                }
                let available = self.fail_after - self.written.len();
                let count = buffer.len().min(available).min(self.max_chunk);
                self.written.extend_from_slice(&buffer[..count]);
                Poll::Ready(Ok(count))
            }

            fn poll_flush(
                self: Pin<&mut Self>,
                _cx: &mut Context<'_>,
            ) -> Poll<std::io::Result<()>> {
                Poll::Ready(Ok(()))
            }

            fn poll_shutdown(
                self: Pin<&mut Self>,
                _cx: &mut Context<'_>,
            ) -> Poll<std::io::Result<()>> {
                Poll::Ready(Ok(()))
            }
        }

        let first = bytes::Bytes::from_static(b"abcd");
        let second = bytes::Bytes::from_static(b"WXYZ");
        let pieces = [(7, 0, &first), (7, 4, &second)];
        let mut writer = FailingWriter {
            written: Vec::new(),
            fail_after: 13 + first.len() + 6,
            max_chunk: 5,
        };

        let (completed, error) = write_piece_frames_vectored(&mut writer, &pieces)
            .await
            .unwrap_err();
        assert_eq!(completed, 1);
        assert_eq!(error.kind(), std::io::ErrorKind::BrokenPipe);
        assert_eq!(writer.written.len(), 13 + first.len() + 6);
    }

    async fn test_upload_rate_admission(
        torrent_limit: Option<u64>,
        consumed_before_test: u64,
    ) -> UploadRateAdmission {
        let network_budget = GlobalNetworkBudget::unlimited();
        let torrent = network_budget.new_transfer_torrent_key();
        network_budget.register_download_torrent(torrent, None);
        network_budget.register_upload_torrent(torrent, torrent_limit);
        let rate_peer = TransferPeerId::new(
            torrent,
            ConnectionId {
                slot: 0,
                generation: 1,
            },
        );
        network_budget.register_transfer_peer(rate_peer);
        if consumed_before_test > 0 {
            let control = RateLimitCancellation::default();
            let grant = network_budget
                .acquire_upload(
                    rate_peer,
                    consumed_before_test,
                    &control,
                    control.generation(),
                )
                .await
                .expect("registered test upload peer")
                .expect("test upload admission should not wait for its initial burst");
            grant.settle(consumed_before_test);
        }
        UploadRateAdmission {
            network_budget,
            peer: rate_peer,
        }
    }

    fn test_download_grant(rate: &UploadRateAdmission, bytes: u64) -> RateAdmissionGrant {
        match rate
            .network_budget
            .try_acquire_download(rate.peer, bytes)
            .expect("registered test download peer")
        {
            RateAdmissionAttempt::Granted(grant) => grant,
            RateAdmissionAttempt::Wait(delay) => {
                panic!("unlimited test download peer unexpectedly waited {delay:?}")
            }
            RateAdmissionAttempt::WaitForChange => {
                panic!("unlimited test download peer unexpectedly waited for fairness progress")
            }
        }
    }

    #[test]
    fn dirty_piece_watermark_overflow_is_bounded_and_fail_closed() {
        let mut tracker = DirtyPieceTracker::default();
        for piece in 0..=MAX_RUNTIME_DIRTY_PIECES {
            tracker.insert(piece as u32);
        }

        assert!(tracker.is_overflowed());
        assert_eq!(tracker.len(), (MAX_RUNTIME_DIRTY_PIECES + 1) as u64);
        assert!(tracker.pieces.is_empty());

        tracker.clear();
        tracker.insert(7);
        assert!(!tracker.is_overflowed());
        assert_eq!(tracker.len(), 1);
        assert!(tracker.pieces.contains(&7));
    }

    #[test]
    fn recheck_invalid_piece_history_is_bounded_but_counts_all() {
        let mut invalid = RecheckInvalidPieces::new(u32::MAX);
        for piece in 0..=rt_db::MAX_JOB_INVALID_PIECES {
            invalid.record(piece as u32);
        }

        assert_eq!(invalid.values.len(), rt_db::MAX_JOB_INVALID_PIECES);
        assert_eq!(invalid.total, rt_db::MAX_JOB_INVALID_PIECES + 1);
        assert_eq!(invalid.values.first(), Some(&0));
        assert_eq!(
            invalid.values.last(),
            Some(&((rt_db::MAX_JOB_INVALID_PIECES - 1) as i64))
        );
    }

    fn persist_task_row(conn: &Connection, entry: &rt_session::TorrentEntry, meta: &TorrentMetaV1) {
        let row = crate::engine::row_from_entry(entry, &TorrentMeta::V1(meta.clone()));
        rt_db::upsert(conn, &row).unwrap();
    }

    #[test]
    fn hybrid_v2_projection_normalizes_rootless_paths_after_v1_padding() {
        let piece_length = (V2_BLOCK_SIZE * 2) as u64;
        let first_length = piece_length + 17;
        let padding_length = piece_length - 17;
        let second_offset = piece_length * 2;
        let first_v1_path = SafeRelPath::from_components(&["hybrid", "first.bin"], false).unwrap();
        let first_v2_path = SafeRelPath::from_name("first.bin", false).unwrap();
        let second_v1_path =
            SafeRelPath::from_components(&["hybrid", "second.bin"], false).unwrap();
        let second_v2_path = SafeRelPath::from_name("second.bin", false).unwrap();
        let v1 = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "hybrid".to_owned(),
            piece_length,
            pieces: vec![[0; 20]; 3],
            files: vec![
                TorrentFileV1 {
                    index: 0,
                    length: first_length,
                    path: first_v1_path,
                    offset: 0,
                    pad: false,
                },
                TorrentFileV1 {
                    index: 1,
                    length: padding_length,
                    path: SafeRelPath::from_name("padding", false).unwrap(),
                    offset: first_length,
                    pad: true,
                },
                TorrentFileV1 {
                    index: 2,
                    length: 11,
                    path: second_v1_path,
                    offset: second_offset,
                    pad: false,
                },
            ],
            private: false,
            raw: Vec::new(),
        };
        let v2 = TorrentMetaV2 {
            info_hash_v2: [2; 32],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "hybrid".to_owned(),
            piece_length,
            files: vec![
                rt_metainfo::TorrentFileV2 {
                    index: 0,
                    length: first_length,
                    path: first_v2_path,
                    offset: 0,
                    piece_offset: 0,
                    pieces_root: Some([9; 32]),
                    pad: false,
                },
                rt_metainfo::TorrentFileV2 {
                    index: 1,
                    length: 11,
                    path: second_v2_path,
                    offset: first_length,
                    piece_offset: second_offset,
                    pieces_root: Some([8; 32]),
                    pad: false,
                },
            ],
            piece_layers: HashMap::from([([9; 32], vec![[1; 32], [2; 32]])]),
            private: false,
            raw: Vec::new(),
        };

        let v1_piece_map = build_piece_map(v1.piece_length, &v1.files).unwrap();
        let projection = HybridV2Meta::from_validated_views(&v1, v1_piece_map, v2);

        assert!(projection.valid_layout);
        let geometry = projection.geometry.as_ref().unwrap();
        assert!(geometry.ranges_match(1, 1));
        assert!(geometry.ranges_match(2, 2));
        assert_eq!(
            projection.piece_expectation(1),
            Some(HybridV2PieceExpectation {
                file_index: 0,
                file_offset: piece_length,
                content_len: 17,
                expected_root: [2; 32],
                piece_leaf_count: Some(2),
            })
        );
        assert_eq!(
            projection.piece_expectation(2),
            Some(HybridV2PieceExpectation {
                file_index: 2,
                file_offset: 0,
                content_len: 11,
                expected_root: [8; 32],
                piece_leaf_count: None,
            })
        );

        let v1_handshake = Handshake {
            reserved: ExtensionFlags::default(),
            info_hash: v1.info_hash,
            peer_id: [3; 20],
        };
        let v2_wire_hash: [u8; 20] = projection.info_hash_v2[..20].try_into().unwrap();
        let v2_handshake = Handshake {
            reserved: ExtensionFlags::with_v2_support(),
            info_hash: v2_wire_hash,
            peer_id: [4; 20],
        };
        let v2_without_capability = Handshake {
            reserved: ExtensionFlags::default(),
            ..v2_handshake.clone()
        };
        assert_eq!(
            incoming_hybrid_plane(v1.info_hash, Some(&projection), &v1_handshake),
            Some(Plane::V1)
        );
        assert_eq!(
            incoming_hybrid_plane(v1.info_hash, Some(&projection), &v2_handshake),
            Some(Plane::V2)
        );
        assert_eq!(
            incoming_hybrid_plane(v1.info_hash, Some(&projection), &v2_without_capability),
            None
        );
        assert!(matches!(
            outgoing_hybrid_plane(v1.info_hash, Some(&projection), &v2_handshake),
            Ok(Plane::V2)
        ));
        assert!(
            outgoing_hybrid_plane(v1.info_hash, Some(&projection), &v2_without_capability).is_err()
        );
    }

    #[tokio::test]
    async fn hybrid_v2_upload_projects_canonical_padding_out_of_wire_payload() {
        let dir = tempfile::tempdir().unwrap();
        let piece_length = 16 * 1024u64;
        let payload_path = SafeRelPath::from_name("payload.bin", false).unwrap();
        let second_path = SafeRelPath::from_name("second.bin", false).unwrap();
        std::fs::write(payload_path.resolve(dir.path()), b"abc").unwrap();
        std::fs::write(second_path.resolve(dir.path()), b"xyz").unwrap();
        let v1 = TorrentMetaV1 {
            info_hash: [5; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "hybrid-upload".to_owned(),
            piece_length,
            pieces: vec![[0; 20]; 2],
            files: vec![
                TorrentFileV1 {
                    index: 0,
                    length: 3,
                    path: payload_path,
                    offset: 0,
                    pad: false,
                },
                TorrentFileV1 {
                    index: 1,
                    length: piece_length - 3,
                    path: SafeRelPath::from_components(&[".pad", "16381"], false).unwrap(),
                    offset: 3,
                    pad: true,
                },
                TorrentFileV1 {
                    index: 2,
                    length: 3,
                    path: second_path.clone(),
                    offset: piece_length,
                    pad: false,
                },
            ],
            private: false,
            raw: Vec::new(),
        };
        let v2 = TorrentMetaV2 {
            info_hash_v2: [6; 32],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "hybrid-upload".to_owned(),
            piece_length,
            files: vec![
                rt_metainfo::TorrentFileV2 {
                    index: 0,
                    length: 3,
                    path: SafeRelPath::from_name("payload.bin", false).unwrap(),
                    offset: 0,
                    piece_offset: 0,
                    pieces_root: Some([7; 32]),
                    pad: false,
                },
                rt_metainfo::TorrentFileV2 {
                    index: 1,
                    length: 3,
                    path: second_path,
                    offset: 3,
                    piece_offset: piece_length,
                    pieces_root: Some([8; 32]),
                    pad: false,
                },
            ],
            piece_layers: HashMap::new(),
            private: false,
            raw: Vec::new(),
        };
        let piece_map = build_piece_map(v1.piece_length, &v1.files).unwrap();
        let hybrid = Arc::new(HybridV2Meta::from_validated_views(
            &v1,
            piece_map.clone(),
            v2,
        ));
        assert!(hybrid.valid_layout);
        let geometry = hybrid.geometry.as_ref().unwrap();
        let canonical = BlockExtent::new(0, 0, 16 * 1024);
        let wire = geometry.canonical_v2_block_for_v1(canonical).unwrap();
        assert_eq!(wire, BlockExtent::new(0, 0, 3));

        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let upload_rate = test_upload_rate_admission(None, 0).await;
        let upload_registration = upload_rate
            .network_budget
            .upload_service()
            .register(upload_rate.peer, false, MAX_UPLOAD_WORK)
            .unwrap();
        let upload = UploadReadContext {
            save_root: dir.path().to_path_buf(),
            piece_map,
            hybrid_v2: Some(hybrid),
            plane: Plane::V2,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                dir.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: resources.clone(),
            upload_control: RateLimitCancellation::default(),
            upload_rate,
            read_admission: upload_registration.read_admission(),
        };
        let block = read_upload_block(&upload, UploadRequest::new(canonical, wire), false)
            .await
            .unwrap();

        assert_eq!(block.data.as_ref(), b"abc");
        assert_eq!(block.data.len(), wire.length as usize);
        assert_eq!(block._lease.bytes(), u64::from(canonical.length));
        drop(block);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[tokio::test]
    async fn hybrid_v2_peer_loop_translates_download_and_upload_wire_ranges() {
        let dir = tempfile::tempdir().unwrap();
        let piece_length = 16 * 1024u64;
        let payload_path = SafeRelPath::from_name("payload.bin", false).unwrap();
        std::fs::write(payload_path.resolve(dir.path()), b"abc").unwrap();
        let v1 = TorrentMetaV1 {
            info_hash: [9; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "hybrid-peer".to_owned(),
            piece_length,
            pieces: vec![[0; 20]],
            files: vec![
                TorrentFileV1 {
                    index: 0,
                    length: 3,
                    path: payload_path.clone(),
                    offset: 0,
                    pad: false,
                },
                TorrentFileV1 {
                    index: 1,
                    length: piece_length - 3,
                    path: SafeRelPath::from_components(&[".pad", "16381"], false).unwrap(),
                    offset: 3,
                    pad: true,
                },
            ],
            private: false,
            raw: Vec::new(),
        };
        let v2 = TorrentMetaV2 {
            info_hash_v2: [10; 32],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "hybrid-peer".to_owned(),
            piece_length,
            files: vec![rt_metainfo::TorrentFileV2 {
                index: 0,
                length: 3,
                path: payload_path,
                offset: 0,
                piece_offset: 0,
                pieces_root: Some([11; 32]),
                pad: false,
            }],
            piece_layers: HashMap::new(),
            private: false,
            raw: Vec::new(),
        };
        let piece_map = build_piece_map(v1.piece_length, &v1.files).unwrap();
        let hybrid = Arc::new(HybridV2Meta::from_validated_views(
            &v1,
            piece_map.clone(),
            v2,
        ));
        assert!(hybrid.valid_layout);

        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let upload_rate = test_upload_rate_admission(None, 0).await;
        let upload = UploadContext {
            save_root: dir.path().to_path_buf(),
            piece_map,
            hybrid_v2: Some(hybrid),
            plane: Plane::V2,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                dir.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: resources.clone(),
            have_pieces: PieceBitmap::from_bools(&[true]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: false,
            fast_negotiated: false,
            upload_control: RateLimitCancellation::default(),
            shutdown_control: RateLimitCancellation::default(),
            upload_rate: upload_rate.clone(),
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };

        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote_stream = TcpStream::connect(peer_addr).await.unwrap();
        let (server_stream, _) = listener.accept().await.unwrap();
        let mut remote = Framed::new(remote_stream, PeerCodec::default());
        let (peer_event_tx, mut peer_event_rx) = mpsc::channel(16);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(8);
        let peer_loop = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server_stream, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            false,
        ));

        remote.send(Message::Unchoke).await.unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), peer_event_rx.recv())
                .await
                .unwrap(),
            Some(PeerEvent::Unchoked { .. })
        ));
        let canonical = BlockRequest {
            piece: 0,
            begin: 0,
            length: 16 * 1024,
        };
        let memory_lease = reserve_peer_event_bytes(&resources, canonical.length as usize).unwrap();
        peer_cmd_tx
            .send(PeerCommand::Request {
                request: canonical,
                download_generation: 0,
                memory_lease,
                rate_grant: None,
                source_permit: None,
            })
            .await
            .unwrap();
        loop {
            let message = timeout(Duration::from_secs(1), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap();
            if let Message::Request {
                piece,
                begin,
                length,
            } = message
            {
                assert_eq!((piece, begin, length), (0, 0, 3));
                break;
            }
        }
        remote
            .send(Message::Piece {
                piece: 0,
                begin: 0,
                data: bytes::Bytes::from_static(b"abc"),
            })
            .await
            .unwrap();
        let received = loop {
            match timeout(Duration::from_secs(1), peer_event_rx.recv())
                .await
                .unwrap()
                .unwrap()
            {
                PeerEvent::Piece { block, .. } => break block,
                _ => continue,
            }
        };
        assert_eq!(received.block.piece, 0);
        assert_eq!(received.block.offset, 0);
        assert_eq!(received.block.data.len(), 16 * 1024);
        assert_eq!(&received.block.data[..3], b"abc");
        assert!(received.block.data[3..].iter().all(|byte| *byte == 0));
        assert_eq!(received.network_bytes, Some(3));
        drop(received);

        peer_cmd_tx.send(PeerCommand::Unchoke).await.unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            Message::Unchoke
        ));
        remote
            .send(Message::Request {
                piece: 0,
                begin: 0,
                length: 3,
            })
            .await
            .unwrap();
        loop {
            let message = timeout(Duration::from_secs(2), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap();
            if let Message::Piece { piece, begin, data } = message {
                assert_eq!((piece, begin), (0, 0));
                assert_eq!(data.as_ref(), b"abc");
                break;
            }
        }

        drop(remote);
        let exit = timeout(Duration::from_secs(2), peer_loop)
            .await
            .expect("hybrid peer loop did not stop after remote close")
            .unwrap();
        assert!(exit.outstanding.is_empty());
    }

    #[tokio::test]
    async fn hybrid_completion_and_recheck_require_both_integrity_views() {
        let temp = tempfile::tempdir().unwrap();
        let content = b"short hybrid payload";
        let piece_length = (V2_BLOCK_SIZE * 2) as u64;
        let mut piece = content.to_vec();
        piece.resize(piece_length as usize, 0);
        let v1_hash: [u8; 20] = Sha1::digest(&piece).into();
        let path = SafeRelPath::from_name("hybrid.bin", false).unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [3; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "hybrid.bin".to_owned(),
            piece_length,
            pieces: vec![v1_hash],
            files: vec![
                TorrentFileV1 {
                    index: 0,
                    length: content.len() as u64,
                    path: path.clone(),
                    offset: 0,
                    pad: false,
                },
                TorrentFileV1 {
                    index: 1,
                    length: piece_length - content.len() as u64,
                    path: SafeRelPath::from_name("padding", false).unwrap(),
                    offset: content.len() as u64,
                    pad: true,
                },
            ],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash,
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = piece_length;
        entry.amount_left = piece_length;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta.clone(),
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        let v2_file_root = rt_hash::BlockHash::of(content).0;
        task.attach_hybrid_v2_metadata(TorrentMetaV2 {
            info_hash_v2: [4; 32],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "hybrid.bin".to_owned(),
            piece_length,
            files: vec![rt_metainfo::TorrentFileV2 {
                index: 0,
                length: content.len() as u64,
                path,
                offset: 0,
                piece_offset: 0,
                pieces_root: Some(v2_file_root),
                pad: false,
            }],
            piece_layers: HashMap::new(),
            private: false,
            raw: Vec::new(),
        });
        assert!(task.transfer_ledger.is_hybrid());
        std::fs::write(temp.path().join("hybrid.bin"), content).unwrap();
        let mut assembly = PieceAssembly::new(piece.len());
        assembly
            .insert(0, &piece[..MAX_BLOCK_SIZE as usize])
            .unwrap();
        assembly
            .insert(MAX_BLOCK_SIZE, &piece[MAX_BLOCK_SIZE as usize..])
            .unwrap();
        task.piece_assemblies.insert(0, assembly);

        assert_eq!(task.verify_completed_piece(0).await, VerifyResult::Valid);
        Arc::make_mut(task.hybrid_v2.as_mut().unwrap()).files[0].pieces_root = Some([0; 32]);
        assert_eq!(
            task.verify_completed_piece(0).await,
            VerifyResult::Invalid,
            "matching v1 SHA-1 cannot certify a mismatched v2 file root"
        );
        assert!(matches!(
            task.run_recheck(None).await,
            RecheckOutcome::Complete
        ));
        assert!(
            !task.picker.is_complete(),
            "disk recheck must reject v1-valid data when its hybrid v2 root mismatches"
        );
        assert_eq!(
            registry
                .read()
                .await
                .get(&hex::encode(meta.info_hash))
                .unwrap()
                .state,
            TorrentState::Downloading
        );
    }

    #[test]
    fn choke_state_does_not_commit_when_peer_mailbox_is_full() {
        let (tx, mut rx) = mpsc::channel(1);
        let control = RateLimitCancellation::default();
        tx.try_send(PeerCommand::Shutdown)
            .expect("fill the test peer mailbox");

        let (state, failed) =
            TorrentTask::try_apply_choke_decision(&tx, &control, false, ChokeDecision::Choke);
        assert!(!state, "failed delivery must retain the previous state");
        assert!(failed);

        let _ = rx.try_recv();
        let generation = control.generation();
        let (state, failed) =
            TorrentTask::try_apply_choke_decision(&tx, &control, false, ChokeDecision::Choke);
        assert!(state);
        assert!(!failed);
        assert_ne!(control.generation(), generation);
    }

    #[tokio::test]
    async fn shutdown_rejects_queued_torrent_command_replies() {
        let (cmd_tx, mut cmd_rx) = mpsc::channel(2);
        let (reply, response) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::Pause { reply: Some(reply) })
            .await
            .unwrap();
        drop(cmd_tx);
        let mut pending_command = None;

        reject_pending_torrent_commands(&mut cmd_rx, &mut pending_command);

        assert_eq!(
            response.await.unwrap(),
            Err("torrent task is shutting down".to_owned())
        );
    }

    #[tokio::test]
    async fn closed_command_channel_rearms_interrupted_stopped_announce() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [26; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "closed-command.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("closed-command.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let db = Arc::new(Mutex::new(conn));
        let (_task_cmd_tx, task_cmd_rx) = mpsc::channel(1);
        let (cmd_tx, mut cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            task_cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        // Hold the registry write lock so announce_stopped is suspended after
        // consuming its flag. Closing the command channel then exercises the
        // interruption branch rather than the normal announce-complete path.
        task.stopped_announced = false;
        let _registry_guard = registry.write().await;
        drop(cmd_tx);
        let mut pending_command = None;
        await_stopped_announce_or_queue_command(&mut task, &mut cmd_rx, &mut pending_command).await;

        assert!(!task.stopped_announced);
        assert!(pending_command.is_none());
    }

    #[test]
    fn merged_peer_request_views_are_deduplicated() {
        let requests = vec![BlockRequest {
            piece: 2,
            begin: 0,
            length: MAX_BLOCK_SIZE,
        }];
        let merged = TorrentTask::merge_unique_block_requests(
            requests,
            vec![
                BlockRequest {
                    piece: 2,
                    begin: 0,
                    length: MAX_BLOCK_SIZE,
                },
                BlockRequest {
                    piece: 3,
                    begin: 0,
                    length: MAX_BLOCK_SIZE,
                },
            ],
        );

        assert_eq!(merged.len(), 2);
        assert_eq!(merged[0].piece, 2);
        assert_eq!(merged[1].piece, 3);
    }

    #[test]
    fn fast_choke_cancels_queued_requests_but_keeps_wire_requests() {
        let queued = BlockRequest {
            piece: 2,
            begin: 0,
            length: MAX_BLOCK_SIZE,
        };
        let on_wire = BlockRequest {
            piece: 3,
            begin: MAX_BLOCK_SIZE,
            length: MAX_BLOCK_SIZE,
        };
        let (retained, cancelled) =
            TorrentTask::reconcile_fast_choke_requests(vec![queued, on_wire], vec![on_wire]);

        assert_eq!(retained, vec![on_wire]);
        assert_eq!(cancelled, vec![queued]);
    }

    #[test]
    fn have_delivery_keeps_a_bounded_retry_until_mailbox_accepts_it() {
        let (tx, mut rx) = mpsc::channel(1);
        tx.try_send(PeerCommand::Shutdown)
            .expect("fill the test peer mailbox");
        let mut pending = PieceBitmap::new(8);

        assert!(!TorrentTask::try_send_have(&tx, &mut pending, 3));
        assert_eq!(pending.first_set_u32(), Some(3));

        let _ = rx.try_recv();
        assert!(TorrentTask::try_send_have(&tx, &mut pending, 3));
        assert_eq!(pending.first_set_u32(), None);
        assert!(matches!(rx.try_recv(), Ok(PeerCommand::Have(3))));
    }

    #[test]
    fn webseed_retry_delay_is_exponential_and_bounded() {
        assert_eq!(webseed_retry_delay(1), Duration::from_secs(1));
        assert_eq!(webseed_retry_delay(2), Duration::from_secs(2));
        assert_eq!(webseed_retry_delay(9), Duration::from_secs(256));
        assert_eq!(webseed_retry_delay(10), WEBSEED_RETRY_MAX);
        assert_eq!(webseed_retry_delay(u8::MAX), WEBSEED_RETRY_MAX);
    }

    #[test]
    fn utp_frame_decoder_preserves_fragmented_and_coalesced_messages() {
        let wire = [
            Message::Have(7).encode(),
            Message::KeepAlive.encode(),
            Message::Unchoke.encode(),
        ]
        .concat();
        let expected = vec![Message::Have(7), Message::KeepAlive, Message::Unchoke];
        let mut decoder = UtpFrameDecoder::default();
        let mut frames = Vec::new();

        for chunk in wire.chunks(2) {
            decoder.push(chunk).unwrap();
            while let Some(message) = decoder.take_frame().unwrap() {
                frames.push(message);
            }
        }

        assert_eq!(frames, expected);
        assert!(decoder.is_empty());
    }

    #[test]
    fn utp_frame_decoder_rejects_oversized_length_before_buffer_growth() {
        let mut decoder = UtpFrameDecoder::default();
        let oversized = (rt_peer_wire::message::MAX_MESSAGE_LEN + 1).to_be_bytes();

        assert!(decoder.push(&oversized).is_err());
        assert_eq!(decoder.buffer.len(), 4);
    }

    #[test]
    fn utp_frame_decoder_admits_partial_frame_before_buffer_growth() {
        let mut caps = [0; rt_metrics::MEMORY_CLASS_COUNT];
        caps[MemoryClass::PeerBuffer as usize] = 64;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: 64,
            class_caps_bytes: caps,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });
        let mut decoder = UtpFrameDecoder::new(governor.clone());

        // The declared frame needs 2 * (4-byte prefix + 32-byte payload) in
        // the decoder's peak allowance. Reject it after retaining only the
        // prefix; the old decoder would accept the prefix and grow to the
        // full frame without consulting the peer-buffer governor.
        assert!(decoder.push(&32u32.to_be_bytes()).is_err());
        assert_eq!(decoder.buffer.len(), 4);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            8
        );
        drop(decoder);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[test]
    fn utp_wire_buffer_reuses_and_releases_its_memory_lease() {
        let mut caps = [0; rt_metrics::MEMORY_CLASS_COUNT];
        caps[MemoryClass::PeerBuffer as usize] = 128;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: 128,
            class_caps_bytes: caps,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });
        let decoder = UtpFrameDecoder::new(governor.clone());
        let mut buffer = UtpWireBuffer::default();

        let first = buffer.encode(&decoder, &Message::Have(7)).unwrap();
        assert_eq!(first, Message::Have(7).encode());
        let held = governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes;
        assert_eq!(held, buffer.lease.as_ref().unwrap().bytes());

        let second = buffer.encode(&decoder, &Message::KeepAlive).unwrap();
        assert_eq!(second, [0, 0, 0, 0]);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            held
        );

        drop(buffer);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[test]
    fn utp_wire_buffer_keeps_old_allocation_when_growth_is_denied() {
        let mut caps = [0; rt_metrics::MEMORY_CLASS_COUNT];
        caps[MemoryClass::PeerBuffer as usize] = 4;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: 4,
            class_caps_bytes: caps,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });
        let decoder = UtpFrameDecoder::new(governor.clone());
        let mut buffer = UtpWireBuffer::default();

        buffer.encode(&decoder, &Message::KeepAlive).unwrap();
        assert!(buffer
            .encode(
                &decoder,
                &Message::Piece {
                    piece: 0,
                    begin: 0,
                    data: vec![0; 32].into(),
                }
            )
            .is_err());
        assert_eq!(buffer.buffer.len(), 4);
        assert_eq!(buffer.buffer.capacity(), 4);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            4
        );

        drop(buffer);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[tokio::test]
    async fn transfer_stats_are_batched_until_progress_flush_on_db_worker() {
        let temp = tempfile::tempdir().unwrap();
        let db_path = temp.path().join("progress.sqlite");
        let db_worker = crate::db_worker::DbWorker::new(db_path.clone());
        db_worker
            .run("migrate_progress_probe", |conn| {
                rt_db::migrate(conn).map_err(|error| error.to_string())
            })
            .await
            .unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "sample.bin".into(),
            piece_length: 4,
            pieces: vec![[2; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("sample.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        let durable_row = crate::engine::row_from_entry(&entry, &TorrentMeta::V1(meta.clone()));
        db_worker
            .run("insert_progress_probe", move |conn| {
                rt_db::upsert(conn, &durable_row).map_err(|error| error.to_string())
            })
            .await
            .unwrap();
        registry.write().await.add(entry).unwrap();
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::clone(&registry),
            DbExecutor::worker(db_worker.clone()),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        task.update_transfer(4, false).await;
        task.update_transfer(2, true).await;
        assert!(task.transfer_stats_dirty);
        let info_hash_before = info_hash.clone();
        let before = db_worker
            .run("read_progress_before_flush", move |conn| {
                rt_db::get(conn, &info_hash_before).map_err(|error| error.to_string())
            })
            .await
            .unwrap();
        assert_eq!(before.downloaded, 0);

        task.persist_progress().await;

        assert!(!task.transfer_stats_dirty);
        let info_hash_after = info_hash.clone();
        let row = db_worker
            .run("read_progress_after_flush", move |conn| {
                rt_db::get(conn, &info_hash_after).map_err(|error| error.to_string())
            })
            .await
            .unwrap();
        assert_eq!(row.uploaded, 2);
        assert_eq!(row.downloaded, 4);
        assert!(
            db_worker
                .metrics_handle()
                .snapshot()
                .batch_transactions_total
                >= 1
        );
        drop(task);
        db_worker.shutdown(Duration::from_secs(1)).await;

        let reopened = Connection::open(db_path).unwrap();
        let row = rt_db::get(&reopened, &info_hash).unwrap();
        assert_eq!(row.uploaded, 2);
        assert_eq!(row.downloaded, 4);
    }

    #[tokio::test]
    async fn first_throttled_progress_starts_interval_without_blocking_on_checkpoint() {
        let fixture = crash_fixture(vec![0x31; 8], 4, 73).await;
        let mut task = crash_task(&fixture, quiet_runtime(), StorageIoConfig::default()).await;
        task.transfer_stats_dirty = true;

        task.persist_progress_throttled(false).await;

        assert!(task.last_progress_persist.is_some());
        assert!(
            task.transfer_stats_dirty,
            "the first partial completion should only start the timer; the actor must not wait for a DB commit or storage barrier"
        );
    }

    #[tokio::test]
    async fn applying_tracker_urls_repairs_stale_detail_projection() {
        let temp = tempfile::tempdir().unwrap();
        let mut conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let old_tracker = "http://old-tracker.example/announce".to_owned();
        let new_tracker = "http://new-tracker.example/announce".to_owned();
        let meta = TorrentMetaV1 {
            info_hash: [21; 20],
            announce: Some(old_tracker.clone()),
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "tracker-race.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("tracker-race.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Paused).unwrap();
        let mut row = crate::engine::row_from_entry(&entry, &TorrentMeta::V1(meta.clone()));
        // Model the engine transaction having updated the compact override
        // while an older tracker-result snapshot still owns the detail rows.
        row.trackers = vec![new_tracker.clone()];
        rt_db::upsert(&conn, &row).unwrap();
        rt_db::replace_torrent_trackers(
            &mut conn,
            &info_hash,
            &[rt_db::TorrentTrackerRow {
                info_hash: info_hash.clone(),
                tracker_index: 0,
                tier: 0,
                url: old_tracker,
                tracker_id: Some(vec![0xabu8]),
                status: "error".to_owned(),
                last_announce_at: Some(1),
                next_announce_at: Some(2),
                last_success_at: None,
                failure_reason: Some("stale tracker result".to_owned()),
                warning_message: None,
                seeders: None,
                leechers: None,
                completed: None,
                uploaded: 0,
                downloaded: 0,
                left_bytes: 4,
            }],
        )
        .unwrap();
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Paused,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        task.apply_tracker_urls(vec![new_tracker.clone()])
            .await
            .unwrap();

        let trackers = rt_db::list_torrent_trackers(&db.lock().unwrap(), &info_hash).unwrap();
        assert_eq!(trackers.len(), 1);
        assert_eq!(trackers[0].url, new_tracker);
        assert_eq!(trackers[0].status, "never_announced");
        assert_eq!(trackers[0].tracker_id, None);
    }

    #[test]
    fn poisoned_prepared_file_registry_is_cleared_and_rebuilt() {
        let prepared = Arc::new(Mutex::new(HashSet::from([3_u32])));
        let poisoner = Arc::clone(&prepared);
        assert!(std::thread::spawn(move || {
            let _guard = poisoner.lock().unwrap();
            panic!("poison the derived prepared-file registry");
        })
        .join()
        .is_err());
        assert!(prepared.is_poisoned());

        assert!(lock_prepared_files(&prepared).is_empty());
        assert!(!prepared.is_poisoned());
    }

    #[tokio::test]
    async fn persisted_file_paths_are_applied_to_runtime_and_piece_map() {
        let temp = tempfile::tempdir().unwrap();
        let mut conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [19; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "renamed.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]; 2],
            files: vec![
                rt_metainfo::TorrentFileV1 {
                    index: 0,
                    length: 4,
                    path: rt_path::SafeRelPath::from_name("old-a.bin", false).unwrap(),
                    offset: 0,
                    pad: false,
                },
                rt_metainfo::TorrentFileV1 {
                    index: 1,
                    length: 4,
                    path: rt_path::SafeRelPath::from_name("old-b.bin", false).unwrap(),
                    offset: 4,
                    pad: false,
                },
            ],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 8;
        entry.amount_left = 8;
        entry.transition(TorrentState::Paused).unwrap();
        persist_task_row(&conn, &entry, &meta);
        rt_db::replace_torrent_files(
            &mut conn,
            &info_hash,
            &[
                rt_db::TorrentFileRow {
                    info_hash: info_hash.clone(),
                    file_index: 0,
                    path: "persisted/a.bin".into(),
                    length: 4,
                    offset: 0,
                    priority: 1,
                    wanted: true,
                    completed_bytes: 0,
                },
                rt_db::TorrentFileRow {
                    info_hash: info_hash.clone(),
                    file_index: 1,
                    path: "persisted/b.bin".into(),
                    length: 4,
                    offset: 4,
                    priority: 1,
                    wanted: true,
                    completed_bytes: 0,
                },
            ],
        )
        .unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Paused,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            resources.clone(),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        assert!(task._file_policy_memory_lease.is_some());
        assert!(resources.snapshot().classes[MemoryClass::Metadata as usize].used_bytes > 0);
        assert_eq!(task.meta.files[0].path.as_display(), "persisted/a.bin");
        assert_eq!(task.meta.files[1].path.as_display(), "persisted/b.bin");
        assert_eq!(
            task.piece_map
                .piece_to_file_regions(0)
                .unwrap()
                .first()
                .unwrap()
                .path
                .as_display(),
            "persisted/a.bin"
        );

        {
            let conn = db.lock().unwrap();
            conn.execute(
                "UPDATE torrent_files SET path = 'runtime/a.bin' WHERE info_hash = ?1 AND file_index = 0",
                [&info_hash],
            )
            .unwrap();
        }
        task.picker.mark_have(0);
        task.picker.mark_have(1);
        assert!(task.picker.is_complete());
        task.prepared_files.lock().unwrap().insert(0);
        task.apply_file_policy_from_db().await.unwrap();
        assert_eq!(task.meta.files[0].path.as_display(), "runtime/a.bin");
        assert!(!task.picker.is_complete());
        assert!(!task.picker.have_piece(0));
        assert!(task.picker.have_piece(1));
        assert_eq!(
            task.piece_map
                .piece_to_file_regions(0)
                .unwrap()
                .first()
                .unwrap()
                .path
                .as_display(),
            "runtime/a.bin"
        );
        assert!(task.prepared_files.lock().unwrap().is_empty());

        {
            let conn = db.lock().unwrap();
            conn.execute(
                "DELETE FROM torrent_files WHERE info_hash = ?1",
                [&info_hash],
            )
            .unwrap();
        }
        task.apply_file_policy_from_db().await.unwrap();
        assert_eq!(task.meta.files[0].path.as_display(), "old-a.bin");
        assert!(task._file_policy_memory_lease.is_none());
        assert_eq!(
            resources.snapshot().classes[MemoryClass::Metadata as usize].used_bytes,
            0
        );
    }

    #[tokio::test]
    async fn failed_block_write_releases_picker_request() {
        let temp = tempfile::tempdir().unwrap();
        let save_root = temp.path().join("not-a-directory");
        std::fs::write(&save_root, b"file").unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let piece_length = 2 * 1024 * 1024;
        let meta = TorrentMetaV1 {
            info_hash: [20; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "write-failure.bin".into(),
            piece_length,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: piece_length,
                path: rt_path::SafeRelPath::from_name("payload.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            save_root.to_string_lossy().into_owned(),
        );
        entry.total_length = piece_length;
        entry.amount_left = piece_length;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            save_root,
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let peer_has = PieceBitmap::from_bools(&[true]);
        task.picker.availability.add_have(0);
        let request = task.picker.pick(&peer_has).unwrap();
        task.handle_block(LeasedBlockEvent::uncharged_for_test(
            request.piece,
            request.begin,
            bytes::Bytes::from(vec![0; request.length as usize]),
        ))
        .await;
        assert_eq!(task.transfer_jobs.len(), 1);
        assert!(task
            .pending_transfer_blocks
            .contains_key(&(request.piece, request.begin)));
        assert!(!task
            .picker
            .is_block_received(request.piece as usize, request.begin));
        task.drain_transfer_jobs().await;

        let retry = task
            .picker
            .pick(&peer_has)
            .expect("a failed disk write must make the block requestable again");
        assert_eq!(retry, request);
        assert_eq!(
            rt_db::get(&db.lock().unwrap(), &info_hash)
                .unwrap()
                .downloaded,
            0
        );
    }

    #[tokio::test]
    async fn stale_piece_attempt_completions_cannot_mutate_a_retry() {
        let fixture = crash_fixture(vec![0x31; 8], 4, 73).await;
        let mut task = crash_task(&fixture, quiet_runtime(), StorageIoConfig::default()).await;
        let peer_has = PieceBitmap::from_bools(&[true, false]);
        task.picker.availability.add_have(0);
        task.picker
            .pick(&peer_has)
            .expect("first attempt should be requestable");
        let old_generation = task.ensure_pending_transfer_piece(0).generation;

        task.fail_piece_transfer(0);
        task.picker
            .pick(&peer_has)
            .expect("failed attempt should be requestable again");
        let new_generation = task.ensure_pending_transfer_piece(0).generation;
        assert_ne!(old_generation, new_generation);
        task.pending_transfer_pieces
            .get_mut(&0)
            .unwrap()
            .writes_in_flight = 1;
        task.pending_transfer_blocks.insert((0, 0), new_generation);

        task.handle_transfer_completion(TransferCompletion::BlockWritten {
            piece: 0,
            generation: old_generation,
            offset: 0,
            length: 4,
            downloaded_bytes: 4,
            result: Err("late old write failure".into()),
        })
        .await;
        task.handle_transfer_completion(TransferCompletion::PieceVerified {
            piece: 0,
            generation: old_generation,
            result: VerifyResult::Invalid,
            assembled: None,
        })
        .await;

        let current = task.pending_transfer_pieces.get(&0).unwrap();
        assert_eq!(current.generation, new_generation);
        assert_eq!(current.writes_in_flight, 1);
        assert!(!current.failed);
        assert_eq!(
            task.pending_transfer_blocks.get(&(0, 0)),
            Some(&new_generation)
        );
        assert!(task.picker.is_piece_in_progress(0));
    }

    #[tokio::test]
    async fn storage_move_resume_reports_durable_state_failure() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [17; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "storage-resume.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("storage-resume.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Paused).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        conn.execute_batch(
            "CREATE TRIGGER fail_storage_resume_checking
             BEFORE UPDATE OF state ON torrents
             WHEN NEW.state = 'checking'
             BEGIN SELECT RAISE(ABORT, 'injected storage resume failure'); END;",
        )
        .unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(1);
        let task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Paused,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        let handle = tokio::spawn(task.run());
        let (reply, response) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::ResumeAfterStorageMove {
                new_save_root: None,
                resume_paused: false,
                reply,
            })
            .await
            .unwrap();
        let result = timeout(Duration::from_secs(2), response)
            .await
            .expect("storage resume did not acknowledge")
            .unwrap();
        assert!(result
            .expect_err("storage resume unexpectedly succeeded")
            .contains("injected storage resume failure"));
        assert!(taskless_state_is_paused(&registry, &info_hash).await);

        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(1), handle)
            .await
            .expect("storage resume test task did not shut down")
            .unwrap();
    }

    async fn taskless_state_is_paused(
        registry: &Arc<RwLock<SessionRegistry>>,
        info_hash: &str,
    ) -> bool {
        registry
            .read()
            .await
            .get(info_hash)
            .is_some_and(|entry| entry.state == TorrentState::Paused)
    }

    #[test]
    fn upload_accounting_batch_notifies_after_four_maximum_blocks() {
        let mut batch = UploadAccountingBatch::default();
        for _ in 0..3 {
            assert!(!batch.add(16 * 1024, UPLOAD_ACCOUNTING_BATCH_BYTES));
        }
        assert!(batch.add(16 * 1024, UPLOAD_ACCOUNTING_BATCH_BYTES));
        batch.clear();
        assert!(batch.is_empty());
        assert!(!batch.add(16 * 1024, UPLOAD_ACCOUNTING_BATCH_BYTES));
        let mut seed_limited_batch = UploadAccountingBatch::default();
        assert!(seed_limited_batch.add(1, 1));
    }

    #[test]
    fn upload_accounting_atomic_add_is_saturating_and_concurrent() {
        let pending = Arc::new(AtomicU64::new(0));
        let workers = (0..8)
            .map(|_| {
                let pending = Arc::clone(&pending);
                std::thread::spawn(move || {
                    for _ in 0..1_000 {
                        atomic_saturating_add(&pending, 1);
                    }
                })
            })
            .collect::<Vec<_>>();
        for worker in workers {
            worker.join().unwrap();
        }
        assert_eq!(pending.load(Ordering::Relaxed), 8_000);

        pending.store(u64::MAX - 1, Ordering::Relaxed);
        atomic_saturating_add(&pending, 2);
        atomic_saturating_add(&pending, 1);
        assert_eq!(pending.load(Ordering::Relaxed), u64::MAX);
    }

    #[tokio::test]
    async fn seed_ratio_limit_pauses_a_completed_torrent() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [3; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "sample.bin".into(),
            piece_length: 4,
            pieces: vec![[4; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("sample.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        task.picker.mark_have(0);
        task.seed_ratio_limit = Some(0.5);
        task.update_transfer(4, false).await;
        task.set_state_checked(TorrentState::Seeding).await.unwrap();
        let events = rt_db::list_session_events(&db.lock().unwrap(), Some(&info_hash), 10).unwrap();
        assert!(events.iter().any(|event| {
            event.kind == "torrent_state_changed"
                && event.payload.contains("downloading")
                && event.payload.contains("seeding")
        }));
        // A completed torrent enforces its ratio immediately from the totals
        // returned by the upload accounting lock, without a second registry
        // read on the upload hot path.
        let peer_addr = "127.0.0.1:6881".parse().unwrap();
        let peer_permits = Arc::new(tokio::sync::Semaphore::new(1));
        let (peer_id, _peer_commands) = task
            .register_peer(peer_addr, peer_permits.acquire_owned().await.unwrap())
            .expect("peer registration should fit the memory budget");
        assert_eq!(
            task.active_peers[&peer_addr]
                .upload_accounting
                .batch_bytes
                .load(Ordering::Relaxed),
            1
        );
        task.active_peers[&peer_addr]
            .upload_accounting
            .pending_uploaded_bytes
            .store(1, Ordering::Relaxed);
        task.handle_peer_event(PeerEvent::Uploaded {
            peer: peer_addr,
            id: peer_id,
        })
        .await;
        assert_eq!(task.active_peers[&peer_addr].uploaded, 1);
        assert_eq!(
            registry
                .read()
                .await
                .get(&info_hash)
                .unwrap()
                .stats
                .uploaded,
            1
        );

        // The peer disconnects before its next batch notification. The
        // terminal handler must drain the remaining bytes exactly once and
        // enforce the same configured ratio threshold.
        task.active_peers[&peer_addr]
            .upload_accounting
            .pending_uploaded_bytes
            .store(1, Ordering::Relaxed);
        task.handle_peer_event(PeerEvent::Disconnected {
            peer: peer_addr,
            id: peer_id,
            outstanding: Vec::new(),
        })
        .await;

        assert!(task.paused);
        assert_eq!(
            registry.read().await.get(&info_hash).unwrap().state,
            TorrentState::Paused
        );
        assert_eq!(
            registry
                .read()
                .await
                .get(&info_hash)
                .unwrap()
                .stats
                .uploaded,
            2
        );
    }

    #[tokio::test]
    async fn recheck_preserves_a_paused_torrent_lifecycle_state() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [12; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "paused.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("paused.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Paused).unwrap();
        persist_task_row(&conn, &entry, &meta);
        let job_id = "queued-recheck".to_owned();
        rt_db::upsert_job(
            &conn,
            &rt_db::JobRow {
                job_id: job_id.clone(),
                kind: "recheck_torrent".to_owned(),
                state: JOB_STATE_RUNNING.to_owned(),
                dry_run: false,
                affected_torrents: vec![info_hash.clone()],
                total: 1,
                done: 0,
                checkpoint: 0,
                file_index: Some(0),
                piece_index: Some(0),
                byte_offset: Some(0),
                verified_bytes: 0,
                invalid_pieces: Vec::new(),
                error: None,
                created_at: 1,
                started_at: Some(1),
                updated_at: 1,
                finished_at: None,
            },
        )
        .unwrap();
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(4);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Paused,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        // The task is already doing its implicit paused-torrent scan. The
        // explicit command must attach the durable job to that scan rather
        // than being discarded, and an unrelated stale cancellation must not
        // stop it.
        cmd_tx
            .send(TorrentCmd::Recheck {
                job_id: Some(job_id.clone()),
            })
            .await
            .unwrap();
        cmd_tx
            .send(TorrentCmd::CancelJob {
                job_id: "stale-recheck".to_owned(),
            })
            .await
            .unwrap();

        assert!(matches!(
            task.run_recheck(None).await,
            RecheckOutcome::Complete
        ));
        assert!(task.paused);
        assert_eq!(
            registry.read().await.get(&info_hash).unwrap().state,
            TorrentState::Paused
        );
        assert_eq!(
            rt_db::get(&db.lock().unwrap(), &info_hash).unwrap().state,
            TorrentState::Paused.as_str()
        );
        assert_eq!(
            rt_db::get_job(&db.lock().unwrap(), &job_id).unwrap().state,
            JOB_STATE_COMPLETED
        );
    }

    #[tokio::test]
    async fn recheck_pause_persistence_failure_keeps_verification_running() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [15; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "pause-failure.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("pause-failure.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        rt_db::upsert(
            &conn,
            &crate::engine::row_from_entry(&entry, &rt_metainfo::TorrentMeta::V1(meta.clone())),
        )
        .unwrap();
        registry.write().await.add(entry).unwrap();
        conn.execute_batch(
            "CREATE TRIGGER fail_paused_state
             BEFORE UPDATE OF state ON torrents
             WHEN NEW.state = 'paused'
             BEGIN SELECT RAISE(ABORT, 'injected paused state failure'); END;",
        )
        .unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        let (pause_reply, pause_result) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::Pause {
                reply: Some(pause_reply),
            })
            .await
            .unwrap();

        assert!(matches!(
            task.run_recheck(None).await,
            RecheckOutcome::Complete
        ));
        assert!(pause_result.await.unwrap().is_err());
        assert!(!task.paused);
        assert_eq!(
            registry.read().await.get(&info_hash).unwrap().state,
            TorrentState::Downloading
        );
        assert_eq!(
            rt_db::get(&db.lock().unwrap(), &info_hash).unwrap().state,
            TorrentState::Downloading.as_str()
        );
    }

    #[tokio::test]
    async fn cancelled_recheck_preserves_a_stopped_torrent_lifecycle_state() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [13; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "stopped.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("stopped.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        persist_task_row(&conn, &entry, &meta);
        rt_db::upsert_job(
            &conn,
            &rt_db::JobRow {
                job_id: "stopped-recheck".to_owned(),
                kind: "recheck_torrent".to_owned(),
                state: JOB_STATE_CANCELLING.to_owned(),
                dry_run: false,
                affected_torrents: vec![info_hash.clone()],
                total: 1,
                done: 0,
                checkpoint: 0,
                file_index: Some(0),
                piece_index: Some(0),
                byte_offset: Some(0),
                verified_bytes: 0,
                invalid_pieces: Vec::new(),
                error: None,
                created_at: 1,
                started_at: Some(1),
                updated_at: 1,
                finished_at: None,
            },
        )
        .unwrap();
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Stopped,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        cmd_tx
            .send(TorrentCmd::CancelJob {
                job_id: "stopped-recheck".to_owned(),
            })
            .await
            .unwrap();

        assert!(matches!(
            task.run_recheck(Some("stopped-recheck".to_owned())).await,
            RecheckOutcome::Cancelled
        ));
        assert!(task.paused);
        assert_eq!(
            registry.read().await.get(&info_hash).unwrap().state,
            TorrentState::Stopped
        );
        assert_eq!(
            rt_db::get(&db.lock().unwrap(), &info_hash).unwrap().state,
            TorrentState::Stopped.as_str()
        );
        assert_eq!(
            rt_db::get_job(&db.lock().unwrap(), "stopped-recheck")
                .unwrap()
                .state,
            JOB_STATE_CANCELLED
        );
    }

    #[tokio::test]
    async fn stopped_dormant_promotion_does_not_become_paused_before_command() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [14; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "staged.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("staged.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(1);
        let task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Stopped,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        let handle = tokio::spawn(task.run());

        timeout(Duration::from_secs(1), async {
            loop {
                let state = db
                    .lock()
                    .unwrap()
                    .query_row(
                        "SELECT state FROM torrents WHERE info_hash = ?1",
                        [&info_hash],
                        |row| row.get::<_, String>(0),
                    )
                    .ok();
                if state.as_deref() == Some(TorrentState::Stopped.as_str()) {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("stopped promotion did not persist its staged state");
        assert_eq!(
            registry.read().await.get(&info_hash).unwrap().state,
            TorrentState::Stopped
        );

        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(1), handle)
            .await
            .expect("staged torrent task did not shut down")
            .unwrap();
    }

    #[tokio::test]
    async fn queued_dormant_promotion_preserves_queue_before_command() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [16; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "queued.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("queued.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        entry.state = TorrentState::Queued;
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(1);
        let task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Queued,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        let handle = tokio::spawn(task.run());

        timeout(Duration::from_secs(1), async {
            loop {
                let state = db
                    .lock()
                    .unwrap()
                    .query_row(
                        "SELECT state FROM torrents WHERE info_hash = ?1",
                        [&info_hash],
                        |row| row.get::<_, String>(0),
                    )
                    .ok();
                if state.as_deref() == Some(TorrentState::Queued.as_str()) {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("queued promotion did not preserve its staged state");
        assert_eq!(
            registry.read().await.get(&info_hash).unwrap().state,
            TorrentState::Queued
        );

        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(1), handle)
            .await
            .expect("queued promotion task did not shut down")
            .unwrap();
    }

    #[tokio::test]
    async fn checking_restore_rechecks_even_when_fastresume_claims_complete() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [23; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "checking-restore.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("checking-restore.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let mut fastresume =
            FastresumeState::new_empty(&meta.info_hash, 1, ImportPolicy::RequireVerification);
        fastresume.clean_shutdown = true;
        fastresume.pieces = vec![PieceState::Valid];
        FastresumeStore::new(temp.path().join("fastresume"))
            .save(&fastresume)
            .unwrap();

        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 0;
        // This is the state persisted when a process stops after admitting a
        // recheck job but before the scan completes. It must take precedence
        // over an older fastresume bitmap.
        entry.state = TorrentState::Checking;
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();

        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(4);
        let task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Checking,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        let handle = tokio::spawn(task.run());

        timeout(Duration::from_secs(2), async {
            loop {
                let state = db
                    .lock()
                    .unwrap()
                    .query_row(
                        "SELECT state FROM torrents WHERE info_hash = ?1",
                        [&info_hash],
                        |row| row.get::<_, String>(0),
                    )
                    .ok();
                if state.as_deref() == Some(TorrentState::Downloading.as_str()) {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("checking restore did not verify the current payload");
        assert_eq!(
            registry.read().await.get(&info_hash).unwrap().state,
            TorrentState::Downloading
        );

        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(1), handle)
            .await
            .expect("checking restore task did not shut down")
            .unwrap();
    }

    #[tokio::test]
    async fn error_dormant_promotion_accepts_resume_before_recovery() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [15; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "error-recovery.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("error-recovery.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.set_error("previous task failure");
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(2);
        let task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Error,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        let handle = tokio::spawn(task.run());
        let (reply, response) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::Resume { reply: Some(reply) })
            .await
            .unwrap();
        assert_eq!(
            timeout(Duration::from_secs(2), response)
                .await
                .expect("error promotion did not receive a resume acknowledgement")
                .unwrap(),
            Ok(())
        );
        assert_eq!(
            registry.read().await.get(&info_hash).unwrap().state,
            TorrentState::Checking
        );

        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(1), handle)
            .await
            .expect("error recovery task did not shut down")
            .unwrap();
    }

    #[test]
    fn decodes_peer_wire_bitfield_msb_first() {
        assert_eq!(
            bitfield_to_pieces(&[0b1010_0000], 8).unwrap(),
            vec![true, false, true, false, false, false, false, false]
        );
    }

    #[test]
    fn rejects_invalid_peer_wire_bitfield_shape() {
        assert!(bitfield_to_pieces(&[0b1010_0000, 0], 8).is_err());
        assert!(bitfield_to_pieces(&[], 8).is_err());
        assert!(bitfield_to_pieces(&[0b1010_0001], 4).is_err());
        assert_eq!(
            bitfield_to_pieces(&[0b1010_0000], 4).unwrap(),
            vec![true, false, true, false]
        );
    }

    #[test]
    fn peer_bitmap_set_iteration_visits_only_valid_set_pieces() {
        let mut pieces = PieceBitmap::new(65);
        pieces.set(0, true);
        pieces.set(63, true);
        pieces.set(64, true);
        let mut visited = Vec::new();
        pieces.for_each_set_piece(64, &mut |piece| visited.push(piece));

        assert_eq!(visited, [0, 63]);
        visited.clear();
        pieces.for_each_set_piece(65, &mut |piece| visited.push(piece));
        assert_eq!(visited, [0, 63, 64]);

        visited.clear();
        pieces.for_each_set_piece_while(65, &mut |piece| {
            visited.push(piece);
            false
        });
        assert_eq!(visited, [0], "bounded work stops at the first set bit");
    }

    #[test]
    fn peer_bitfield_reservation_is_bounded_by_governor() {
        let mut bits = [0xff; 9];
        bits[8] = 0x80;
        let pieces = PieceBitmap::from_bitfield(&bits, 65).unwrap();
        let bytes = pieces.memory_bytes();
        assert_eq!(bytes, 2 * std::mem::size_of::<u64>() as u64);

        let mut class_caps_bytes = [0; rt_metrics::MEMORY_CLASS_COUNT];
        class_caps_bytes[MemoryClass::PeerBuffer as usize] = bytes;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: bytes,
            class_caps_bytes,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });

        let lease = reserve_peer_bitfield_bytes(&governor, &pieces).unwrap();
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            bytes
        );
        assert!(reserve_peer_bitfield_bytes(&governor, &pieces).is_err());
        drop(lease);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[test]
    fn peer_bitfield_wire_reservation_covers_transient_copies() {
        let pieces = PieceBitmap::from_bools(&[true; 65]);
        let wire_bytes = 3 * pieces.len().div_ceil(8) as u64 + 5;
        let mut class_caps_bytes = [0; rt_metrics::MEMORY_CLASS_COUNT];
        class_caps_bytes[MemoryClass::PeerBuffer as usize] = wire_bytes;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: wire_bytes,
            class_caps_bytes,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });

        let lease = reserve_peer_bitfield_wire_bytes(&governor, &pieces).unwrap();
        assert_eq!(lease.bytes(), wire_bytes);
        assert!(reserve_peer_bitfield_wire_bytes(&governor, &pieces).is_err());
        drop(lease);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[test]
    fn piece_assembly_reservation_is_owned_until_assembly_drop() {
        let bytes = 4 * 1024usize;
        let mut class_caps_bytes = [0; rt_metrics::MEMORY_CLASS_COUNT];
        class_caps_bytes[MemoryClass::PieceAssembly as usize] = bytes as u64;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: bytes as u64,
            class_caps_bytes,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });

        let lease = reserve_piece_assembly_bytes(&governor, bytes).unwrap();
        let assembly = PieceAssembly::with_memory_lease(bytes, lease);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PieceAssembly as usize].used_bytes,
            bytes as u64
        );
        assert!(reserve_piece_assembly_bytes(&governor, 1).is_err());
        drop(assembly);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PieceAssembly as usize].used_bytes,
            0
        );
    }

    #[test]
    fn encodes_piece_flags_to_peer_wire_bitfield_msb_first() {
        assert_eq!(
            pieces_to_bitfield(&[true, false, true, false, false, false, false, false, true]),
            vec![0b1010_0000, 0b1000_0000]
        );
    }

    #[test]
    fn stricter_limit_uses_lowest_enabled_limit() {
        assert_eq!(stricter_limit(Some(10), Some(20)), Some(10));
        assert_eq!(stricter_limit(Some(30), Some(20)), Some(20));
        assert_eq!(stricter_limit(Some(30), None), Some(30));
        assert_eq!(stricter_limit(None, Some(40)), Some(40));
        assert_eq!(stricter_limit(None, None), None);
    }

    #[test]
    fn parses_outgoing_utp_policy() {
        assert_eq!(
            parse_outgoing_transport_policy("auto"),
            OutgoingTransportPolicy::Auto
        );
        assert_eq!(
            parse_outgoing_transport_policy("prefer"),
            OutgoingTransportPolicy::PreferUtp
        );
        assert_eq!(
            parse_outgoing_transport_policy("utp-only"),
            OutgoingTransportPolicy::UtpOnly
        );
        assert_eq!(
            parse_outgoing_transport_policy("off"),
            OutgoingTransportPolicy::TcpOnly
        );
    }

    #[test]
    fn auto_outgoing_utp_policy_is_source_and_privacy_aware() {
        assert_eq!(
            outgoing_transport_policy_for_peer(
                OutgoingTransportPolicy::Auto,
                PeerSource::Tracker,
                false
            ),
            OutgoingTransportPolicy::TcpOnly
        );
        assert_eq!(
            outgoing_transport_policy_for_peer(
                OutgoingTransportPolicy::Auto,
                PeerSource::Dht,
                false
            ),
            OutgoingTransportPolicy::PreferUtp
        );
        assert_eq!(
            outgoing_transport_policy_for_peer(
                OutgoingTransportPolicy::Auto,
                PeerSource::PeerExchange,
                false
            ),
            OutgoingTransportPolicy::PreferUtp
        );
        assert_eq!(
            outgoing_transport_policy_for_peer(
                OutgoingTransportPolicy::UtpOnly,
                PeerSource::Manual,
                true
            ),
            OutgoingTransportPolicy::TcpOnly
        );
    }

    #[test]
    fn super_seed_visible_pieces_reveals_one_available_piece() {
        let addr = "127.0.0.1:6881".parse().unwrap();
        let visible = super_seed_visible_pieces(&[true, true, false, true], 4, addr);

        assert_eq!(visible.count_ones(), 1);
        assert_eq!(visible.get(2), Some(false));
    }

    #[test]
    fn super_seed_visible_pieces_handles_empty_have_set() {
        let addr = "127.0.0.1:6881".parse().unwrap();

        assert_eq!(
            super_seed_visible_pieces(&[false, false, false], 3, addr),
            PieceBitmap::new(3)
        );
    }

    #[test]
    fn webseed_block_url_accepts_direct_file_and_base_url() {
        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "sample.iso".into(),
            piece_length: 16_384,
            pieces: vec![[2; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 5,
                path: rt_path::SafeRelPath::from_name("sample.iso", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };

        assert_eq!(
            webseed_block_url(&meta, "https://mirror.example/sample.iso")
                .unwrap()
                .as_str(),
            "https://mirror.example/sample.iso"
        );
        assert_eq!(
            webseed_block_url(&meta, "https://mirror.example/releases/")
                .unwrap()
                .as_str(),
            "https://mirror.example/releases/sample.iso"
        );
        assert!(webseed_block_url(&meta, "ftp://mirror.example/sample.iso").is_none());
    }

    #[test]
    fn webseed_block_url_expands_single_file_directory_prefix() {
        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "payload-dir".into(),
            piece_length: 16_384,
            pieces: vec![[2; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 5,
                path: rt_path::SafeRelPath::from_components(&["payload-dir", "payload.bin"], false)
                    .unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };

        assert_eq!(
            webseed_block_url(&meta, "https://mirror.example/payload-dir")
                .unwrap()
                .as_str(),
            "https://mirror.example/payload-dir/payload.bin"
        );
    }

    #[test]
    fn multi_file_webseed_url_appends_torrent_root_and_file_path() {
        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "release".into(),
            piece_length: 16_384,
            pieces: vec![[2; 20]],
            files: vec![
                rt_metainfo::TorrentFileV1 {
                    index: 0,
                    length: 5,
                    path: rt_path::SafeRelPath::from_components(
                        &["release", "docs", "readme.txt"],
                        false,
                    )
                    .unwrap(),
                    offset: 0,
                    pad: false,
                },
                rt_metainfo::TorrentFileV1 {
                    index: 1,
                    length: 7,
                    path: rt_path::SafeRelPath::from_components(&["release", "payload.bin"], false)
                        .unwrap(),
                    offset: 5,
                    pad: false,
                },
            ],
            private: false,
            raw: Vec::new(),
        };

        assert_eq!(
            webseed_file_url(&meta, &meta.files[0], "https://mirror.example/pub/")
                .unwrap()
                .as_str(),
            "https://mirror.example/pub/release/docs/readme.txt"
        );
        assert_eq!(
            webseed_file_url(&meta, &meta.files[0], "https://mirror.example/pub/release")
                .unwrap()
                .as_str(),
            "https://mirror.example/pub/release/docs/readme.txt"
        );
    }

    #[test]
    fn webseed_block_ranges_split_files_and_synthesize_padding() {
        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "release".into(),
            piece_length: 16_384,
            pieces: vec![[2; 20]],
            files: vec![
                rt_metainfo::TorrentFileV1 {
                    index: 0,
                    length: 3,
                    path: rt_path::SafeRelPath::from_components(&["release", "a.bin"], false)
                        .unwrap(),
                    offset: 0,
                    pad: false,
                },
                rt_metainfo::TorrentFileV1 {
                    index: 1,
                    length: 2,
                    path: rt_path::SafeRelPath::from_components(&["release", ".pad", "2"], false)
                        .unwrap(),
                    offset: 3,
                    pad: true,
                },
                rt_metainfo::TorrentFileV1 {
                    index: 2,
                    length: 4,
                    path: rt_path::SafeRelPath::from_components(&["release", "b.bin"], false)
                        .unwrap(),
                    offset: 5,
                    pad: false,
                },
            ],
            private: false,
            raw: Vec::new(),
        };

        let ranges = webseed_block_ranges(
            &meta,
            BlockRequest {
                piece: 0,
                begin: 1,
                length: 6,
            },
        )
        .unwrap();

        assert_eq!(ranges.len(), 3);
        assert_eq!(
            (
                ranges[0].file_offset,
                ranges[0].block_offset,
                ranges[0].length,
                ranges[0].file.pad,
            ),
            (1, 0, 2, false)
        );
        assert_eq!(
            (
                ranges[1].file_offset,
                ranges[1].block_offset,
                ranges[1].length,
                ranges[1].file.pad,
            ),
            (0, 2, 2, true)
        );
        assert_eq!(
            (
                ranges[2].file_offset,
                ranges[2].block_offset,
                ranges[2].length,
                ranges[2].file.pad,
            ),
            (0, 4, 2, false)
        );

        let mut piece_boundary_meta = meta.clone();
        piece_boundary_meta.piece_length = 6;
        assert!(webseed_block_ranges(
            &piece_boundary_meta,
            BlockRequest {
                piece: 0,
                begin: 1,
                length: 6,
            }
        )
        .is_none());
    }

    #[test]
    fn webseed_block_ranges_reject_excessive_file_fanout() {
        let files = (0..=MAX_WEBSEED_RANGES_PER_BLOCK)
            .map(|index| {
                let filename = format!("{index}.bin");
                rt_metainfo::TorrentFileV1 {
                    index: index as u32,
                    length: 1,
                    path: rt_path::SafeRelPath::from_components(
                        &["release", filename.as_str()],
                        false,
                    )
                    .unwrap(),
                    offset: index as u64,
                    pad: false,
                }
            })
            .collect();
        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "release".into(),
            piece_length: 16_384,
            pieces: vec![[2; 20]],
            files,
            private: false,
            raw: Vec::new(),
        };

        assert!(webseed_block_ranges(
            &meta,
            BlockRequest {
                piece: 0,
                begin: 0,
                length: (MAX_WEBSEED_RANGES_PER_BLOCK + 1) as u32,
            }
        )
        .is_none());

        let mut overflow_meta = meta;
        overflow_meta.piece_length = u64::MAX;
        assert!(webseed_block_ranges(
            &overflow_meta,
            BlockRequest {
                piece: 2,
                begin: 0,
                length: 1,
            }
        )
        .is_none());
    }

    #[test]
    fn webseed_range_response_rejects_server_that_ignores_range() {
        let headers = reqwest::header::HeaderMap::new();

        let error =
            validate_webseed_range_response(StatusCode::OK, &headers, 16_384, 32_767).unwrap_err();

        assert!(error.to_string().contains("did not honor byte range"));
    }

    #[test]
    fn webseed_file_byte_range_rejects_invalid_or_overflowing_coordinates() {
        assert_eq!(
            webseed_file_byte_range(32_772, 8).unwrap(),
            (32_772, 32_779)
        );
        assert!(webseed_file_byte_range(0, 0).is_err());
        assert!(webseed_file_byte_range(u64::MAX, 2).is_err());
        assert!(webseed_file_byte_range(0, MAX_BLOCK_SIZE as usize + 1).is_err());
    }

    #[test]
    fn webseed_error_log_text_redacts_credentials_and_controls() {
        let error = anyhow::anyhow!(
            "request failed for https://seed-user:seed-secret@cdn.example/private/key?token=query-secret#fragment\n\u{001b}[31mspoof"
        );

        let message = webseed_error_for_log(&error);

        assert!(message.contains("https://cdn.example/"));
        assert!(message.contains("spoof"));
        assert!(!message.chars().any(char::is_control));
        for secret in [
            "seed-user",
            "seed-secret",
            "private",
            "query-secret",
            "fragment",
        ] {
            assert!(!message.contains(secret), "{message}");
        }
    }

    #[test]
    fn webseed_range_response_requires_the_requested_content_range() {
        let mut headers = reqwest::header::HeaderMap::new();
        headers.insert(
            CONTENT_RANGE,
            reqwest::header::HeaderValue::from_static("bytes 16384-32767/65536"),
        );

        assert!(validate_webseed_range_response(
            StatusCode::PARTIAL_CONTENT,
            &headers,
            16_384,
            32_767,
        )
        .is_ok());
        assert!(
            validate_webseed_range_response(StatusCode::PARTIAL_CONTENT, &headers, 0, 16_383,)
                .is_err()
        );
    }

    #[test]
    fn parses_ut_pex_added_ipv4_peers() {
        let added = [127, 0, 0, 1, 0x1a, 0xe1, 10, 0, 0, 2, 0x13, 0x88];
        let payload = rt_bencode::encode(&BValue::Dict(vec![(
            b"added".as_slice(),
            BValue::Bytes(&added),
        )]));

        let peers = parse_ut_pex_peers(&payload).unwrap();

        assert_eq!(
            peers.added,
            vec![
                "127.0.0.1:6881".parse::<SocketAddr>().unwrap(),
                "10.0.0.2:5000".parse::<SocketAddr>().unwrap(),
            ]
        );
    }

    #[test]
    fn parses_ut_pex_added6_ipv6_peers() {
        // TNG-020: added6 (BEP 11 IPv6 compact peers, 16-byte address + 2-byte
        // port) was previously not parsed at all -- only IPv4 `added`.
        let mut added6 = Vec::new();
        added6.extend_from_slice(&Ipv6Addr::LOCALHOST.octets());
        added6.extend_from_slice(&0x1a_e1u16.to_be_bytes());
        added6.extend_from_slice(&Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1).octets());
        added6.extend_from_slice(&0x1388u16.to_be_bytes());
        let payload = rt_bencode::encode(&BValue::Dict(vec![(
            b"added6".as_slice(),
            BValue::Bytes(&added6),
        )]));

        let peers = parse_ut_pex_peers(&payload).unwrap();

        assert_eq!(
            peers.added,
            vec![
                SocketAddr::V6(SocketAddrV6::new(Ipv6Addr::LOCALHOST, 6881, 0, 0)),
                SocketAddr::V6(SocketAddrV6::new(
                    Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1),
                    5000,
                    0,
                    0
                )),
            ]
        );
    }

    #[test]
    fn parses_ut_pex_added_and_added6_together() {
        let added = [10, 0, 0, 2, 0x13, 0x88];
        let mut added6 = Vec::new();
        added6.extend_from_slice(&Ipv6Addr::LOCALHOST.octets());
        added6.extend_from_slice(&0x1a_e1u16.to_be_bytes());
        let payload = rt_bencode::encode(&BValue::Dict(vec![
            (b"added".as_slice(), BValue::Bytes(&added)),
            (b"added6".as_slice(), BValue::Bytes(&added6)),
        ]));

        let peers = parse_ut_pex_peers(&payload).unwrap();

        assert_eq!(
            peers.added,
            vec![
                "10.0.0.2:5000".parse::<SocketAddr>().unwrap(),
                SocketAddr::V6(SocketAddrV6::new(Ipv6Addr::LOCALHOST, 6881, 0, 0)),
            ]
        );
    }

    #[test]
    fn parses_ut_pex_dropped_ipv4_and_ipv6_peers() {
        let dropped = [10, 0, 0, 2, 0x13, 0x88];
        let mut dropped6 = Vec::new();
        dropped6.extend_from_slice(&Ipv6Addr::LOCALHOST.octets());
        dropped6.extend_from_slice(&0x1a_e1u16.to_be_bytes());
        let payload = rt_bencode::encode(&BValue::Dict(vec![
            (b"dropped".as_slice(), BValue::Bytes(&dropped)),
            (b"dropped6".as_slice(), BValue::Bytes(&dropped6)),
        ]));

        let peers = parse_ut_pex_peers(&payload).unwrap();

        assert!(peers.added.is_empty());
        assert_eq!(
            peers.dropped,
            vec![
                "10.0.0.2:5000".parse::<SocketAddr>().unwrap(),
                SocketAddr::V6(SocketAddrV6::new(Ipv6Addr::LOCALHOST, 6881, 0, 0)),
            ]
        );
    }

    #[test]
    fn rejects_ut_pex_flat_bencode_node_bombs() {
        let mut payload = b"l".to_vec();
        for _ in 0..=MAX_UT_PEX_BENCODE_NODES {
            payload.extend_from_slice(b"i1e");
        }
        payload.push(b'e');

        let error = parse_ut_pex_peers(&payload).unwrap_err();
        assert!(error.to_string().contains("node limit exceeded"));
    }

    #[test]
    fn private_torrent_extension_handshake_does_not_advertise_pex() {
        let metadata = Arc::new(vec![1, 2, 3, 4]);

        let public = extension_handshake_for_torrent(Some(&metadata), false, true);
        let private = extension_handshake_for_torrent(Some(&metadata), true, true);
        let disabled = extension_handshake_for_torrent(Some(&metadata), false, false);

        assert_eq!(public.ut_metadata_id(), Some(LOCAL_UT_METADATA_ID));
        assert_eq!(public.ut_pex_id(), Some(LOCAL_UT_PEX_ID));
        assert_eq!(private.ut_metadata_id(), Some(LOCAL_UT_METADATA_ID));
        assert_eq!(private.ut_pex_id(), None);
        assert_eq!(disabled.ut_metadata_id(), Some(LOCAL_UT_METADATA_ID));
        assert_eq!(disabled.ut_pex_id(), None);
    }

    #[test]
    fn metadata_response_rejects_unrepresentable_or_out_of_range_piece() {
        let metadata = vec![1, 2, 3, 4];

        assert_eq!(
            metadata_response(u32::MAX, &metadata),
            UtMetadataMessage::Reject { piece: u32::MAX }
        );
        assert_eq!(
            metadata_response(1, &metadata),
            UtMetadataMessage::Reject { piece: 1 }
        );
    }

    #[test]
    fn file_hints_capture_size_mtime_and_inode() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("sample.bin"), b"hello").unwrap();

        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "sample.bin".into(),
            piece_length: 16_384,
            pieces: vec![[2; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 3,
                length: 5,
                path: rt_path::SafeRelPath::from_name("sample.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };

        let hints = collect_file_hints(dir.path(), &meta);

        assert_eq!(hints.len(), 1);
        assert_eq!(hints[0].file_index, 3);
        assert_eq!(hints[0].size, 5);
        assert!(hints[0].mtime_secs > 0);
    }

    #[test]
    fn file_hints_omit_missing_files_without_failing_the_whole_torrent() {
        // Regression test for the "one missing file poisons the whole
        // torrent's fastresume trust" bug: a multi-file torrent where one
        // file is absent (e.g. a BEP47 padding file real clients never
        // write, or a renamed/deleted file) must still return hints for
        // every OTHER file that does exist on disk.
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("present.bin"), b"hello").unwrap();
        // The missing data file and synthetic pad entry are both omitted
        // without suppressing a hint for the present payload file.

        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "multi".into(),
            piece_length: 16_384,
            pieces: vec![[2; 20]],
            files: vec![
                rt_metainfo::TorrentFileV1 {
                    index: 0,
                    length: 5,
                    path: rt_path::SafeRelPath::from_name("present.bin", false).unwrap(),
                    offset: 0,
                    pad: false,
                },
                rt_metainfo::TorrentFileV1 {
                    index: 1,
                    length: 0,
                    path: rt_path::SafeRelPath::from_name("missing.bin", false).unwrap(),
                    offset: 5,
                    pad: false,
                },
                rt_metainfo::TorrentFileV1 {
                    index: 2,
                    length: 11,
                    path: rt_path::SafeRelPath::from_components(&[".pad", "11"], false).unwrap(),
                    offset: 5,
                    pad: true,
                },
            ],
            private: false,
            raw: Vec::new(),
        };

        let hints = collect_file_hints(dir.path(), &meta);

        assert_eq!(hints.len(), 1, "only the present file should have a hint");
        assert_eq!(hints[0].file_index, 0);
        assert_eq!(hints[0].size, 5);
    }

    #[test]
    fn outstanding_piece_match_requires_exact_length() {
        let mut outstanding = vec![OutstandingRequest::new(
            BlockRequest {
                piece: 4,
                begin: 16_384,
                length: 16_384,
            },
            None,
        )];

        assert!(take_matching_outstanding(&mut outstanding, 4, 16_384, 8_192).is_none());
        assert_eq!(outstanding.len(), 1);
        assert!(take_matching_outstanding(&mut outstanding, 4, 16_384, 16_384).is_some());
        assert!(outstanding.is_empty());
    }

    #[test]
    fn fast_choke_keeps_wire_request_lease_and_legacy_choke_releases_it() {
        let mut class_caps = [0; rt_metrics::MEMORY_CLASS_COUNT];
        class_caps[MemoryClass::PeerBuffer as usize] = 8;
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: 8,
            class_caps_bytes: class_caps,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });
        let request = BlockRequest {
            piece: 4,
            begin: 0,
            length: 4,
        };
        let lease = reserve_peer_event_bytes(&resources, 4).unwrap();
        let mut fast_outstanding = vec![OutstandingRequest::new(request, Some(lease))];

        assert_eq!(
            take_choked_requests(&mut fast_outstanding, true),
            vec![request]
        );
        assert_eq!(fast_outstanding.len(), 1);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            4
        );

        let lease = reserve_peer_event_bytes(&resources, 4).unwrap();
        let mut legacy_outstanding = vec![OutstandingRequest::new(request, Some(lease))];
        assert_eq!(
            take_choked_requests(&mut legacy_outstanding, false),
            vec![request]
        );
        assert!(legacy_outstanding.is_empty());
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            4,
            "the Fast peer's original response remains outstanding"
        );
        drop(fast_outstanding);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[test]
    fn timed_out_requests_are_returned_for_requeue() {
        let mut outstanding = vec![
            OutstandingRequest {
                req: BlockRequest {
                    piece: 1,
                    begin: 0,
                    length: 16_384,
                },
                wire_req: BlockRequest {
                    piece: 1,
                    begin: 0,
                    length: 16_384,
                },
                sent_at: Instant::now() - Duration::from_secs(120),
                memory_lease: None,
                rate_grant: None,
                _source_permit: None,
            },
            OutstandingRequest::new(
                BlockRequest {
                    piece: 2,
                    begin: 0,
                    length: 16_384,
                },
                None,
            ),
        ];

        let timed_out = take_timed_out_requests(&mut outstanding, Duration::from_secs(60));

        assert_eq!(timed_out.len(), 1);
        assert_eq!(timed_out[0].piece, 1);
        assert_eq!(outstanding.len(), 1);
        assert_eq!(outstanding[0].req.piece, 2);
    }

    #[test]
    fn timed_out_request_refunds_its_reserved_download_grant() {
        let budget = GlobalNetworkBudget::unlimited();
        let torrent = budget.new_transfer_torrent_key();
        budget.register_download_torrent(torrent, Some(1));
        let peer = TransferPeerId::new(
            torrent,
            ConnectionId {
                slot: 0,
                generation: 1,
            },
        );
        budget.register_transfer_peer(peer);
        let grant = match budget.try_acquire_download(peer, 4).unwrap() {
            RateAdmissionAttempt::Granted(grant) => grant,
            RateAdmissionAttempt::Wait(delay) => {
                panic!("startup burst should admit block: {delay:?}")
            }
            RateAdmissionAttempt::WaitForChange => {
                panic!("startup burst unexpectedly waited for fairness progress")
            }
        };
        assert_eq!(
            budget.download_available_credit_bytes_for(peer),
            16 * 1024 - 4
        );

        let request = BlockRequest {
            piece: 3,
            begin: 0,
            length: 4,
        };
        let mut outstanding = vec![OutstandingRequest::with_rate_grant(
            request,
            request,
            None,
            Some(grant),
            None,
        )];
        assert_eq!(
            take_timed_out_requests(&mut outstanding, Duration::ZERO),
            vec![request]
        );
        assert_eq!(budget.download_available_credit_bytes_for(peer), 16 * 1024);
    }

    #[test]
    fn piece_assembly_tracks_complete_piece_bytes() {
        let mut assembly = PieceAssembly::new((MAX_BLOCK_SIZE * 2) as usize);
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        assembly.insert(0, &[1; MAX_BLOCK_SIZE as usize]).unwrap();
        assert!(!assembly.is_complete());
        let received = assembly.received_blocks(&resources, 0).unwrap();
        assert_eq!(received.len(), 1);
        assert_eq!(received[0].0, 0);
        assert_eq!(received[0].1.len(), MAX_BLOCK_SIZE as usize);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            u64::from(MAX_BLOCK_SIZE)
        );
        drop(received);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
        assembly
            .insert(MAX_BLOCK_SIZE, &[2; MAX_BLOCK_SIZE as usize])
            .unwrap();
        assert!(assembly.is_complete());
        assert_eq!(assembly.data()[0], 1);
        assert_eq!(assembly.data()[MAX_BLOCK_SIZE as usize], 2);
    }

    #[test]
    fn completed_piece_freezes_and_reuses_its_assembly_allocation() {
        let mut assembly = PieceAssembly::new(MAX_BLOCK_SIZE as usize);
        let original_allocation = assembly.data.as_ptr();
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());

        assembly
            .insert(0, &[0xA5; MAX_BLOCK_SIZE as usize])
            .unwrap();

        let completed = assembly.completed_data.as_ref().unwrap();
        assert_eq!(completed.as_ptr(), original_allocation);
        assert_eq!(completed[0], 0xA5);
        let blocks = assembly.received_blocks(&resources, 0).unwrap();
        assert_eq!(blocks.len(), 1);
        assert_eq!(blocks[0].1.block.data.as_ptr(), completed.as_ptr());
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0,
            "completed payload slices should not reserve copied block buffers"
        );
    }

    #[test]
    fn completed_payload_views_keep_piece_lease_after_assembly_is_dropped() {
        let piece_len = MAX_BLOCK_SIZE as usize;
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let lease = resources
            .try_acquire(MemoryClass::PieceAssembly, piece_len as u64)
            .unwrap();
        let mut assembly = PieceAssembly::with_memory_lease(piece_len, lease);
        assembly
            .insert(0, &[0x5A; MAX_BLOCK_SIZE as usize])
            .unwrap();
        let payload_view = assembly.completed_data.as_ref().unwrap().slice(0..128);

        assert!(assembly._memory_lease.is_some());
        drop(assembly);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PieceAssembly as usize].used_bytes,
            piece_len as u64,
            "a queued Bytes view must keep the complete backing allocation charged"
        );
        drop(payload_view);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PieceAssembly as usize].used_bytes,
            0
        );
    }

    #[test]
    fn evicted_block_views_share_the_assembly_memory_lease() {
        let piece_len = (MAX_BLOCK_SIZE * 2) as usize;
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let lease = resources
            .try_acquire(MemoryClass::PieceAssembly, piece_len as u64)
            .unwrap();
        let mut assembly = PieceAssembly::with_memory_lease(piece_len, lease);
        assembly
            .insert(0, &[0xA1; MAX_BLOCK_SIZE as usize])
            .unwrap();
        assembly
            .insert(MAX_BLOCK_SIZE, &[0xB2; MAX_BLOCK_SIZE as usize])
            .unwrap();

        let completed_ptr = assembly.completed_data.as_ref().unwrap().as_ptr();
        let mut blocks = assembly.into_received_blocks(7).unwrap();
        assert_eq!(blocks.len(), 2);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PieceAssembly as usize].used_bytes,
            piece_len as u64
        );
        assert_eq!(blocks[0].1.block.data[0], 0xA1);
        assert_eq!(blocks[1].1.block.data[0], 0xB2);
        assert_eq!(blocks[0].1.block.data.as_ptr(), completed_ptr);
        assert_eq!(
            blocks[1].1.block.data.as_ptr(),
            completed_ptr.wrapping_add(MAX_BLOCK_SIZE as usize)
        );

        let last = blocks.pop().unwrap();
        drop(blocks);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PieceAssembly as usize].used_bytes,
            piece_len as u64,
            "a shared slice still owns the original piece allocation"
        );
        drop(last);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PieceAssembly as usize].used_bytes,
            0
        );
    }

    #[test]
    fn piece_assembly_rejects_out_of_range_block() {
        let mut assembly = PieceAssembly::new(4);
        let err = assembly.insert(2, &[1, 2, 3]).unwrap_err();
        assert!(err.to_string().contains("exceeds piece length"));
    }

    #[test]
    fn piece_assembly_rejects_conflicting_duplicate_block() {
        let mut assembly = PieceAssembly::new(MAX_BLOCK_SIZE as usize);
        assembly.insert(0, &[1; MAX_BLOCK_SIZE as usize]).unwrap();
        assembly.insert(0, &[1; MAX_BLOCK_SIZE as usize]).unwrap();

        let err = assembly
            .insert(0, &[2; MAX_BLOCK_SIZE as usize])
            .unwrap_err();
        assert!(err.to_string().contains("conflicting duplicate block"));
    }

    #[tokio::test]
    async fn fastresume_flushes_partial_in_memory_assembly_to_disk() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let piece_length = u64::from(MAX_BLOCK_SIZE) * 2;
        let meta = TorrentMetaV1 {
            info_hash: [21; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "partial.bin".into(),
            piece_length,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: piece_length,
                path: rt_path::SafeRelPath::from_name("partial.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = piece_length;
        entry.amount_left = piece_length;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();

        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        task.picker.availability.add_have(0);
        let peer_has = PieceBitmap::from_bools(&[true]);
        let request = task.picker.pick(&peer_has).unwrap();
        let payload = bytes::Bytes::from(vec![0xA5; request.length as usize]);
        task.handle_block(LeasedBlockEvent::uncharged_for_test(
            request.piece,
            request.begin,
            payload.clone(),
        ))
        .await;
        assert!(task.piece_assemblies.contains_key(&request.piece));

        task.save_fastresume(false).await;

        let on_disk = std::fs::read(temp.path().join("partial.bin")).unwrap();
        assert_eq!(on_disk.len(), piece_length as usize);
        assert_eq!(&on_disk[..request.length as usize], payload.as_ref());
        assert!(on_disk[request.length as usize..]
            .iter()
            .all(|byte| *byte == 0));
        let state = task.fastresume.load(&info_hash).unwrap();
        assert_eq!(
            state.partial_pieces,
            vec![PartialPieceState {
                piece: request.piece,
                received_blocks: vec![0],
            }]
        );
    }

    #[tokio::test]
    async fn hash_failure_does_not_persist_piece_as_valid() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [22; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "invalid-piece.bin".into(),
            piece_length: 4,
            // The received payload is four 0xA5 bytes, so this deliberately
            // cannot validate against the all-zero expected hash.
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("invalid-piece.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();

        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        task.picker.availability.add_have(0);
        let request = task.picker.pick(&PieceBitmap::from_bools(&[true])).unwrap();
        task.handle_block(LeasedBlockEvent::uncharged_for_test(
            request.piece,
            request.begin,
            bytes::Bytes::from_static(b"\xA5\xA5\xA5\xA5"),
        ))
        .await;
        task.drain_transfer_jobs().await;

        let state = task.fastresume.load(&info_hash).unwrap();
        assert_eq!(state.pieces, vec![PieceState::Unknown]);
        assert!(state.partial_pieces.is_empty());
        assert!(!task.picker.have_piece(0));
    }

    #[tokio::test]
    async fn pause_flushes_partial_assembly_before_clearing_peers() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let piece_length = u64::from(MAX_BLOCK_SIZE) * 2;
        let meta = TorrentMetaV1 {
            info_hash: [24; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "pause-partial.bin".into(),
            piece_length,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: piece_length,
                path: rt_path::SafeRelPath::from_name("pause-partial.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = piece_length;
        entry.amount_left = piece_length;
        entry.transition(TorrentState::Paused).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();

        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(2);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            true,
            TorrentState::Paused,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        task.picker.availability.add_have(0);
        let request = task.picker.pick(&PieceBitmap::from_bools(&[true])).unwrap();
        let payload = bytes::Bytes::from(vec![0xA5; request.length as usize]);
        task.handle_block(LeasedBlockEvent::uncharged_for_test(
            request.piece,
            request.begin,
            payload.clone(),
        ))
        .await;
        assert!(task.piece_assemblies.contains_key(&request.piece));

        let actor = tokio::spawn(task.run());
        let (pause_reply, pause_result) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::Pause {
                reply: Some(pause_reply),
            })
            .await
            .unwrap();
        assert_eq!(
            timeout(Duration::from_secs(2), pause_result)
                .await
                .expect("pause reply was not delivered")
                .unwrap(),
            Ok(())
        );

        let on_disk = std::fs::read(temp.path().join("pause-partial.bin")).unwrap();
        assert_eq!(on_disk.len(), piece_length as usize);
        assert_eq!(&on_disk[..request.length as usize], payload.as_ref());

        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(2), actor)
            .await
            .expect("paused task did not shut down")
            .unwrap();
    }

    #[tokio::test]
    async fn recheck_flushes_partial_assembly_before_clearing_peers() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let piece_length = u64::from(MAX_BLOCK_SIZE) * 2;
        let mut complete_piece = vec![0xA5; MAX_BLOCK_SIZE as usize];
        complete_piece.extend(vec![0x5A; MAX_BLOCK_SIZE as usize]);
        let piece_hash: [u8; 20] = Sha1::digest(&complete_piece).into();
        let meta = TorrentMetaV1 {
            info_hash: [23; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "recheck-partial.bin".into(),
            piece_length,
            pieces: vec![piece_hash],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: piece_length,
                path: rt_path::SafeRelPath::from_name("recheck-partial.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = piece_length;
        entry.amount_left = piece_length;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();

        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        task.picker.availability.add_have(0);
        let request = task.picker.pick(&PieceBitmap::from_bools(&[true])).unwrap();
        let payload = bytes::Bytes::from(vec![0xA5; request.length as usize]);
        task.handle_block(LeasedBlockEvent::uncharged_for_test(
            request.piece,
            request.begin,
            payload.clone(),
        ))
        .await;
        assert!(task.piece_assemblies.contains_key(&request.piece));

        assert!(matches!(
            task.run_recheck(None).await,
            RecheckOutcome::Complete
        ));
        let on_disk = std::fs::read(temp.path().join("recheck-partial.bin")).unwrap();
        assert_eq!(&on_disk[..request.length as usize], payload.as_ref());
    }

    #[tokio::test]
    async fn restored_partial_piece_writes_new_blocks_directly() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let piece_length = u64::from(MAX_BLOCK_SIZE) * 2;
        let first = vec![0x11; MAX_BLOCK_SIZE as usize];
        let second = vec![0x22; MAX_BLOCK_SIZE as usize];
        let mut piece_data = first.clone();
        piece_data.extend_from_slice(&second);
        let piece_hash: [u8; 20] = Sha1::digest(&piece_data).into();
        let meta = TorrentMetaV1 {
            info_hash: [22; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "restored-partial.bin".into(),
            piece_length,
            pieces: vec![piece_hash],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: piece_length,
                path: rt_path::SafeRelPath::from_name("restored-partial.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let file_path = temp.path().join("restored-partial.bin");
        let mut initial_data = first.clone();
        initial_data.extend(vec![0; second.len()]);
        std::fs::write(&file_path, initial_data).unwrap();
        let info_hash = hex::encode(meta.info_hash);
        let mut fastresume =
            FastresumeState::new_empty(&meta.info_hash, 1, ImportPolicy::RequireVerification);
        fastresume.clean_shutdown = true;
        fastresume.partial_pieces = vec![PartialPieceState {
            piece: 0,
            received_blocks: vec![0],
        }];
        fastresume.file_hints = collect_file_hints(temp.path(), &meta);
        FastresumeStore::new(temp.path().join("fastresume"))
            .save(&fastresume)
            .unwrap();

        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = piece_length;
        entry.amount_left = piece_length;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();

        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        assert!(task.restore_fastresume().await);
        assert!(task.restored_partial_pieces.contains(&0));
        assert!(!task.can_aggregate_piece_write(0));
        assert_eq!(task.transfer_ledger.piece_progress(0), Some((1, 2)));
        assert!(task.transfer_piece_memory_leases.contains_key(&0));

        task.picker.availability.add_have(0);
        let request = task.picker.pick(&PieceBitmap::from_bools(&[true])).unwrap();
        assert_eq!(request.begin, MAX_BLOCK_SIZE);
        task.handle_block(LeasedBlockEvent::uncharged_for_test(
            request.piece,
            request.begin,
            bytes::Bytes::from(second.clone()),
        ))
        .await;
        task.drain_transfer_jobs().await;

        assert!(task.picker.is_complete());
        assert!(task.transfer_ledger.has_piece(0));
        assert!(task.piece_assemblies.is_empty());
        assert!(!task.restored_partial_pieces.contains(&0));
        assert!(!task.transfer_piece_memory_leases.contains_key(&0));
        let on_disk = std::fs::read(file_path).unwrap();
        assert_eq!(&on_disk[..first.len()], first.as_slice());
        assert_eq!(&on_disk[first.len()..], second.as_slice());
    }

    #[test]
    fn piece_assembly_budget_evicts_oldest_incomplete_piece() {
        let now = Instant::now();
        let mut assemblies = HashMap::new();
        assemblies.insert(
            1,
            PieceAssembly {
                last_used: now - Duration::from_secs(30),
                ..PieceAssembly::new(4)
            },
        );
        assemblies.insert(
            2,
            PieceAssembly {
                last_used: now - Duration::from_secs(20),
                ..PieceAssembly::new(4)
            },
        );
        assemblies.insert(
            3,
            PieceAssembly {
                last_used: now,
                ..PieceAssembly::new(4)
            },
        );
        let mut bytes = 12;

        let evictions = evict_piece_assemblies_to_budget(&mut assemblies, &mut bytes, 3, 2, 12)
            .into_iter()
            .map(|(piece, _)| piece)
            .collect::<Vec<_>>();

        assert_eq!(evictions, vec![1]);
        assert_eq!(bytes, 8);
        assert!(!assemblies.contains_key(&1));
        assert!(assemblies.contains_key(&2));
        assert!(assemblies.contains_key(&3));
    }

    #[test]
    fn piece_assembly_budget_preserves_current_piece_when_possible() {
        let now = Instant::now();
        let mut assemblies = HashMap::new();
        assemblies.insert(
            1,
            PieceAssembly {
                last_used: now - Duration::from_secs(60),
                ..PieceAssembly::new(4)
            },
        );
        assemblies.insert(
            2,
            PieceAssembly {
                last_used: now - Duration::from_secs(30),
                ..PieceAssembly::new(4)
            },
        );
        assemblies.insert(
            3,
            PieceAssembly {
                last_used: now - Duration::from_secs(90),
                ..PieceAssembly::new(4)
            },
        );
        let mut bytes = 12;

        let evictions = evict_piece_assemblies_to_budget(&mut assemblies, &mut bytes, 3, 3, 8)
            .into_iter()
            .map(|(piece, _)| piece)
            .collect::<Vec<_>>();

        assert_eq!(evictions, vec![1]);
        assert_eq!(bytes, 8);
        assert!(!assemblies.contains_key(&1));
        assert!(assemblies.contains_key(&2));
        assert!(assemblies.contains_key(&3));
    }

    #[test]
    fn piece_assembly_budget_stops_at_current_piece_only() {
        let mut assemblies = HashMap::new();
        assemblies.insert(7, PieceAssembly::new(16));
        let mut bytes = 16;

        let evictions = evict_piece_assemblies_to_budget(&mut assemblies, &mut bytes, 7, 0, 0)
            .into_iter()
            .map(|(piece, _)| piece)
            .collect::<Vec<_>>();

        assert!(evictions.is_empty());
        assert_eq!(bytes, 16);
        assert!(assemblies.contains_key(&7));
    }

    #[test]
    fn configured_piece_assembly_cap_is_per_torrent_soft_ceiling() {
        assert_eq!(
            effective_piece_assembly_soft_cap(8 * 1024 * 1024),
            8 * 1024 * 1024
        );
        assert_eq!(
            effective_piece_assembly_soft_cap(512 * 1024 * 1024),
            MAX_IN_MEMORY_PIECE_ASSEMBLY_BYTES_PER_TORRENT
        );
    }

    #[test]
    fn request_pipeline_reduces_near_piece_assembly_cap() {
        assert_eq!(
            memory_aware_request_pipeline(0, 1024),
            PEER_REQUEST_PIPELINE_NORMAL
        );
        assert_eq!(
            memory_aware_request_pipeline(767, 1024),
            PEER_REQUEST_PIPELINE_NORMAL
        );
        assert_eq!(
            memory_aware_request_pipeline(768, 1024),
            PEER_REQUEST_PIPELINE_CONSTRAINED
        );
        assert_eq!(
            memory_aware_request_pipeline(1, 0),
            PEER_REQUEST_PIPELINE_NORMAL
        );
    }

    #[test]
    fn tracker_peer_cache_cap_scales_with_peer_limit() {
        assert_eq!(tracker_peer_cache_cap(1), TRACKER_PEER_CACHE_MIN);
        assert_eq!(tracker_peer_cache_cap(100), 400);
        assert_eq!(tracker_peer_cache_cap(usize::MAX), MAX_TRACKER_PEERS);
    }

    #[test]
    fn tracker_peer_cache_reservation_is_owned_until_cache_drop() {
        let capacity = tracker_peer_cache_cap(1);
        let bytes = capacity as u64 * TRACKER_PEER_CACHE_BYTES_PER_ENTRY;
        let mut caps = [0; rt_metrics::MEMORY_CLASS_COUNT];
        caps[MemoryClass::TrackerPeers as usize] = bytes;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: bytes,
            class_caps_bytes: caps,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });

        let (cache, lease) = prepare_tracker_peer_cache(&governor, 1);
        assert!(cache.capacity() >= capacity);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::TrackerPeers as usize].used_bytes,
            bytes
        );
        drop(cache);
        drop(lease);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::TrackerPeers as usize].used_bytes,
            0
        );
    }

    #[test]
    fn webseed_body_reservation_uses_webseed_governor_class() {
        let mut caps = [0; rt_metrics::MEMORY_CLASS_COUNT];
        caps[MemoryClass::WebseedBody as usize] = 16;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: 16,
            class_caps_bytes: caps,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });

        let lease = reserve_webseed_body_bytes(&governor, 16).unwrap();
        assert_eq!(
            governor.snapshot().classes[MemoryClass::WebseedBody as usize].used_bytes,
            16
        );
        drop(lease);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::WebseedBody as usize].used_bytes,
            0
        );
        assert!(reserve_webseed_body_bytes(&governor, 17).is_err());
        assert_eq!(
            governor.snapshot().classes[MemoryClass::WebseedBody as usize].denied_allocations,
            1
        );
    }

    #[tokio::test]
    async fn webseed_block_is_debited_from_the_local_download_bucket() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let temp = tempfile::tempdir().unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let webseed_addr = listener.local_addr().unwrap();
        let server = tokio::spawn(async move {
            let (mut stream, _) = listener.accept().await.unwrap();
            let mut request = Vec::new();
            let mut buffer = [0_u8; 1024];
            while !request.windows(4).any(|window| window == b"\r\n\r\n") {
                let read = stream.read(&mut buffer).await.unwrap();
                if read == 0 {
                    return;
                }
                request.extend_from_slice(&buffer[..read]);
            }
            stream
                .write_all(b"HTTP/1.1 206 Partial Content\r\nContent-Length: 4\r\nContent-Range: bytes 0-3/4\r\nConnection: close\r\n\r\ndata")
                .await
                .unwrap();
            stream.shutdown().await.unwrap();
        });

        let meta = TorrentMetaV1 {
            info_hash: [27; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: vec![format!("http://{webseed_addr}/payload.bin")],
            comment: None,
            created_by: None,
            creation_date: None,
            name: "payload.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("payload.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(4);
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let observed_resources = resources.clone();
        let budget = GlobalNetworkBudget::unlimited();
        // No peer slots are configured; the serial webseed still needs its
        // one transient ledger slot to reserve and reconcile this block.
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            resources,
            cmd_rx,
            temp.path().join("fastresume"),
            0,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy {
                allow_loopback: true,
                ..OutboundEgressPolicy::default()
            },
            budget,
            10_000,
            None,
        )
        .await;
        task.set_torrent_download_limit(Some(1));

        let abandoned_request = task
            .picker
            .pick_from_seed()
            .expect("fixture should expose a webseed block");
        let abandoned_conn = task
            .reserve_webseed_block(abandoned_request)
            .expect("webseed reservation should enter the transfer ledger");
        assert_eq!(task.transfer_ledger.in_flight(), 1);
        task.release_webseed_block(abandoned_conn, abandoned_request);
        task.close_webseed_transfer_connection();
        assert_eq!(task.transfer_ledger.in_flight(), 0);
        assert_eq!(task.transfer_ledger.piece_progress(0), None);
        assert!(!task.transfer_piece_memory_leases.contains_key(&0));

        let event = timeout(Duration::from_secs(5), task.download_next_webseed_block())
            .await
            .expect("webseed fetch should finish")
            .expect("webseed block should be delivered");
        assert_eq!(event.block.data.as_ref(), b"data");
        assert_eq!(event.network_bytes, Some(4));
        let transfer_conn = task
            .webseed_transfer_conn
            .expect("webseed work should register a ledger connection");
        let block = BlockExtent::new(0, 0, 4);
        assert_eq!(task.transfer_ledger.outstanding(transfer_conn), 1);
        assert!(matches!(
            task.transfer_ledger.on_block(transfer_conn, block),
            ReceiveOutcome::Accepted { .. }
        ));
        task.close_webseed_transfer_connection();
        assert!(!task.transfer_ledger.is_live(transfer_conn));
        assert_eq!(task.transfer_ledger.in_flight(), 0);
        assert_eq!(task.transfer_ledger.piece_progress(0), Some((1, 1)));
        assert_eq!(
            observed_resources.snapshot().classes[MemoryClass::WebseedBody as usize].used_bytes,
            4,
            "the body reservation must remain live after fetch returns"
        );
        let rate_peer = TransferPeerId::new(task.transfer_rate_torrent, transfer_conn);
        assert!(
            task.network_budget
                .download_available_credit_bytes_for(rate_peer)
                < 16 * 1024,
            "the fetched webseed block must consume the shared torrent rate credit"
        );
        drop(event);
        assert_eq!(
            observed_resources.snapshot().classes[MemoryClass::WebseedBody as usize].used_bytes,
            0,
            "dropping the block event releases its body reservation"
        );
        server.await.unwrap();
    }

    #[tokio::test]
    async fn webseed_fetch_runs_alongside_active_peers_and_keeps_actor_responsive() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let temp = tempfile::tempdir().unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let webseed_addr = listener.local_addr().unwrap();
        let (request_started_tx, request_started_rx) = oneshot::channel();
        let (release_response_tx, release_response_rx) = oneshot::channel();
        let server = tokio::spawn(async move {
            let (mut stream, _) = listener.accept().await.unwrap();
            let mut request = Vec::new();
            let mut buffer = [0_u8; 1024];
            while !request.windows(4).any(|window| window == b"\r\n\r\n") {
                let read = stream.read(&mut buffer).await.unwrap();
                if read == 0 {
                    return;
                }
                request.extend_from_slice(&buffer[..read]);
            }
            let _ = stream
                .write_all(b"HTTP/1.1 206 Partial Content\r\nContent-Length: 4\r\nContent-Range: bytes 0-3/4\r\nConnection: close\r\n\r\n")
                .await;
            let _ = request_started_tx.send(());
            if release_response_rx.await.is_err() {
                return;
            }
            let _ = stream.write_all(b"data").await;
            let _ = stream.shutdown().await;
        });

        let meta = TorrentMetaV1 {
            info_hash: [25; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: vec![format!("http://{webseed_addr}/payload.bin")],
            comment: None,
            created_by: None,
            creation_date: None,
            name: "payload.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("payload.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(4);
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let budget = GlobalNetworkBudget::unlimited();
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            resources,
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy {
                allow_loopback: true,
                ..OutboundEgressPolicy::default()
            },
            budget,
            10_000,
            None,
        )
        .await;
        let peer_slots = Arc::new(tokio::sync::Semaphore::new(1));
        let peer_permit = Arc::clone(&peer_slots).acquire_owned().await.unwrap();
        let (_peer_id, _peer_commands) = task
            .register_peer("127.0.0.1:6882".parse().unwrap(), peer_permit)
            .expect("a test peer should occupy one active slot");
        assert!(!task.active_peers.is_empty());
        let actor = tokio::spawn(task.run());

        timeout(Duration::from_secs(2), request_started_rx)
            .await
            .expect("webseed request did not start")
            .expect("webseed test server dropped before the request");
        let (reply, result) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::GetWebseeds { reply })
            .await
            .unwrap();
        let snapshots = timeout(Duration::from_secs(1), result)
            .await
            .expect("torrent actor should answer while the HTTP body is held")
            .unwrap();
        assert_eq!(snapshots.len(), 1);
        assert!(!snapshots[0].is_downloading);

        let (reply, result) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::Pause { reply: Some(reply) })
            .await
            .unwrap();
        assert_eq!(
            timeout(Duration::from_secs(1), result)
                .await
                .expect("pause should complete after the fetch")
                .unwrap(),
            Ok(())
        );
        release_response_tx.send(()).unwrap();
        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(1), actor)
            .await
            .expect("torrent actor should shut down")
            .unwrap();
        server.await.unwrap();
        assert!(
            !temp.path().join("payload.bin").exists(),
            "a response released after pause must not reach storage"
        );
    }

    #[tokio::test]
    async fn webseed_rate_wait_does_not_block_lifecycle_commands() {
        let temp = tempfile::tempdir().unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let webseed_addr = listener.local_addr().unwrap();

        let meta = TorrentMetaV1 {
            info_hash: [26; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: vec![format!("http://{webseed_addr}/payload.bin")],
            comment: None,
            created_by: None,
            creation_date: None,
            name: "payload.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("payload.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(4);
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let budget = GlobalNetworkBudget::new(8, Some(1), None);
        // Put the process download bucket into debt. The four-byte webseed
        // remains in rate admission, before opening its HTTP connection.
        let drain_torrent = budget.new_transfer_torrent_key();
        budget.register_download_torrent(drain_torrent, None);
        let drain_peer = TransferPeerId::new(
            drain_torrent,
            ConnectionId {
                slot: u32::MAX,
                generation: 1,
            },
        );
        budget.register_transfer_peer(drain_peer);
        let drain_control = RateLimitCancellation::default();
        let drain_grant = budget
            .acquire_download(
                drain_peer,
                64 * 1024,
                &drain_control,
                drain_control.generation(),
            )
            .await
            .unwrap()
            .unwrap();
        drain_grant.settle(64 * 1024);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            resources,
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy {
                allow_loopback: true,
                ..OutboundEgressPolicy::default()
            },
            budget,
            10_000,
            None,
        )
        .await;
        assert!(
            task.start_webseed_block(),
            "the webseed must enter rate admission"
        );
        let task = tokio::spawn(task.run());

        let (webseed_reply, webseed_result) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::GetWebseeds {
                reply: webseed_reply,
            })
            .await
            .unwrap();
        let snapshots = timeout(Duration::from_secs(1), webseed_result)
            .await
            .expect("webseed snapshot query should complete during rate wait")
            .unwrap();
        assert_eq!(snapshots.len(), 1);

        let (pause_reply, pause_result) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::Pause {
                reply: Some(pause_reply),
            })
            .await
            .unwrap();
        assert_eq!(
            timeout(Duration::from_secs(1), pause_result)
                .await
                .expect("pause should interrupt the global download wait")
                .unwrap(),
            Ok(())
        );
        assert!(
            timeout(Duration::from_millis(50), listener.accept())
                .await
                .is_err(),
            "a rate-blocked webseed must not open its HTTP connection"
        );

        let (webseed_reply, webseed_result) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::GetWebseeds {
                reply: webseed_reply,
            })
            .await
            .unwrap();
        let snapshots = timeout(Duration::from_secs(1), webseed_result)
            .await
            .expect("webseed snapshot query should complete after pause")
            .unwrap();
        assert_eq!(snapshots.len(), 1);
        assert!(!snapshots[0].is_downloading);
        assert_eq!(snapshots[0].download_rate, 0);

        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(1), task)
            .await
            .expect("webseed rate wait should not strand shutdown")
            .unwrap();
    }

    #[tokio::test]
    async fn live_pause_does_not_block_shutdown_on_slow_stopped_announce() {
        use tokio::io::AsyncReadExt;

        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let tracker_addr = listener.local_addr().unwrap();
        let (tracker_request_tx, mut tracker_request_rx) = mpsc::unbounded_channel();
        let tracker = tokio::spawn(async move {
            loop {
                let Ok((mut stream, _)) = listener.accept().await else {
                    break;
                };
                let request_tx = tracker_request_tx.clone();
                tokio::spawn(async move {
                    let mut request = Vec::new();
                    let mut buffer = [0_u8; 1024];
                    while !request.windows(4).any(|window| window == b"\r\n\r\n") {
                        let read = stream.read(&mut buffer).await.unwrap();
                        if read == 0 {
                            return;
                        }
                        request.extend_from_slice(&buffer[..read]);
                    }
                    let stopped = request
                        .windows(b"event=stopped".len())
                        .any(|window| window == b"event=stopped");
                    let _ = request_tx.send(stopped);
                    tokio::time::sleep(Duration::from_secs(30)).await;
                });
            }
        });

        let temp = tempfile::tempdir().unwrap();
        let tracker_url = format!("http://{tracker_addr}/announce");
        let meta = TorrentMetaV1 {
            info_hash: [27; 20],
            announce: Some(tracker_url),
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "slow-stop.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("slow-stop.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        let mut fastresume = FastresumeState::new_empty(
            &meta.info_hash,
            meta.pieces.len() as u32,
            ImportPolicy::RequireVerification,
        );
        fastresume.clean_shutdown = true;
        FastresumeStore::new(temp.path().join("fastresume"))
            .save(&fastresume)
            .unwrap();

        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (cmd_tx, cmd_rx) = mpsc::channel(4);
        let task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            30,
            1,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy {
                allow_loopback: true,
                ..OutboundEgressPolicy::default()
            },
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        let actor = tokio::spawn(task.run());

        timeout(Duration::from_secs(2), async {
            loop {
                let state = db
                    .lock()
                    .unwrap()
                    .query_row(
                        "SELECT state FROM torrents WHERE info_hash = ?1",
                        [&info_hash],
                        |row| row.get::<_, String>(0),
                    )
                    .ok();
                if state.as_deref() == Some(TorrentState::Downloading.as_str()) {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("live torrent did not reach its active state");

        let (pause_reply, pause_result) = oneshot::channel();
        cmd_tx
            .send(TorrentCmd::Pause {
                reply: Some(pause_reply),
            })
            .await
            .unwrap();
        assert_eq!(
            timeout(Duration::from_secs(1), pause_result)
                .await
                .expect("pause reply should be durable before stopped announce")
                .unwrap(),
            Ok(())
        );
        timeout(Duration::from_secs(1), async {
            loop {
                match tracker_request_rx.recv().await {
                    Some(true) => break,
                    Some(false) => {}
                    None => panic!("tracker test server dropped before stopped announce"),
                }
            }
        })
        .await
        .expect("stopped tracker announce did not start");

        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(1), async {
            loop {
                match tracker_request_rx.recv().await {
                    Some(true) => break,
                    Some(false) => {}
                    None => panic!("tracker test server dropped before shutdown announce"),
                }
            }
        })
        .await
        .expect("shutdown did not retry the interrupted stopped announce");
        timeout(Duration::from_secs(2), actor)
            .await
            .expect("shutdown should interrupt the live stopped tracker announce")
            .unwrap();
        tracker.abort();
        let _ = tracker.await;
    }

    #[test]
    fn tracker_peer_cache_drops_new_peers_after_cap() {
        let peers = [
            SocketAddr::from(([127, 0, 0, 1], 6881)),
            SocketAddr::from(([127, 0, 0, 2], 6881)),
            SocketAddr::from(([127, 0, 0, 3], 6881)),
        ];
        let mut known = HashSet::new();

        let dropped = remember_tracker_peers_bounded(&mut known, &peers, 2);

        assert_eq!(known.len(), 2);
        assert_eq!(dropped, 1);

        let duplicate = *known.iter().next().unwrap();
        let dropped = remember_tracker_peers_bounded(&mut known, &[duplicate], 2);

        assert_eq!(known.len(), 2);
        assert_eq!(dropped, 0);
    }

    #[test]
    fn tracker_tiers_preserve_bep12_order_and_dedupe() {
        let meta = TorrentMetaV1 {
            info_hash: [1; 20],
            announce: Some("http://tracker-a/announce".into()),
            announce_list: vec![
                vec![
                    "http://tracker-a/announce".into(),
                    "http://tracker-b/announce".into(),
                ],
                vec!["udp://tracker-c:6969/announce".into()],
            ],
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "sample.bin".into(),
            piece_length: 16_384,
            pieces: vec![[2; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 5,
                path: rt_path::SafeRelPath::from_name("sample.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: true,
            raw: Vec::new(),
        };

        let tiers = tracker_tiers_from_meta(&meta);

        assert_eq!(tiers.len(), 2);
        assert_eq!(tiers[0].len(), 2);
        assert_eq!(tiers[0][0].url, "http://tracker-a/announce");
        assert_eq!(tiers[0][1].url, "http://tracker-b/announce");
        assert_eq!(tiers[1][0].url, "udp://tracker-c:6969/announce");
    }

    #[test]
    fn tracker_status_persistence_fields_are_stable() {
        assert_eq!(
            tracker_status_label(&TrackerStatus::NeverAnnounced),
            "never_announced"
        );
        assert_eq!(tracker_status_label(&TrackerStatus::Working), "working");

        let warning = TrackerStatus::Warning("tracker says slow down".to_owned());
        assert_eq!(tracker_status_label(&warning), "warning");
        assert_eq!(
            tracker_warning_message(&warning).as_deref(),
            Some("tracker says slow down")
        );

        let failure = TrackerStatus::Error(TrackerError::Timeout);
        assert_eq!(tracker_status_label(&failure), "error");
        assert_eq!(
            tracker_failure_reason(&failure).as_deref(),
            Some("announce timed out")
        );
    }

    #[test]
    fn tracker_lifecycle_events_clear_after_one_success() {
        assert_eq!(
            tracker_event_after_success(TrackerEvent::Started, TrackerEvent::Started),
            TrackerEvent::Empty
        );
        assert_eq!(
            tracker_event_after_success(TrackerEvent::Completed, TrackerEvent::Completed),
            TrackerEvent::Empty
        );
        assert_eq!(
            tracker_event_after_success(TrackerEvent::Empty, TrackerEvent::Empty),
            TrackerEvent::Empty
        );
    }

    #[test]
    fn tracker_success_does_not_clear_a_newer_lifecycle_event() {
        assert_eq!(
            tracker_event_after_success(TrackerEvent::Completed, TrackerEvent::Started),
            TrackerEvent::Completed
        );
        assert_eq!(
            tracker_event_after_success(TrackerEvent::Started, TrackerEvent::Completed),
            TrackerEvent::Started
        );
    }

    #[test]
    fn incomplete_recheck_discards_stale_terminal_tracker_events() {
        assert_eq!(
            tracker_event_after_incomplete_recheck(TrackerEvent::Started),
            TrackerEvent::Started
        );
        assert_eq!(
            tracker_event_after_incomplete_recheck(TrackerEvent::Empty),
            TrackerEvent::Empty
        );
        assert_eq!(
            tracker_event_after_incomplete_recheck(TrackerEvent::Completed),
            TrackerEvent::Empty
        );
        assert_eq!(
            tracker_event_after_incomplete_recheck(TrackerEvent::Stopped),
            TrackerEvent::Empty
        );
    }

    #[tokio::test]
    async fn restarting_tracker_session_schedules_a_new_started_event_immediately() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [25; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "tracker-session.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("tracker-session.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            registry,
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let tracker_urls = vec![
            "http://tracker-a/announce".to_owned(),
            "http://tracker-b/announce".to_owned(),
        ];
        task.tracker_tiers = tracker_tiers_from_urls(&tracker_urls);
        for tracker in task.tracker_tiers.iter_mut().flatten() {
            tracker.next_announce = Some(Instant::now() + Duration::from_secs(3600));
        }
        task.tracker_event = TrackerEvent::Completed;
        task.stopped_announced = true;

        task.restart_tracker_session();

        assert_eq!(task.tracker_event, TrackerEvent::Started);
        assert!(!task.stopped_announced);
        assert!(task
            .tracker_tiers
            .iter()
            .flatten()
            .all(|tracker| tracker.is_due()));
    }

    #[test]
    fn stopped_announce_is_consumed_once_per_session() {
        let mut stopped_announced = false;

        assert!(consume_stopped_announce(&mut stopped_announced));
        assert!(!consume_stopped_announce(&mut stopped_announced));

        stopped_announced = false;
        assert!(consume_stopped_announce(&mut stopped_announced));
    }

    #[test]
    fn private_peer_allowlist_only_accepts_tracker_peers() {
        let peer: SocketAddr = "127.0.0.1:6881".parse().unwrap();
        let same_host_ephemeral: SocketAddr = "127.0.0.1:49152".parse().unwrap();
        let other: SocketAddr = "127.0.0.2:6881".parse().unwrap();
        let public_peer: SocketAddr = "198.51.100.10:6881".parse().unwrap();
        let public_same_host_ephemeral: SocketAddr = "198.51.100.10:49152".parse().unwrap();
        let benchmark_peer: SocketAddr = "198.18.4.2:51413".parse().unwrap();
        let benchmark_same_host_ephemeral: SocketAddr = "198.18.4.2:49152".parse().unwrap();
        let benchmark_other_host: SocketAddr = "198.18.4.3:49152".parse().unwrap();
        let outside_benchmark_range: SocketAddr = "198.20.4.2:49152".parse().unwrap();
        let mut allowed = HashSet::new();

        assert!(!private_peer_source_allowed(true, &allowed, peer));
        allowed.insert(peer);
        assert!(private_peer_source_allowed(true, &allowed, peer));
        assert!(private_peer_source_allowed(
            true,
            &allowed,
            same_host_ephemeral
        ));
        assert!(!private_peer_source_allowed(true, &allowed, other));
        assert!(private_peer_source_allowed(false, &allowed, other));

        allowed.insert(public_peer);
        assert!(!private_peer_source_allowed(
            true,
            &allowed,
            public_same_host_ephemeral
        ));

        allowed.insert(benchmark_peer);
        assert!(private_peer_source_allowed(
            true,
            &allowed,
            benchmark_same_host_ephemeral
        ));
        assert!(!private_peer_source_allowed(
            true,
            &allowed,
            benchmark_other_host
        ));
        assert!(!private_peer_source_allowed(
            true,
            &allowed,
            outside_benchmark_range
        ));
    }

    #[tokio::test]
    async fn private_tracker_failover_disconnects_old_peers_and_clears_allowlist() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [26; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "private-failover.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: SafeRelPath::from_name("private-failover.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: true,
            raw: Vec::new(),
        };
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        task.tracker_tiers = vec![vec![
            TrackerState::new("https://a.example/announce"),
            TrackerState::new("https://b.example/announce"),
        ]];
        task.private_tracker_key = Some((0, 0));

        let peer: SocketAddr = "127.0.0.1:6881".parse().unwrap();
        let permits = Arc::new(tokio::sync::Semaphore::new(1));
        let (_peer_id, _peer_cmd_rx) = task
            .register_peer(peer, permits.acquire_owned().await.unwrap())
            .expect("peer registration should fit the memory budget");
        task.known_tracker_peers.insert(peer);

        task.advance_private_tracker_after_failure((0, 0)).await;

        assert_eq!(task.private_tracker_key, Some((0, 1)));
        assert!(task.active_peers.is_empty());
        assert!(task.known_tracker_peers.is_empty());
        assert!(task.tracker_tiers[0][1].is_due());
    }

    #[tokio::test]
    async fn torrent_upload_limit_is_one_bucket_shared_by_all_peers() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [26; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "shared-upload.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: SafeRelPath::from_name("shared-upload.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let mut entry = rt_session::TorrentEntry::new(
            hex::encode(meta.info_hash),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        let db = Arc::new(Mutex::new(conn));
        rt_db::upsert_torrent_limits(
            &db.lock().unwrap(),
            &rt_db::TorrentLimitRow {
                info_hash: hex::encode(meta.info_hash),
                download_limit: Some(200_000),
                upload_limit: Some(200_000),
                max_connections: None,
                seed_ratio_limit: None,
                seed_idle_limit: None,
                sequential_download: false,
                sequential_download_from_piece: None,
                first_last_piece_prio: false,
                force_start: false,
                super_seeding: false,
                auto_tmm: false,
                auto_management: false,
            },
        )
        .unwrap();
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let permits = Arc::new(tokio::sync::Semaphore::new(2));
        let mut contexts = Vec::new();
        let mut _rxs = Vec::new();
        for port in [6881, 6882] {
            let peer: SocketAddr = format!("127.0.0.1:{port}").parse().unwrap();
            let (_id, rx) = task
                .register_peer(peer, permits.clone().acquire_owned().await.unwrap())
                .expect("peer registration should fit the memory budget");
            _rxs.push(rx);
            contexts.push(task.upload_context(peer).expect("registered peer"));
        }

        // Both generation-safe peer identities draw on one torrent node, so
        // only the first grant can pass while the configured bucket is in debt.
        let control = RateLimitCancellation::default();
        let generation = control.generation();
        let first = task
            .network_budget
            .acquire_upload(contexts[0].upload_rate.peer, 200_000, &control, generation)
            .await
            .unwrap()
            .expect("first peer should receive the torrent's startup burst");
        first.settle(200_000);
        let second_budget = task.network_budget.clone();
        let second_peer = contexts[1].upload_rate.peer;
        let second_control = control.clone();
        let second = tokio::spawn(async move {
            second_budget
                .acquire_upload(second_peer, 1, &second_control, generation)
                .await
        });
        tokio::task::yield_now().await;
        assert!(!second.is_finished());
        // Removing the torrent cap wakes the parked peer immediately.
        task.set_torrent_upload_limit(None);
        second.await.unwrap().unwrap().unwrap().settle(1);
    }

    #[tokio::test]
    async fn drained_download_rate_tree_schedules_retry_deadline() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [26; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "paced.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: SafeRelPath::from_name("paced.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let mut entry = rt_session::TorrentEntry::new(
            hex::encode(meta.info_hash),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        let db = Arc::new(Mutex::new(conn));
        rt_db::upsert_torrent_limits(
            &db.lock().unwrap(),
            &rt_db::TorrentLimitRow {
                info_hash: hex::encode(meta.info_hash),
                download_limit: Some(2),
                upload_limit: None,
                max_connections: None,
                seed_ratio_limit: None,
                seed_idle_limit: None,
                sequential_download: false,
                sequential_download_from_piece: None,
                first_last_piece_prio: false,
                force_start: false,
                super_seeding: false,
                auto_tmm: false,
                auto_management: false,
            },
        )
        .unwrap();
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let peer: SocketAddr = "127.0.0.1:6881".parse().unwrap();
        let permits = Arc::new(tokio::sync::Semaphore::new(1));
        let (_id, mut cmd_rx) = task
            .register_peer(peer, permits.acquire_owned().await.unwrap())
            .expect("peer registration should fit the memory budget");
        {
            let handle = task.active_peers.get_mut(&peer).unwrap();
            handle.choked = false;
            handle.add_peer_have(0);
        }
        task.picker.availability.add_bitfield(&[0x80]);

        // Drain the 16 KiB startup burst four bytes into debt. At 2 B/s the
        // request scheduler should retry when those four debt bytes refill.
        let transfer_conn = task.active_peers.get(&peer).unwrap().transfer_conn;
        let rate_peer = TransferPeerId::new(task.transfer_rate_torrent, transfer_conn);
        let control = RateLimitCancellation::default();
        let drain_bytes = 16 * 1024 + 4;
        task.network_budget
            .acquire_download(rate_peer, drain_bytes, &control, control.generation())
            .await
            .unwrap()
            .unwrap()
            .settle(drain_bytes);
        task.refill_peer_requests(peer).await;
        assert!(
            cmd_rx.try_recv().is_err(),
            "rate debt should defer the request"
        );
        let wake = task
            .download_rate_wake
            .expect("a rate-ready retry deadline must be scheduled");
        let wait = wake.saturating_duration_since(Instant::now());
        assert!(
            wait > Duration::from_millis(1500) && wait <= Duration::from_secs(2),
            "4 bytes at 2 B/s is ~2 s away, got {wait:?}"
        );

        // Removing the rate clears the stale two-second deadline and
        // immediately retries the active peer with the unlimited budget.
        task.apply_torrent_limits(&EngineTorrentLimits::default())
            .await
            .unwrap();
        let request_command = cmd_rx.try_recv().expect("request should be queued");
        let PeerCommand::Request {
            request,
            memory_lease,
            ..
        } = request_command
        else {
            panic!("expected a download request command");
        };
        assert_eq!(memory_lease.bytes(), u64::from(request.length));
        assert!(task.download_rate_wake.is_none());
    }

    #[tokio::test(start_paused = true)]
    async fn stale_rate_waiter_retires_after_another_peer_consumes_its_only_piece() {
        let fx = crash_fixture(vec![7; 4], 4, 206).await;
        rt_db::upsert_torrent_limits(
            &fx.db.lock().unwrap(),
            &rt_db::TorrentLimitRow {
                info_hash: fx.info_hash.clone(),
                download_limit: Some(32 * 1024 * 1024),
                upload_limit: None,
                max_connections: None,
                seed_ratio_limit: None,
                seed_idle_limit: None,
                sequential_download: false,
                sequential_download_from_piece: None,
                first_last_piece_prio: false,
                force_start: false,
                super_seeding: false,
                auto_tmm: false,
                auto_management: false,
            },
        )
        .unwrap();
        let (mut task, _cmd_tx) =
            crash_task_with_mailbox(&fx, quiet_runtime(), StorageIoConfig::default()).await;

        let permits = Arc::new(tokio::sync::Semaphore::new(2));
        let parked_addr: SocketAddr = "127.0.0.1:6881".parse().unwrap();
        let active_addr: SocketAddr = "127.0.0.1:6882".parse().unwrap();
        for peer in [parked_addr, active_addr] {
            task.register_peer(peer, permits.clone().acquire_owned().await.unwrap())
                .expect("peer registration should fit the memory budget");
            if task.active_peers.get_mut(&peer).unwrap().add_peer_have(0) {
                task.picker.availability.add_have(0);
            }
            task.active_peers.get_mut(&peer).unwrap().choked = false;
        }

        let active_conn = task.active_peers[&active_addr].transfer_conn;
        let active_rate_peer = TransferPeerId::new(task.transfer_rate_torrent, active_conn);
        while let RateAdmissionAttempt::Granted(grant) = task
            .network_budget
            .try_acquire_download(active_rate_peer, 16 * 1024)
            .unwrap()
        {
            grant.settle(16 * 1024);
        }

        task.refill_peer_requests(parked_addr).await;
        assert!(
            task.rate_waiting_peers.contains(&parked_addr),
            "the denied peer must be recorded as a live rate waiter"
        );
        assert_eq!(task.active_peers.len(), 2);

        let completed = task.picker.pick_from_seed().expect("one available piece");
        assert!(task
            .picker
            .block_received_pending(completed.piece as usize, completed.begin));
        task.network_budget
            .set_download_torrent_limit(task.transfer_rate_torrent, None);
        task.network_budget.set_download_limit(None);
        assert!(matches!(
            task.network_budget
                .try_acquire_download(active_rate_peer, 1)
                .unwrap(),
            RateAdmissionAttempt::Wait(_) | RateAdmissionAttempt::WaitForChange
        ));

        task.retry_rate_waiting_peers().await;
        assert!(!task.rate_waiting_peers.contains(&parked_addr));
        assert_eq!(task.active_peers.len(), 2, "neither live peer is removed");
        assert!(matches!(
            task.network_budget
                .try_acquire_download(active_rate_peer, 1)
                .unwrap(),
            RateAdmissionAttempt::Granted(_)
        ));
    }

    #[tokio::test]
    async fn peer_request_admission_retries_after_payload_capacity_returns() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [27; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "admission.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: SafeRelPath::from_name("admission.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let peer_state_bytes = PieceBitmap::memory_bytes_for_len(1)
            .saturating_mul(2)
            .saturating_add(u64::try_from(std::mem::size_of::<usize>()).unwrap_or(u64::MAX))
            .saturating_add(
                u64::try_from(TransferLedger::<Arc<PieceMap>>::estimated_connection_state_bytes())
                    .unwrap_or(u64::MAX),
            );
        let ledger_piece_bytes =
            TransferLedger::<Arc<PieceMap>>::estimated_piece_state_bytes_for_block_count(1);
        let mut resource_config = rt_metrics::ResourceGovernorConfig::default();
        resource_config.class_caps_bytes[MemoryClass::PeerBuffer as usize] = peer_state_bytes
            .saturating_add(u64::try_from(ledger_piece_bytes).unwrap_or(u64::MAX))
            .saturating_add(4);
        let resources = ResourceGovernor::new(resource_config);
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            resources.clone(),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let peer: SocketAddr = "127.0.0.1:6881".parse().unwrap();
        let permits = Arc::new(tokio::sync::Semaphore::new(1));
        let (_id, mut peer_commands) = task
            .register_peer(peer, permits.acquire_owned().await.unwrap())
            .expect("peer registration should fit the memory budget");
        {
            let handle = task.active_peers.get_mut(&peer).unwrap();
            handle.choked = false;
            handle.add_peer_have(0);
        }
        task.picker.availability.add_bitfield(&[0x80]);

        // The peer maps and one ledger piece fit, but this blocker leaves no
        // room for the 4-byte response until capacity returns.
        let blocker = resources
            .try_acquire(
                MemoryClass::PeerBuffer,
                u64::try_from(ledger_piece_bytes.saturating_add(4)).unwrap(),
            )
            .expect("test blocker should consume the remaining capacity");
        task.refill_peer_requests(peer).await;
        assert!(peer_commands.try_recv().is_err());
        assert!(task.peer_request_memory_retry_pending);
        assert_eq!(task.active_peers[&peer].outstanding, 0);
        assert!(task.active_peers[&peer].requested.is_empty());

        drop(blocker);
        task.retry_memory_denied_peer_requests().await;
        let PeerCommand::Request {
            request,
            memory_lease,
            ..
        } = peer_commands
            .try_recv()
            .expect("returned capacity should admit the request")
        else {
            panic!("expected a peer request");
        };
        assert_eq!(request.length, 4);
        assert_eq!(memory_lease.bytes(), 4);
        assert!(!task.peer_request_memory_retry_pending);
    }

    #[tokio::test]
    async fn fast_peer_request_while_choked_is_rejected_not_dropped() {
        let temp = tempfile::tempdir().unwrap();
        let payload = vec![7u8; MAX_BLOCK_SIZE as usize];
        std::fs::write(temp.path().join("peer.bin"), &payload).unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();

        let piece_map = Arc::new(
            PieceMap::new(
                u64::from(MAX_BLOCK_SIZE),
                vec![FileSpan {
                    file_index: 0,
                    path: rt_path::SafeRelPath::from_name("peer.bin", false).unwrap(),
                    content_offset: 0,
                    length: u64::from(MAX_BLOCK_SIZE),
                }],
            )
            .unwrap(),
        );
        let control = RateLimitCancellation::default();
        let shutdown_control = RateLimitCancellation::default();
        let upload = UploadContext {
            save_root: temp.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                temp.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            have_pieces: PieceBitmap::from_bools(&[true]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: true,
            fast_negotiated: true,
            upload_control: control.clone(),
            shutdown_control: shutdown_control.clone(),
            upload_rate: test_upload_rate_admission(Some(1), 32 * 1024).await,
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };
        let (peer_event_tx, peer_event_rx) = mpsc::channel(4);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(4);
        let loop_task = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            true,
        ));
        let mut remote = Framed::new(remote, PeerCodec::default());

        // We never unchoked this peer. Under BEP 6 its request must be
        // answered with Reject Request rather than silently ignored.
        remote
            .send(Message::Request {
                piece: 0,
                begin: 0,
                length: MAX_BLOCK_SIZE,
            })
            .await
            .unwrap();
        let reply = timeout(Duration::from_secs(2), remote.next())
            .await
            .expect("a Fast peer must get an answer to its request")
            .unwrap()
            .unwrap();
        assert!(matches!(
            reply,
            Message::Reject {
                piece: 0,
                begin: 0,
                length: MAX_BLOCK_SIZE
            }
        ));

        control.cancel();
        shutdown_control.cancel();
        peer_cmd_tx.send(PeerCommand::Shutdown).await.unwrap();
        let exit = timeout(Duration::from_secs(1), loop_task)
            .await
            .expect("shutdown should end the peer loop")
            .unwrap();
        assert!(exit.result.is_ok());
        drop(peer_event_rx);
    }

    #[tokio::test]
    async fn evicted_piece_assembly_is_spilled_to_disk_not_discarded() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let piece_length = u64::from(MAX_BLOCK_SIZE) * 2;
        let meta = TorrentMetaV1 {
            info_hash: [25; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "spill.bin".into(),
            piece_length,
            pieces: vec![[0; 20], [0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: piece_length * 2,
                path: rt_path::SafeRelPath::from_name("spill.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        // One assembly fits the budget; the second forces the first out.
        task.piece_assembly_soft_cap_bytes = piece_length as usize;
        let block = |piece: u32, fill: u8| BlockEvent {
            piece,
            offset: 0,
            data: bytes::Bytes::from(vec![fill; MAX_BLOCK_SIZE as usize]),
        };
        task.record_piece_block(&block(0, 0xA1)).await.unwrap();
        task.record_piece_block(&block(1, 0xB2)).await.unwrap();

        // Piece 0 left memory, but its received block was written, not lost.
        assert!(!task.piece_assemblies.contains_key(&0));
        assert!(task.piece_assemblies.contains_key(&1));
        assert!(task.restored_partial_pieces.contains(&0));
        assert_eq!(task.piece_assembly_evictions, 1);
        let on_disk = std::fs::read(temp.path().join("spill.bin")).unwrap();
        assert_eq!(
            &on_disk[..MAX_BLOCK_SIZE as usize],
            &vec![0xA1; MAX_BLOCK_SIZE as usize][..]
        );
    }

    #[test]
    fn request_window_grows_only_for_fast_peers_and_never_under_pressure() {
        // Unknown or slow peers keep the fixed floor.
        assert_eq!(adaptive_request_pipeline(32, 0.0, 0), 32);
        assert_eq!(adaptive_request_pipeline(32, 100_000.0, 0), 32);
        // 20 MiB/s x 0.25 s is 320 blocks: capped at the adaptive maximum.
        assert_eq!(adaptive_request_pipeline(32, 20.0 * 1_048_576.0, 0), 128);
        // 4 MiB/s x 0.25 s = 64 blocks.
        assert_eq!(adaptive_request_pipeline(32, 4.0 * 1_048_576.0, 0), 64);
        // Memory pressure always wins, however fast the peer is.
        assert_eq!(adaptive_request_pipeline(8, 1e9, 0), 8);
        // A saturated torrent stops growing every peer's window.
        assert_eq!(adaptive_request_pipeline(32, 1e9, 2_000), 48);
        assert_eq!(adaptive_request_pipeline(32, 1e9, 5_000), 32);
        // NaN never inflates the window.
        assert_eq!(adaptive_request_pipeline(32, f64::NAN, 0), 32);
    }

    #[test]
    fn v1_padding_bytes_must_be_zero() {
        let files = vec![
            TorrentFileV1 {
                index: 0,
                length: 3,
                path: SafeRelPath::from_name("payload.bin", false).unwrap(),
                offset: 0,
                pad: false,
            },
            TorrentFileV1 {
                index: 1,
                length: 13,
                path: SafeRelPath::from_components(&[".pad", "13"], false).unwrap(),
                offset: 3,
                pad: true,
            },
        ];
        let piece_map = build_piece_map(16, &files).unwrap();
        let mut block = b"abc".to_vec();
        block.resize(16, 0);
        assert!(validate_padding_block(&piece_map, 0, 0, &block).is_ok());

        block[7] = 1;
        assert!(validate_padding_block(&piece_map, 0, 0, &block).is_err());
    }

    #[test]
    fn peer_availability_reconcile_counts_only_transitions() {
        let mut availability = Availability::new(4);

        reconcile_peer_availability(
            &mut availability,
            &[false, false, false, false],
            &[true, false, true, false],
        );
        reconcile_peer_availability(
            &mut availability,
            &[true, false, true, false],
            &[true, true, false, false],
        );

        assert_eq!(availability.count(0), 1);
        assert_eq!(availability.count(1), 1);
        assert_eq!(availability.count(2), 0);
        assert_eq!(availability.count(3), 0);
    }

    #[test]
    fn removing_peer_availability_accepts_the_packed_bitmap_directly() {
        let mut availability = Availability::new(10);
        for piece in [0, 2, 7, 9] {
            availability.add_have(piece);
        }
        let peer_has = PieceBitmap::from_bools(&[
            true, false, true, false, false, false, false, true, false, true,
        ]);

        remove_peer_availability(&mut availability, &peer_has);

        for piece in 0..10 {
            assert_eq!(availability.count(piece), 0, "piece {piece}");
        }
    }

    #[tokio::test]
    async fn upload_block_reads_across_many_file_regions() {
        let dir = tempfile::tempdir().unwrap();
        let mut files = Vec::new();
        let mut expected = Vec::new();
        let mut offset = 0u64;
        for idx in 0..64u32 {
            let path = rt_path::SafeRelPath::from_name(format!("{idx}.bin"), false).unwrap();
            let bytes = vec![idx as u8; 256];
            std::fs::write(path.resolve(dir.path()), &bytes).unwrap();
            expected.extend_from_slice(&bytes);
            files.push(FileSpan {
                file_index: idx,
                path,
                content_offset: offset,
                length: 256,
            });
            offset += 256;
        }
        let piece_map = Arc::new(PieceMap::new(16 * 1024, files).unwrap());
        let upload_rate = test_upload_rate_admission(None, 0).await;
        let upload_registration = upload_rate
            .network_budget
            .upload_service()
            .register(upload_rate.peer, false, MAX_UPLOAD_WORK)
            .unwrap();
        let upload = UploadContext {
            save_root: dir.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                dir.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            have_pieces: PieceBitmap::from_bools(&[true]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: true,
            fast_negotiated: false,
            upload_control: RateLimitCancellation::default(),
            shutdown_control: RateLimitCancellation::default(),
            upload_rate: upload_rate.clone(),
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };

        let read_context = UploadReadContext {
            save_root: upload.save_root.clone(),
            piece_map: upload.piece_map.clone(),
            hybrid_v2: None,
            plane: Plane::V1,
            storage: upload.storage.clone(),
            resources: upload.resources.clone(),
            upload_control: upload.upload_control.clone(),
            upload_rate: upload.upload_rate.clone(),
            read_admission: upload_registration.read_admission(),
        };
        let extent = BlockExtent::new(0, 0, 16 * 1024);
        let block = read_upload_block(&read_context, UploadRequest::from_wire(extent), false)
            .await
            .unwrap();

        assert_eq!(block.data.as_ref(), expected.as_slice());
        assert_eq!(
            upload.resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            16 * 1024
        );
        drop(block);
        assert_eq!(
            upload.resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[tokio::test]
    async fn contiguous_upload_blocks_share_one_storage_read_and_keep_wire_slices() {
        let dir = tempfile::tempdir().unwrap();
        let first = vec![0x31; MAX_BLOCK_SIZE as usize];
        let second = vec![0xa7; MAX_BLOCK_SIZE as usize];
        let mut payload = first.clone();
        payload.extend_from_slice(&second);
        std::fs::write(dir.path().join("payload.bin"), &payload).unwrap();
        let piece_map = Arc::new(
            PieceMap::new(
                u64::from(MAX_BLOCK_SIZE) * 2,
                vec![FileSpan {
                    file_index: 0,
                    path: SafeRelPath::from_name("payload.bin", false).unwrap(),
                    content_offset: 0,
                    length: payload.len() as u64,
                }],
            )
            .unwrap(),
        );
        let upload_rate = test_upload_rate_admission(None, 0).await;
        let upload_registration = upload_rate
            .network_budget
            .upload_service()
            .register(upload_rate.peer, false, MAX_UPLOAD_WORK)
            .unwrap();
        let read_context = UploadReadContext {
            save_root: dir.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                dir.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            upload_control: RateLimitCancellation::default(),
            upload_rate,
            read_admission: upload_registration.read_admission(),
        };
        let first_request = UploadRequest::from_wire(BlockExtent::new(0, 0, MAX_BLOCK_SIZE));
        let second_request =
            UploadRequest::from_wire(BlockExtent::new(0, MAX_BLOCK_SIZE, MAX_BLOCK_SIZE));
        let specs = [first_request, second_request].map(|request| UploadReadSpec {
            request,
            span: upload_read_span(&read_context, request),
            choke_critical: false,
        });
        assert!(can_append_upload_read(
            &specs[..1],
            &specs[1],
            MAX_BLOCK_SIZE as usize
        ));
        let reads_before: u64 = read_context.storage.stats().read_ops_by_class.iter().sum();

        let blocks = read_upload_batch_blocks(&read_context, &specs)
            .await
            .unwrap();

        assert_eq!(blocks.len(), 2);
        assert_eq!(blocks[0].data.as_ref(), first.as_slice());
        assert_eq!(blocks[1].data.as_ref(), second.as_slice());
        let reads_after: u64 = read_context.storage.stats().read_ops_by_class.iter().sum();
        assert_eq!(reads_after - reads_before, 1);
        assert_eq!(
            read_context.resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            u64::from(MAX_BLOCK_SIZE) * 2
        );

        drop(blocks);
        assert_eq!(
            read_context.resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
    }

    #[tokio::test]
    async fn upload_batch_resource_denial_fails_all_members_without_partial_admission() {
        let dir = tempfile::tempdir().unwrap();
        let payload_len = MAX_BLOCK_SIZE as usize * 2;
        std::fs::write(dir.path().join("payload.bin"), vec![0x4c; payload_len]).unwrap();
        let piece_map = Arc::new(
            PieceMap::new(
                u64::from(MAX_BLOCK_SIZE) * 2,
                vec![FileSpan {
                    file_index: 0,
                    path: SafeRelPath::from_name("payload.bin", false).unwrap(),
                    content_offset: 0,
                    length: u64::from(MAX_BLOCK_SIZE) * 2,
                }],
            )
            .unwrap(),
        );
        let upload_rate = test_upload_rate_admission(None, 0).await;
        let upload_registration = upload_rate
            .network_budget
            .upload_service()
            .register(upload_rate.peer, false, MAX_UPLOAD_WORK)
            .unwrap();
        let mut resource_config = rt_metrics::ResourceGovernorConfig::default();
        // One legal block fits, but the two-block backing allocation does not.
        resource_config.class_caps_bytes[MemoryClass::PeerBuffer as usize] =
            u64::from(MAX_BLOCK_SIZE);
        let resources = ResourceGovernor::new(resource_config);
        let read_context = UploadReadContext {
            save_root: dir.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                dir.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: resources.clone(),
            upload_control: RateLimitCancellation::default(),
            upload_rate,
            read_admission: upload_registration.read_admission(),
        };
        let requests = [
            BlockExtent::new(0, 0, MAX_BLOCK_SIZE),
            BlockExtent::new(0, MAX_BLOCK_SIZE, MAX_BLOCK_SIZE),
        ];
        let specs = requests.map(|block| {
            let request = UploadRequest::from_wire(block);
            UploadReadSpec {
                request,
                span: upload_read_span(&read_context, request),
                choke_critical: false,
            }
        });

        let completions =
            upload_read_batch_future(specs.into_iter().collect(), Arc::new(read_context)).await;

        assert_eq!(completions.len(), 2);
        assert!(completions.into_iter().all(|completion| matches!(
            completion,
            UploadReadCompletion::Completed { result: Err(_), .. }
        )));
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
        assert_eq!(
            upload_registration.read_admission().in_flight_read_jobs(),
            0
        );
    }

    #[tokio::test]
    async fn upload_block_synthesizes_missing_bep47_padding() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("payload.bin"), b"abc").unwrap();
        let files = vec![
            FileSpan {
                file_index: 0,
                path: SafeRelPath::from_name("payload.bin", false).unwrap(),
                content_offset: 0,
                length: 3,
            },
            FileSpan {
                file_index: 1,
                path: SafeRelPath::from_components(&[".pad", "13"], false).unwrap(),
                content_offset: 3,
                length: 13,
            },
        ];
        let piece_map = Arc::new(PieceMap::new_with_padding(16, files, [1]).unwrap());
        let upload_rate = test_upload_rate_admission(None, 0).await;
        let upload_registration = upload_rate
            .network_budget
            .upload_service()
            .register(upload_rate.peer, false, MAX_UPLOAD_WORK)
            .unwrap();
        let upload = UploadReadContext {
            save_root: dir.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                dir.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            upload_rate,
            upload_control: RateLimitCancellation::default(),
            read_admission: upload_registration.read_admission(),
        };

        let extent = BlockExtent::new(0, 0, 16);
        let block = read_upload_block(&upload, UploadRequest::from_wire(extent), false)
            .await
            .unwrap();
        let mut expected = b"abc".to_vec();
        expected.resize(16, 0);
        assert_eq!(block.data.as_ref(), expected.as_slice());
        assert!(!dir.path().join(".pad/13").exists());
    }

    #[test]
    fn upload_context_piece_map_is_shared_not_deep_cloned_per_peer() {
        // TNG-014: `UploadContext.piece_map` used to be an owned `PieceMap`,
        // deep-copying its `files: Vec<FileSpan>` on every new peer
        // connection (`upload_context()`'s `self.piece_map.clone()`).
        // Wrapping it in `Arc` makes that the same cheap refcount bump every
        // other per-peer field already gets (`storage`, `resources`, etc.)
        // instead of real, avoidable memory growth at swarm scale.
        let files = vec![FileSpan {
            file_index: 0,
            path: rt_path::SafeRelPath::from_name("a.bin", false).unwrap(),
            content_offset: 0,
            length: 256,
        }];
        let shared = Arc::new(PieceMap::new(16 * 1024, files).unwrap());
        assert_eq!(Arc::strong_count(&shared), 1);

        // Mirrors exactly what `upload_context()` does per new peer
        // connection: `piece_map: self.piece_map.clone()`.
        let per_peer_a = shared.clone();
        let per_peer_b = shared.clone();

        assert_eq!(
            Arc::strong_count(&shared),
            3,
            "cloning for two peer connections should only bump the refcount, not allocate two new PieceMaps"
        );
        assert!(
            Arc::ptr_eq(&shared, &per_peer_a) && Arc::ptr_eq(&per_peer_a, &per_peer_b),
            "every peer's piece_map must point at the exact same allocation"
        );
    }

    #[test]
    fn metadata_upload_payload_is_shared_and_budgeted_per_torrent() {
        let pieces = [0_u8; 20];
        let mut info_pairs: Vec<(&[u8], BValue<'_>)> = vec![
            (b"length", BValue::Int(4)),
            (b"name", BValue::Bytes(b"a.bin")),
            (b"piece length", BValue::Int(16_384)),
            (b"pieces", BValue::Bytes(&pieces)),
        ];
        info_pairs.sort_by(|a, b| a.0.cmp(b.0));
        let raw = rt_bencode::encode(&BValue::Dict(vec![(
            b"info".as_slice(),
            BValue::Dict(info_pairs),
        )]));
        let payload_len = torrent_info_bytes(&raw).unwrap().len();
        let mut class_caps_bytes = [0; rt_metrics::MEMORY_CLASS_COUNT];
        let class_cap_bytes = payload_len as u64 + 1024 * 1024;
        class_caps_bytes[MemoryClass::Metadata as usize] = class_cap_bytes;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: class_cap_bytes,
            class_caps_bytes,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });

        let (metadata, lease) = prepare_metadata_payload(&governor, "a".repeat(40).as_str(), &raw);
        let metadata = metadata.expect("metadata payload should fit the class budget");
        let peer_a = metadata.clone();
        let peer_b = metadata.clone();
        assert!(Arc::ptr_eq(&metadata, &peer_a));
        assert!(Arc::ptr_eq(&peer_a, &peer_b));
        assert_eq!(
            governor.snapshot().classes[MemoryClass::Metadata as usize].used_bytes,
            payload_len as u64
        );
        drop(peer_a);
        drop(peer_b);
        drop(metadata);
        drop(lease);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::Metadata as usize].used_bytes,
            0
        );
    }

    #[test]
    fn tracker_state_reservation_covers_bounded_response_fields() {
        let mut tiers = tracker_tiers_from_urls(&["https://tracker.example/announce".to_owned()]);
        let bytes = tracker_state_memory_bytes(&tiers, tiers.capacity()) as u64;
        let mut class_caps_bytes = [0; rt_metrics::MEMORY_CLASS_COUNT];
        class_caps_bytes[MemoryClass::Metadata as usize] = bytes;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: bytes,
            class_caps_bytes,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });

        let leases = reserve_tracker_state_memory(&governor, &tiers, tiers.capacity()).unwrap();
        assert_eq!(leases.iter().map(MemoryLease::bytes).sum::<u64>(), bytes);

        let tracker = tiers[0].first_mut().unwrap();
        tracker.on_success(&AnnounceResponse {
            interval: 1_800,
            min_interval: None,
            peers: Vec::new(),
            tracker_id: Some(vec![0xabu8; MAX_TRACKER_STATE_ID_BYTES]),
            warning_message: Some("warning".repeat(MAX_TRACKER_STATE_TEXT_BYTES / 7)),
            complete: None,
            incomplete: None,
        });
        assert_eq!(
            governor.snapshot().classes[MemoryClass::Metadata as usize].used_bytes,
            bytes
        );

        drop(leases);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::Metadata as usize].used_bytes,
            0
        );
    }

    #[test]
    fn upload_block_reservation_uses_peer_buffer_governor_class() {
        let mut caps = [0; rt_metrics::MEMORY_CLASS_COUNT];
        caps[MemoryClass::PeerBuffer as usize] = 16 * 1024;
        let governor = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig {
            total_cap_bytes: 16 * 1024,
            class_caps_bytes: caps,
            pressure_constrained_pct: 75,
            pressure_critical_pct: 90,
        });

        let lease = reserve_peer_upload_bytes(&governor, 16 * 1024).unwrap();
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            16 * 1024
        );
        drop(lease);
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );
        assert!(reserve_peer_upload_bytes(&governor, 16 * 1024 + 1).is_err());
        assert_eq!(
            governor.snapshot().classes[MemoryClass::PeerBuffer as usize].denied_allocations,
            1
        );
    }

    #[tokio::test]
    async fn peer_event_delivery_is_bounded_when_torrent_actor_stalls() {
        let (tx, mut rx) = mpsc::channel(1);
        let peer_id = PeerId::new();
        tx.send(PeerEvent::Unchoked {
            peer: "127.0.0.1:6881".parse().unwrap(),
            id: peer_id,
            download_generation: 0,
        })
        .await
        .unwrap();

        let started = Instant::now();
        let delivered = send_peer_event(
            &tx,
            PeerEvent::Interested {
                peer: "127.0.0.1:6881".parse().unwrap(),
                id: peer_id,
            },
        )
        .await;

        assert!(!delivered);
        assert!(started.elapsed() < PEER_EVENT_SEND_TIMEOUT + Duration::from_secs(1));
        assert!(rx.try_recv().is_ok());
    }

    #[tokio::test]
    async fn upload_read_panic_keeps_its_request_for_peer_cleanup() {
        let request = UploadRequest::from_wire(BlockExtent::new(7, 16 * 1024, 16 * 1024));
        let read = std::future::poll_fn(|_| -> std::task::Poll<_> {
            panic!("simulated upload read panic");
        });

        let completion = catch_upload_read(request, read).await;

        assert!(matches!(
            completion,
            UploadReadCompletion::Panicked { request: actual } if actual == request
        ));
    }

    #[tokio::test]
    async fn upload_reads_are_aborted_after_peer_loop_exit() {
        use std::sync::atomic::{AtomicBool, Ordering};

        struct DropMarker(Arc<AtomicBool>);

        impl Drop for DropMarker {
            fn drop(&mut self) {
                self.0.store(true, Ordering::SeqCst);
            }
        }

        let dropped = Arc::new(AtomicBool::new(false));
        let started = Arc::new(AtomicBool::new(false));
        let marker = Arc::clone(&dropped);
        let task_started = Arc::clone(&started);
        let read = Box::pin(async move {
            task_started.store(true, Ordering::SeqCst);
            let _marker = DropMarker(marker);
            std::future::pending::<UploadReadCompletion>().await
        });
        let mut upload_reads = UploadReadTasks::default();
        upload_reads.push(read);
        assert!(upload_reads.next().now_or_never().is_none());
        assert!(started.load(Ordering::SeqCst));

        abort_upload_reads(&mut upload_reads);
        assert!(dropped.load(Ordering::SeqCst));
    }

    #[tokio::test]
    async fn upload_reads_are_aborted_when_peer_loop_is_cancelled() {
        use std::sync::atomic::{AtomicBool, Ordering};

        struct DropMarker(Arc<AtomicBool>);

        impl Drop for DropMarker {
            fn drop(&mut self) {
                self.0.store(true, Ordering::SeqCst);
            }
        }

        let dropped = Arc::new(AtomicBool::new(false));
        let owner_started = Arc::new(AtomicBool::new(false));
        let marker = Arc::clone(&dropped);
        let (read_started_tx, read_started_rx) = oneshot::channel();
        let read = Box::pin(async move {
            let _ = read_started_tx.send(());
            let _marker = DropMarker(marker);
            std::future::pending::<UploadReadCompletion>().await
        });
        let task_owner_started = Arc::clone(&owner_started);
        let peer_loop = tokio::spawn(async move {
            let mut upload_reads = UploadReadTasks::default();
            upload_reads.push(read);
            tokio::select! {
                _ = upload_reads.next() => panic!("pending upload read unexpectedly completed"),
                _ = read_started_rx => {}
            }
            task_owner_started.store(true, Ordering::SeqCst);
            std::future::pending::<()>().await;
        });
        timeout(Duration::from_secs(1), async {
            while !owner_started.load(Ordering::SeqCst) {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("upload read owner did not start");
        peer_loop.abort();
        assert!(peer_loop.await.unwrap_err().is_cancelled());

        assert!(dropped.load(Ordering::SeqCst));
    }

    #[tokio::test]
    async fn failed_choke_event_preserves_outstanding_requests() {
        let (tx, _rx) = mpsc::channel(1);
        let peer = "127.0.0.1:6881".parse().unwrap();
        let peer_id = PeerId::new();
        tx.try_send(PeerEvent::Unchoked {
            peer,
            id: peer_id,
            download_generation: 0,
        })
        .unwrap();
        let request = BlockRequest {
            piece: 3,
            begin: 0,
            length: 4,
        };
        let mut outstanding = Vec::new();

        assert!(
            !send_choke_event(
                &tx,
                peer,
                peer_id,
                0,
                false,
                vec![request],
                &mut outstanding,
            )
            .await
        );
        assert_eq!(drain_outstanding(&mut outstanding), vec![request]);
    }

    #[tokio::test]
    async fn terminal_peer_disconnect_waits_for_dedicated_queue_capacity() {
        let (tx, mut rx) = mpsc::channel(1);
        let peer = "127.0.0.1:6881".parse().unwrap();
        let peer_id = PeerId::new();
        tx.send(PeerEvent::Unchoked {
            peer,
            id: peer_id,
            download_generation: 0,
        })
        .await
        .unwrap();

        let sender = tokio::spawn(async move {
            send_peer_disconnect_event(
                &tx,
                PeerEvent::Disconnected {
                    peer,
                    id: peer_id,
                    outstanding: Vec::new(),
                },
            )
            .await
        });
        tokio::task::yield_now().await;
        assert!(
            !sender.is_finished(),
            "terminal disconnect must not be dropped when its queue is full"
        );

        assert!(matches!(rx.recv().await, Some(PeerEvent::Unchoked { .. })));
        assert!(sender.await.unwrap());
        assert!(matches!(
            rx.recv().await,
            Some(PeerEvent::Disconnected { .. })
        ));
    }

    async fn peer_loop_upload_context(
        root: &std::path::Path,
        payload_len: u64,
        fast_negotiated: bool,
        rate_limited: bool,
        upload_control: RateLimitCancellation,
        shutdown_control: RateLimitCancellation,
    ) -> (UploadContext, MountScheduler) {
        let upload_rate = test_upload_rate_admission(
            rate_limited.then_some(1),
            if rate_limited { 32 * 1024 } else { 0 },
        )
        .await;
        let piece_map = Arc::new(
            PieceMap::new(
                payload_len,
                vec![FileSpan {
                    file_index: 0,
                    path: rt_path::SafeRelPath::from_name("peer.bin", false).unwrap(),
                    content_offset: 0,
                    length: payload_len,
                }],
            )
            .unwrap(),
        );
        let storage = MountScheduler::new_for_path(
            StorageRootId::new(),
            root,
            &SchedulerConfig {
                profile: StorageProfile::Unknown,
                ..Default::default()
            },
        );
        let upload = UploadContext {
            save_root: root.to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: storage.clone(),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            have_pieces: PieceBitmap::from_bools(&[true]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: true,
            fast_negotiated,
            upload_control,
            shutdown_control,
            upload_rate,
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };
        (upload, storage)
    }

    #[tokio::test]
    async fn peer_loop_flushes_small_upload_batches_after_the_short_deadline() {
        let temp = tempfile::tempdir().unwrap();
        let payload = vec![0x5a; 16 * 1024];
        std::fs::write(temp.path().join("peer.bin"), &payload).unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();
        let (upload, _) = peer_loop_upload_context(
            temp.path(),
            payload.len() as u64,
            true,
            false,
            RateLimitCancellation::default(),
            RateLimitCancellation::default(),
        )
        .await;
        let pending_uploaded_bytes = Arc::clone(&upload.upload_accounting);
        let (peer_event_tx, mut peer_event_rx) = mpsc::channel(8);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(4);
        let peer_loop = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            false,
        ));
        let mut remote = Framed::new(remote, PeerCodec::default());

        peer_cmd_tx.send(PeerCommand::Unchoke).await.unwrap();
        assert!(matches!(
            remote.next().await.unwrap().unwrap(),
            Message::Unchoke
        ));
        remote
            .send(Message::Request {
                piece: 0,
                begin: 0,
                length: payload.len() as u32,
            })
            .await
            .unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            Message::Piece { ref data, .. } if data.as_ref() == payload.as_slice()
        ));
        assert!(matches!(
            timeout(Duration::from_secs(1), peer_event_rx.recv())
                .await
                .unwrap(),
            Some(PeerEvent::Uploaded { peer, .. }) if peer == peer_addr
        ));
        assert_eq!(
            pending_uploaded_bytes
                .pending_uploaded_bytes
                .load(Ordering::Relaxed),
            payload.len() as u64
        );

        assert!(timeout(Duration::from_millis(50), peer_event_rx.recv())
            .await
            .is_err());
        peer_cmd_tx.send(PeerCommand::Shutdown).await.unwrap();
        let exit = timeout(Duration::from_secs(1), peer_loop)
            .await
            .expect("peer loop did not stop")
            .unwrap();
        assert!(exit.result.is_ok());
    }

    #[tokio::test]
    async fn remote_cancel_rejects_fast_request_still_queued_for_storage() {
        let temp = tempfile::tempdir().unwrap();
        const REQUESTS: usize = MAX_PENDING_UPLOAD_READS + 1;
        const REQUEST_BYTES: u64 = 4;
        let payload = vec![0x5a; REQUESTS * REQUEST_BYTES as usize];
        std::fs::write(temp.path().join("peer.bin"), &payload).unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();
        let upload_control = RateLimitCancellation::default();
        let shutdown_control = RateLimitCancellation::default();
        let (upload, storage) = peer_loop_upload_context(
            temp.path(),
            payload.len() as u64,
            true,
            true,
            upload_control.clone(),
            shutdown_control.clone(),
        )
        .await;
        // Storage operation counts now reflect batched reads, so wait on the
        // scheduler's logical job charges rather than assuming one operation
        // per wire request.
        let upload_service = upload.upload_rate.network_budget.upload_service();
        let (peer_event_tx, _peer_event_rx) = mpsc::channel(REQUESTS + 1);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(REQUESTS + 1);
        let loop_task = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            true,
        ));
        let mut remote = Framed::new(remote, PeerCodec::default());

        peer_cmd_tx.send(PeerCommand::Unchoke).await.unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            Message::Unchoke
        ));
        for index in 0..REQUESTS {
            remote
                .send(Message::Request {
                    piece: 0,
                    begin: (index as u32) * REQUEST_BYTES as u32,
                    length: REQUEST_BYTES as u32,
                })
                .await
                .unwrap();
        }
        let service_read_window = MAX_PENDING_UPLOAD_READS.min(
            crate::transfer::upload_scheduler::UploadReadLimits::default()
                .max_in_flight_per_connection,
        );
        timeout(Duration::from_secs(15), async {
            while upload_service.in_flight_read_jobs() < service_read_window
                || storage.stats().read_ops_by_class[IoClass::PeerRead as usize] == 0
            {
                tokio::task::yield_now().await;
            }
        })
        .await
        .unwrap_or_else(|_| {
            let observed = upload_service.in_flight_read_jobs();
            panic!("the process upload service admitted-read window did not fill: {observed}/{service_read_window} logical reads")
        });

        let queued = (MAX_PENDING_UPLOAD_READS as u32) * REQUEST_BYTES as u32;
        remote
            .send(Message::Cancel {
                piece: 0,
                begin: queued,
                length: REQUEST_BYTES as u32,
            })
            .await
            .unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            Message::Reject { piece: 0, begin, length }
                if begin == queued && length == REQUEST_BYTES as u32
        ));

        upload_control.cancel();
        shutdown_control.cancel();
        peer_cmd_tx.send(PeerCommand::Shutdown).await.unwrap();
        let exit = timeout(Duration::from_secs(2), loop_task)
            .await
            .expect("peer loop did not stop after queued Cancel")
            .unwrap();
        assert!(exit.result.is_ok());
    }

    #[tokio::test]
    async fn remote_cancel_keeps_fast_request_already_in_service_owed() {
        let temp = tempfile::tempdir().unwrap();
        let payload = b"data";
        std::fs::write(temp.path().join("peer.bin"), payload).unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();
        let upload_control = RateLimitCancellation::default();
        let shutdown_control = RateLimitCancellation::default();
        let (upload, storage) = peer_loop_upload_context(
            temp.path(),
            payload.len() as u64,
            true,
            true,
            upload_control.clone(),
            shutdown_control.clone(),
        )
        .await;
        let rate = upload.upload_rate.clone();
        let (peer_event_tx, _peer_event_rx) = mpsc::channel(2);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(2);
        let loop_task = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            true,
        ));
        let mut remote = Framed::new(remote, PeerCodec::default());

        peer_cmd_tx.send(PeerCommand::Unchoke).await.unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            Message::Unchoke
        ));
        remote
            .send(Message::Request {
                piece: 0,
                begin: 0,
                length: payload.len() as u32,
            })
            .await
            .unwrap();
        timeout(Duration::from_secs(2), async {
            while storage.stats().backend_read_ops_by_class[IoClass::PeerRead as usize] == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("the upload read did not enter service");
        remote
            .send(Message::Cancel {
                piece: 0,
                begin: 0,
                length: payload.len() as u32,
            })
            .await
            .unwrap();
        assert!(timeout(Duration::from_millis(50), remote.next())
            .await
            .is_err());

        rate.network_budget
            .set_upload_torrent_limit(rate.peer.torrent, None);
        assert!(matches!(
            timeout(Duration::from_secs(2), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            Message::Piece { piece: 0, begin: 0, data } if data.as_ref() == payload
        ));
        drop(peer_cmd_tx);
        let exit = timeout(Duration::from_secs(2), loop_task)
            .await
            .expect("peer loop did not finish after its in-service response")
            .unwrap();
        assert!(exit.result.is_ok());
    }

    #[tokio::test]
    async fn endgame_cancel_targets_only_exact_duplicate_requests() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [91; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "endgame-cancel.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("endgame-cancel.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let permits = Arc::new(tokio::sync::Semaphore::new(3));
        let accepted_peer = "127.0.0.1:6881".parse().unwrap();
        let duplicate_peer = "127.0.0.1:6882".parse().unwrap();
        let near_match_peer = "127.0.0.1:6883".parse().unwrap();
        let (_, mut accepted_commands) = task
            .register_peer(
                accepted_peer,
                permits.clone().acquire_owned().await.unwrap(),
            )
            .expect("accepted peer registration should fit the memory budget");
        let (_, mut duplicate_commands) = task
            .register_peer(
                duplicate_peer,
                permits.clone().acquire_owned().await.unwrap(),
            )
            .expect("duplicate peer registration should fit the memory budget");
        let (_, mut near_match_commands) = task
            .register_peer(near_match_peer, permits.acquire_owned().await.unwrap())
            .expect("near-match peer registration should fit the memory budget");

        let accepted = BlockRequest {
            piece: 0,
            begin: 0,
            length: 4,
        };
        task.active_peers
            .get_mut(&duplicate_peer)
            .unwrap()
            .requested
            .push(accepted);
        task.active_peers
            .get_mut(&near_match_peer)
            .unwrap()
            .requested
            .push(BlockRequest {
                length: 3,
                ..accepted
            });

        task.cancel_endgame_duplicates(accepted);

        assert!(matches!(
            duplicate_commands.try_recv(),
            Ok(PeerCommand::Cancel { request }) if request == accepted
        ));
        assert!(accepted_commands.try_recv().is_err());
        assert!(near_match_commands.try_recv().is_err());
        task.shutdown_peers().await;
    }

    #[tokio::test]
    async fn peer_loop_shutdown_interrupts_rate_limited_upload() {
        let temp = tempfile::tempdir().unwrap();
        let payload = vec![7u8; MAX_BLOCK_SIZE as usize];
        std::fs::write(temp.path().join("peer.bin"), &payload).unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();

        let piece_map = Arc::new(
            PieceMap::new(
                u64::from(MAX_BLOCK_SIZE),
                vec![FileSpan {
                    file_index: 0,
                    path: rt_path::SafeRelPath::from_name("peer.bin", false).unwrap(),
                    content_offset: 0,
                    length: u64::from(MAX_BLOCK_SIZE),
                }],
            )
            .unwrap(),
        );
        let control = RateLimitCancellation::default();
        let shutdown_control = RateLimitCancellation::default();
        let upload = UploadContext {
            save_root: temp.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                temp.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            have_pieces: PieceBitmap::from_bools(&[true]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: true,
            fast_negotiated: false,
            upload_control: control.clone(),
            shutdown_control: shutdown_control.clone(),
            upload_rate: test_upload_rate_admission(Some(1), 32 * 1024).await,
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };
        let (peer_event_tx, mut peer_event_rx) = mpsc::channel(4);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(4);
        let loop_task = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            true,
        ));
        let mut remote = Framed::new(remote, PeerCodec::default());

        peer_cmd_tx.send(PeerCommand::Unchoke).await.unwrap();
        assert!(matches!(
            remote.next().await.unwrap().unwrap(),
            Message::Unchoke
        ));
        remote
            .send(Message::Request {
                piece: 0,
                begin: 0,
                length: MAX_BLOCK_SIZE,
            })
            .await
            .unwrap();
        tokio::time::sleep(Duration::from_millis(20)).await;

        // The one-byte-per-second bucket would otherwise keep this peer loop
        // in its upload wait for hours after the first byte is consumed.
        control.cancel();
        shutdown_control.cancel();
        peer_cmd_tx.send(PeerCommand::Shutdown).await.unwrap();
        let exit = timeout(Duration::from_secs(1), loop_task)
            .await
            .expect("shutdown must interrupt a rate-limited upload wait")
            .unwrap();
        assert!(exit.result.is_ok());
        assert!(matches!(
            peer_event_rx.recv().await,
            Some(PeerEvent::Disconnected { peer, .. }) if peer == peer_addr
        ));
    }

    #[tokio::test]
    async fn peer_loop_keeps_reading_while_upload_waits_for_rate_budget() {
        let temp = tempfile::tempdir().unwrap();
        let payload = vec![7u8; MAX_BLOCK_SIZE as usize];
        std::fs::write(temp.path().join("peer.bin"), &payload).unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();

        let piece_map = Arc::new(
            PieceMap::new(
                u64::from(MAX_BLOCK_SIZE),
                vec![FileSpan {
                    file_index: 0,
                    path: rt_path::SafeRelPath::from_name("peer.bin", false).unwrap(),
                    content_offset: 0,
                    length: u64::from(MAX_BLOCK_SIZE),
                }],
            )
            .unwrap(),
        );
        let storage = MountScheduler::new_for_path(
            StorageRootId::new(),
            temp.path(),
            &SchedulerConfig {
                profile: StorageProfile::Unknown,
                ..Default::default()
            },
        );
        let control = RateLimitCancellation::default();
        let shutdown_control = RateLimitCancellation::default();
        let upload = UploadContext {
            save_root: temp.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: storage.clone(),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            have_pieces: PieceBitmap::from_bools(&[true]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: true,
            fast_negotiated: false,
            upload_control: control.clone(),
            shutdown_control: shutdown_control.clone(),
            upload_rate: test_upload_rate_admission(Some(1), 32 * 1024).await,
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };
        let (peer_event_tx, mut peer_event_rx) = mpsc::channel(4);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(4);
        let loop_task = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            true,
        ));
        let mut remote = Framed::new(remote, PeerCodec::default());

        peer_cmd_tx.send(PeerCommand::Unchoke).await.unwrap();
        assert!(matches!(
            remote.next().await.unwrap().unwrap(),
            Message::Unchoke
        ));
        remote
            .send(Message::Request {
                piece: 0,
                begin: 0,
                length: MAX_BLOCK_SIZE,
            })
            .await
            .unwrap();
        let peer_read_index = IoClass::PeerRead as usize;
        timeout(Duration::from_secs(2), async {
            while storage.stats().backend_read_ops_by_class[peer_read_index] == 0 {
                tokio::task::yield_now().await;
            }
            // Let the completed storage task advance into its deliberately
            // blocked rate admission before sending the next peer message.
            tokio::time::sleep(Duration::from_millis(10)).await;
        })
        .await
        .expect("upload storage read did not complete");

        remote.send(Message::Interested).await.unwrap();
        let event = timeout(Duration::from_secs(1), async {
            loop {
                if let Some(event) = peer_event_rx.recv().await {
                    if matches!(event, PeerEvent::Interested { peer, .. } if peer == peer_addr) {
                        break event;
                    }
                }
            }
        })
        .await
        .expect("the peer loop stalled behind upload rate admission");
        assert!(matches!(event, PeerEvent::Interested { .. }));

        control.cancel();
        shutdown_control.cancel();
        peer_cmd_tx.send(PeerCommand::Shutdown).await.unwrap();
        let exit = timeout(Duration::from_secs(1), loop_task)
            .await
            .expect("shutdown must interrupt the upload wait")
            .unwrap();
        assert!(exit.result.is_ok());
    }

    #[tokio::test]
    async fn peer_loop_exits_when_command_channel_closes() {
        let temp = tempfile::tempdir().unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let client = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();

        let piece_map = Arc::new(
            PieceMap::new(
                4,
                vec![FileSpan {
                    file_index: 0,
                    path: rt_path::SafeRelPath::from_name("peer.bin", false).unwrap(),
                    content_offset: 0,
                    length: 4,
                }],
            )
            .unwrap(),
        );
        let upload = UploadContext {
            save_root: temp.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                temp.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            have_pieces: PieceBitmap::from_bools(&[false]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: true,
            fast_negotiated: false,
            upload_control: RateLimitCancellation::default(),
            shutdown_control: RateLimitCancellation::default(),
            upload_rate: test_upload_rate_admission(None, 0).await,
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };
        let (peer_event_tx, mut peer_event_rx) = mpsc::channel(2);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(1);
        drop(peer_cmd_tx);

        let result = timeout(
            Duration::from_secs(1),
            run_peer_loop(
                peer_addr,
                PeerId::new(),
                PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
                peer_event_tx,
                peer_cmd_rx,
                upload,
                true,
            ),
        )
        .await
        .expect("closed command channel should stop the peer promptly");

        assert!(result.result.is_ok());
        assert!(matches!(
            peer_event_rx.recv().await,
            Some(PeerEvent::Disconnected { peer, .. }) if peer == peer_addr
        ));
        drop(client);
    }

    #[tokio::test]
    async fn peer_loop_uses_remote_metadata_extension_id_for_upload() {
        let temp = tempfile::tempdir().unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();

        let piece_map = Arc::new(
            PieceMap::new(
                4,
                vec![FileSpan {
                    file_index: 0,
                    path: rt_path::SafeRelPath::from_name("peer.bin", false).unwrap(),
                    content_offset: 0,
                    length: 4,
                }],
            )
            .unwrap(),
        );
        let upload = UploadContext {
            save_root: temp.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                temp.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            have_pieces: PieceBitmap::from_bools(&[false]),
            _bitmap_memory_lease: None,
            metadata: Some(Arc::new(b"metadata".to_vec())),
            is_private: false,
            pex_enabled: true,
            fast_negotiated: false,
            upload_control: RateLimitCancellation::default(),
            shutdown_control: RateLimitCancellation::default(),
            upload_rate: test_upload_rate_admission(None, 0).await,
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };
        let (peer_event_tx, mut peer_event_rx) = mpsc::channel(4);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(1);
        let loop_task = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            true,
        ));
        let mut remote = Framed::new(remote, PeerCodec::default());

        remote
            .send(Message::Extended {
                ext_id: EXT_HANDSHAKE_ID,
                payload: ExtensionHandshake::new(None).with_ut_metadata(7).encode(),
            })
            .await
            .unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), peer_event_rx.recv())
                .await
                .unwrap(),
            Some(PeerEvent::ExtendedHandshake {
                ut_metadata_id: Some(7),
                ..
            })
        ));

        remote
            .send(Message::Extended {
                // This is TorrentNG's id, which the remote learned from our
                // handshake. The response must use the remote's id (7).
                ext_id: LOCAL_UT_METADATA_ID,
                payload: UtMetadataMessage::Request { piece: 0 }.encode(),
            })
            .await
            .unwrap();

        let response = timeout(Duration::from_secs(1), remote.next())
            .await
            .unwrap()
            .unwrap()
            .unwrap();
        let Message::Extended { ext_id, payload } = response else {
            panic!("expected a ut_metadata response");
        };
        assert_eq!(ext_id, 7);
        assert_eq!(
            UtMetadataMessage::parse(&payload).unwrap(),
            UtMetadataMessage::Data {
                piece: 0,
                total_size: 8,
                data: b"metadata".to_vec(),
            }
        );

        drop(peer_cmd_tx);
        let exit = timeout(Duration::from_secs(1), loop_task)
            .await
            .expect("peer loop should stop when its command channel closes")
            .unwrap();
        assert!(exit.result.is_ok());
    }

    #[tokio::test]
    async fn peer_loop_returns_outstanding_requests_on_disconnect() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let temp = tempfile::tempdir().unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();

        let remote_task = tokio::spawn(async move {
            let mut remote = remote;
            remote.write_all(&Message::Unchoke.encode()).await.unwrap();
            let mut request = [0u8; 128];
            let _ = remote.read(&mut request).await;
        });

        let piece_map = Arc::new(
            PieceMap::new(
                4,
                vec![FileSpan {
                    file_index: 0,
                    path: rt_path::SafeRelPath::from_name("peer.bin", false).unwrap(),
                    content_offset: 0,
                    length: 4,
                }],
            )
            .unwrap(),
        );
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let request_lease = reserve_peer_event_bytes(&resources, 4).unwrap();
        let upload_rate = test_upload_rate_admission(None, 0).await;
        let rate_grant = test_download_grant(&upload_rate, 4);
        let upload = UploadContext {
            save_root: temp.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                temp.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources,
            have_pieces: PieceBitmap::from_bools(&[false]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: true,
            fast_negotiated: false,
            upload_control: RateLimitCancellation::default(),
            shutdown_control: RateLimitCancellation::default(),
            upload_rate,
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };
        let (peer_event_tx, mut peer_event_rx) = mpsc::channel(4);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(4);
        let loop_task = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            false,
        ));

        assert!(matches!(
            peer_event_rx.recv().await,
            Some(PeerEvent::Unchoked { peer, .. }) if peer == peer_addr
        ));
        let request = BlockRequest {
            piece: 0,
            begin: 0,
            length: 4,
        };
        peer_cmd_tx
            .send(PeerCommand::Request {
                request,
                download_generation: 0,
                memory_lease: request_lease,
                rate_grant: Some(rate_grant),
                source_permit: None,
            })
            .await
            .unwrap();

        let exit = timeout(Duration::from_secs(2), loop_task)
            .await
            .expect("peer loop did not exit after remote disconnect")
            .unwrap();
        assert!(exit.outstanding.contains(&request));
        remote_task.await.unwrap();
    }

    #[tokio::test]
    async fn peer_loop_moves_request_reservation_into_piece_event() {
        let temp = tempfile::tempdir().unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer_addr = listener.local_addr().unwrap();
        let remote = TcpStream::connect(peer_addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();
        let mut remote = Framed::new(remote, PeerCodec::default());

        let piece_map = Arc::new(
            PieceMap::new(
                4,
                vec![FileSpan {
                    file_index: 0,
                    path: rt_path::SafeRelPath::from_name("peer.bin", false).unwrap(),
                    content_offset: 0,
                    length: 4,
                }],
            )
            .unwrap(),
        );
        let resources = ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default());
        let request_lease = reserve_peer_event_bytes(&resources, 4).unwrap();
        let upload_rate = test_upload_rate_admission(None, 0).await;
        let rate_grant = test_download_grant(&upload_rate, 4);
        let upload = UploadContext {
            save_root: temp.path().to_path_buf(),
            piece_map,
            hybrid_v2: None,
            plane: Plane::V1,
            storage: MountScheduler::new_for_path(
                StorageRootId::new(),
                temp.path(),
                &SchedulerConfig {
                    profile: StorageProfile::Unknown,
                    ..Default::default()
                },
            ),
            resources: resources.clone(),
            have_pieces: PieceBitmap::from_bools(&[false]),
            _bitmap_memory_lease: None,
            metadata: None,
            is_private: false,
            pex_enabled: true,
            fast_negotiated: false,
            upload_control: RateLimitCancellation::default(),
            shutdown_control: RateLimitCancellation::default(),
            upload_rate,
            upload_accounting: Arc::new(UploadAccountingState::new(UPLOAD_ACCOUNTING_BATCH_BYTES)),
        };
        let (peer_event_tx, mut peer_event_rx) = mpsc::channel(4);
        let (peer_cmd_tx, peer_cmd_rx) = mpsc::channel(4);
        let loop_task = tokio::spawn(run_peer_loop(
            peer_addr,
            PeerId::new(),
            PeerIo::Tcp(Framed::new(server, PeerCodec::default())),
            peer_event_tx,
            peer_cmd_rx,
            upload,
            false,
        ));

        remote.send(Message::Unchoke).await.unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), peer_event_rx.recv())
                .await
                .unwrap(),
            Some(PeerEvent::Unchoked { peer, .. }) if peer == peer_addr
        ));

        let request = BlockRequest {
            piece: 0,
            begin: 0,
            length: 4,
        };
        peer_cmd_tx
            .send(PeerCommand::Request {
                request,
                download_generation: 0,
                memory_lease: request_lease,
                rate_grant: Some(rate_grant),
                source_permit: None,
            })
            .await
            .unwrap();
        loop {
            let message = timeout(Duration::from_secs(1), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap();
            if matches!(message, Message::Request { .. }) {
                break;
            }
        }
        peer_cmd_tx
            .send(PeerCommand::Cancel { request })
            .await
            .unwrap();
        assert!(matches!(
            timeout(Duration::from_secs(1), remote.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            Message::Cancel {
                piece: 0,
                begin: 0,
                length: 4
            }
        ));
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            4,
            "sending Cancel must retain the lease for a possible in-flight Piece"
        );
        remote
            .send(Message::Piece {
                piece: 0,
                begin: 0,
                data: bytes::Bytes::from_static(b"data"),
            })
            .await
            .unwrap();

        let block = timeout(Duration::from_secs(1), async {
            loop {
                match peer_event_rx.recv().await {
                    Some(PeerEvent::Piece { block, .. }) => break block,
                    Some(PeerEvent::RequestSent { .. }) => continue,
                    other => panic!("expected a leased piece event, got {other:?}"),
                }
            }
        })
        .await
        .unwrap();
        assert_eq!(block.len(), 4);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            4,
            "the reservation must move from the outstanding request to the event"
        );
        drop(block);
        assert_eq!(
            resources.snapshot().classes[MemoryClass::PeerBuffer as usize].used_bytes,
            0
        );

        drop(peer_cmd_tx);
        let exit = timeout(Duration::from_secs(1), loop_task)
            .await
            .expect("peer loop should stop when its command channel closes")
            .unwrap();
        assert!(exit.result.is_ok());
    }

    #[test]
    fn peer_event_channel_capacity_is_bounded_by_global_peer_budget() {
        assert_eq!(peer_event_channel_capacity(1), 64);
        assert_eq!(peer_event_channel_capacity(200), 200);
        assert_eq!(peer_event_channel_capacity(10_000), 512);
    }

    #[test]
    fn paused_torrent_drops_late_peer_events() {
        let peer_id = PeerId::new();
        let active_event = PeerEvent::Unchoked {
            peer: "127.0.0.1:6881".parse().unwrap(),
            id: peer_id,
            download_generation: 0,
        };
        let late_piece = PeerEvent::Piece {
            peer: "127.0.0.1:6881".parse().unwrap(),
            id: peer_id,
            block: LeasedBlockEvent::uncharged_for_test(0, 0, bytes::Bytes::from_static(b"late")),
        };

        assert!(peer_event_if_active(false, active_event).is_some());
        assert!(peer_event_if_active(true, late_piece).is_none());
    }

    #[tokio::test]
    async fn last_peer_disconnect_preserves_partial_assembly() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let piece_length = u64::from(MAX_BLOCK_SIZE) * 2;
        let meta = TorrentMetaV1 {
            info_hash: [25; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "disconnect-partial.bin".into(),
            piece_length,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: piece_length,
                path: rt_path::SafeRelPath::from_name("disconnect-partial.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let peer_addr = "127.0.0.1:6881".parse().unwrap();
        let permits = Arc::new(tokio::sync::Semaphore::new(1));
        let (peer_id, _peer_cmd_rx) = task
            .register_peer(peer_addr, permits.acquire_owned().await.unwrap())
            .expect("peer registration should fit the memory budget");
        task.picker.availability.add_have(0);
        let request = task.picker.pick(&PieceBitmap::from_bools(&[true])).unwrap();
        task.record_piece_block(&BlockEvent {
            piece: request.piece,
            offset: request.begin,
            data: bytes::Bytes::from(vec![0xA5; request.length as usize]),
        })
        .await
        .unwrap();
        assert!(!task
            .picker
            .block_received(request.piece as usize, request.begin));

        task.handle_peer_event(PeerEvent::Disconnected {
            peer: peer_addr,
            id: peer_id,
            outstanding: vec![request],
        })
        .await;

        assert!(task.active_peers.is_empty());
        assert!(task.piece_assemblies.contains_key(&request.piece));
        assert_eq!(task.picker.partial_pieces(), vec![(request.piece, vec![0])]);
    }

    #[tokio::test]
    async fn stale_peer_events_cannot_mutate_a_reconnected_peer() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [18; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "peer-reconnect.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("peer-reconnect.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let peer_addr = "127.0.0.1:6881".parse().unwrap();
        let permits = Arc::new(tokio::sync::Semaphore::new(2));
        let (old_id, old_cmd_rx) = task
            .register_peer(
                peer_addr,
                Arc::clone(&permits).acquire_owned().await.unwrap(),
            )
            .expect("old peer registration should fit the memory budget");
        task.active_peers.remove(&peer_addr);
        drop(old_cmd_rx);
        let (new_id, mut new_cmd_rx) = task
            .register_peer(peer_addr, permits.acquire_owned().await.unwrap())
            .expect("new peer registration should fit the memory budget");
        assert_ne!(old_id, new_id);

        task.handle_peer_event(PeerEvent::Interested {
            peer: peer_addr,
            id: old_id,
        })
        .await;
        task.handle_peer_event(PeerEvent::Disconnected {
            peer: peer_addr,
            id: old_id,
            outstanding: Vec::new(),
        })
        .await;

        let current = task
            .active_peers
            .get(&peer_addr)
            .expect("stale disconnect removed the reconnected peer");
        assert_eq!(current.id, new_id);
        assert!(!current.interested);

        task.handle_peer_event(PeerEvent::Interested {
            peer: peer_addr,
            id: new_id,
        })
        .await;
        assert!(task.active_peers.get(&peer_addr).unwrap().interested);
        assert!(matches!(new_cmd_rx.try_recv(), Ok(PeerCommand::Unchoke)));
    }

    #[tokio::test]
    async fn disconnecting_an_unchoked_peer_immediately_fills_the_upload_slot() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [37; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "choker-disconnect.bin".into(),
            piece_length: 4,
            pieces: vec![[0; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("choker-disconnect.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::new(RwLock::new(SessionRegistry::new())),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let peer_count = DEFAULT_MAX_UNCHOKED + 2;
        let permits = Arc::new(tokio::sync::Semaphore::new(peer_count));
        let mut peer_ids = HashMap::new();
        let mut command_receivers = HashMap::new();
        for index in 0..peer_count {
            let peer_addr = format!("127.0.0.1:{}", 6881 + index as u16)
                .parse()
                .unwrap();
            let (peer_id, command_rx) = task
                .register_peer(
                    peer_addr,
                    Arc::clone(&permits)
                        .acquire_owned()
                        .await
                        .expect("peer permit"),
                )
                .expect("peer registration should fit the memory budget");
            peer_ids.insert(peer_addr, peer_id);
            command_receivers.insert(peer_addr, command_rx);
        }

        for (peer_addr, peer_id) in &peer_ids {
            task.handle_peer_event(PeerEvent::Interested {
                peer: *peer_addr,
                id: *peer_id,
            })
            .await;
        }

        let released_peer = task
            .active_peers
            .iter()
            .find(|(_, handle)| !handle.upload_choked)
            .map(|(addr, handle)| (*addr, handle.id))
            .expect("an interested peer should occupy an upload slot");
        let waiting_peer = task
            .active_peers
            .iter()
            .find(|(_, handle)| handle.interested && handle.upload_choked)
            .map(|(addr, _)| *addr)
            .expect("the extra interested peer should be waiting for a slot");

        task.handle_peer_event(PeerEvent::Disconnected {
            peer: released_peer.0,
            id: released_peer.1,
            outstanding: Vec::new(),
        })
        .await;

        assert!(!task.active_peers[&waiting_peer].upload_choked);
        assert!(matches!(
            command_receivers.get_mut(&waiting_peer).unwrap().try_recv(),
            Ok(PeerCommand::Unchoke)
        ));
    }

    #[tokio::test]
    async fn shutdown_peers_clears_picker_peer_state() {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let meta = TorrentMetaV1 {
            info_hash: [9; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: "sample.bin".into(),
            piece_length: 4,
            pieces: vec![[8; 20]],
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: 4,
                path: rt_path::SafeRelPath::from_name("sample.bin", false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = 4;
        entry.amount_left = 4;
        entry.transition(TorrentState::Downloading).unwrap();
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        let db = Arc::new(Mutex::new(conn));
        let (_cmd_tx, cmd_rx) = mpsc::channel(1);
        let mut task = TorrentTask::new(
            meta,
            temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::clone(&registry),
            DbExecutor::direct(Arc::clone(&db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            temp.path().join("fastresume"),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            StorageIoConfig::default(),
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;

        let peer_addr = "127.0.0.1:6881".parse().unwrap();
        let (peer_cmd_tx, _peer_cmd_rx) = mpsc::channel(1);
        let peer_permit = Arc::new(tokio::sync::Semaphore::new(1))
            .acquire_owned()
            .await
            .unwrap();
        task.picker.availability.add_bitfield(&[0x80]);
        task.picker.pick_from_seed().unwrap();
        let peer_has = PieceBitmap::from_bools(&[true]);
        let peer_have_count = peer_has.count_ones();
        let pending_have = PieceBitmap::new(1);
        let bitmap_memory_lease = task
            .resources
            .try_acquire(
                MemoryClass::PeerBuffer,
                peer_has
                    .memory_bytes()
                    .saturating_add(pending_have.memory_bytes())
                    .saturating_add(u64::try_from(std::mem::size_of::<usize>()).unwrap()),
            )
            .expect("test peer state should fit the memory budget");
        task.active_peers.insert(
            peer_addr,
            PeerHandle {
                id: PeerId::new(),
                transfer_conn: task
                    .transfer_ledger
                    .try_connect(PEER_REQUEST_PIPELINE_ADAPTIVE_MAX)
                    .unwrap(),
                plane: Plane::V1,
                cmd_tx: peer_cmd_tx,
                upload_control: RateLimitCancellation::default(),
                shutdown_control: RateLimitCancellation::default(),
                peer_task: None,
                peer_has,
                peer_have_count,
                choked: true,
                upload_choked: true,
                interested: false,
                downloaded: 0,
                uploaded: 0,
                upload_accounting: Arc::new(UploadAccountingState::new(
                    UPLOAD_ACCOUNTING_BATCH_BYTES,
                )),
                download_rate: 0.0,
                upload_rate: 0.0,
                download_rate_window: 0,
                upload_rate_window: 0,
                download_rate_window_started: Instant::now(),
                upload_rate_window_started: Instant::now(),
                outstanding: 0,
                download_generation: 0,
                requested: Vec::new(),
                ut_metadata_id: None,
                ut_pex_id: None,
                metadata_size: None,
                request_window: WindowController::new(WindowConfig {
                    initial: PEER_REQUEST_PIPELINE_NORMAL,
                    min: 4,
                    max: PEER_REQUEST_PIPELINE_ADAPTIVE_MAX,
                    ..WindowConfig::default()
                }),
                _peer_permit: peer_permit,
                _bitmap_memory_lease: bitmap_memory_lease,
                pending_have,
            },
        );

        let peer = task.active_peers.get_mut(&peer_addr).unwrap();
        assert_eq!(peer.peer_have_count, 1);
        peer.replace_peer_have(PieceBitmap::new(1));
        assert_eq!(peer.peer_have_count, 0);
        assert!(peer.add_peer_have(0));
        assert!(
            !peer.add_peer_have(0),
            "duplicate HAVE must not inflate the count"
        );
        assert!(!peer.add_peer_have(1), "out-of-range HAVE must be ignored");
        assert_eq!(peer.peer_have_count, 1);

        assert_eq!(task.picker.availability.count(0), 1);
        let upload_accounting = Arc::clone(&task.active_peers[&peer_addr].upload_accounting);
        upload_accounting
            .pending_uploaded_bytes
            .store(17, Ordering::Relaxed);
        task.shutdown_peers().await;

        assert!(task.active_peers.is_empty());
        assert_eq!(
            upload_accounting
                .pending_uploaded_bytes
                .load(Ordering::Relaxed),
            0
        );
        assert_eq!(
            registry
                .read()
                .await
                .get(&info_hash)
                .unwrap()
                .stats
                .uploaded,
            17
        );
        assert_eq!(task.picker.availability.count(0), 0);
        assert!(task.picker.pick_from_seed().is_some());
    }

    // ---- crash safety -------------------------------------------------------

    struct CrashFixture {
        temp: tempfile::TempDir,
        registry: Arc<RwLock<SessionRegistry>>,
        db: Arc<Mutex<Connection>>,
        info_hash: String,
        meta: TorrentMetaV1,
        data: Vec<u8>,
    }

    impl CrashFixture {
        fn payload_path(&self) -> PathBuf {
            self.temp.path().join(&self.meta.name)
        }

        fn write_payload(&self) {
            std::fs::write(self.payload_path(), &self.data).unwrap();
        }

        fn fastresume_dir(&self) -> PathBuf {
            self.temp.path().join("fastresume")
        }

        fn event_kinds(&self) -> Vec<String> {
            let db = self.db.lock().unwrap();
            let mut stmt = db
                .prepare("SELECT kind FROM session_events ORDER BY event_id")
                .unwrap();
            stmt.query_map([], |row| row.get::<_, String>(0))
                .unwrap()
                .map(Result::unwrap)
                .collect()
        }

        fn event_payload(&self, kind: &str) -> Option<serde_json::Value> {
            let db = self.db.lock().unwrap();
            db.query_row(
                "SELECT payload FROM session_events WHERE kind = ?1 ORDER BY event_id DESC LIMIT 1",
                [kind],
                |row| row.get::<_, String>(0),
            )
            .ok()
            .and_then(|payload| serde_json::from_str(&payload).ok())
        }
    }

    async fn crash_fixture(data: Vec<u8>, piece_length: u64, seed: u8) -> CrashFixture {
        let temp = tempfile::tempdir().unwrap();
        let conn = Connection::open_in_memory().unwrap();
        rt_db::migrate(&conn).unwrap();
        let name = format!("crash-{seed}.bin");
        let meta = TorrentMetaV1 {
            info_hash: [seed; 20],
            announce: None,
            announce_list: Vec::new(),
            webseeds: Vec::new(),
            comment: None,
            created_by: None,
            creation_date: None,
            name: name.clone(),
            piece_length,
            pieces: data
                .chunks(piece_length as usize)
                .map(|chunk| Sha1::digest(chunk).into())
                .collect(),
            files: vec![rt_metainfo::TorrentFileV1 {
                index: 0,
                length: data.len() as u64,
                path: rt_path::SafeRelPath::from_name(&name, false).unwrap(),
                offset: 0,
                pad: false,
            }],
            private: false,
            raw: Vec::new(),
        };
        let info_hash = hex::encode(meta.info_hash);
        let registry = Arc::new(RwLock::new(SessionRegistry::new()));
        let mut entry = rt_session::TorrentEntry::new(
            info_hash.clone(),
            meta.name.clone(),
            temp.path().to_string_lossy().into_owned(),
        );
        entry.total_length = data.len() as u64;
        entry.amount_left = data.len() as u64;
        entry.state = TorrentState::Downloading;
        persist_task_row(&conn, &entry, &meta);
        registry.write().await.add(entry).unwrap();
        CrashFixture {
            temp,
            registry,
            db: Arc::new(Mutex::new(conn)),
            info_hash,
            meta,
            data,
        }
    }

    async fn crash_task(
        fx: &CrashFixture,
        runtime: Arc<CrashSafetyRuntime>,
        io: StorageIoConfig,
    ) -> TorrentTask {
        let (task, cmd_tx) = crash_task_with_mailbox(fx, runtime, io).await;
        // Keep the mailbox open for the whole test: a disconnected command
        // channel makes a recheck report `Shutdown`.
        std::mem::forget(cmd_tx);
        task
    }

    async fn crash_task_with_mailbox(
        fx: &CrashFixture,
        runtime: Arc<CrashSafetyRuntime>,
        io: StorageIoConfig,
    ) -> (TorrentTask, mpsc::Sender<TorrentCmd>) {
        let (cmd_tx, cmd_rx) = mpsc::channel(4);
        let mut task = TorrentTask::new(
            fx.meta.clone(),
            fx.temp.path().to_path_buf(),
            false,
            TorrentState::Downloading,
            Arc::clone(&fx.registry),
            DbExecutor::direct(Arc::clone(&fx.db)),
            ResourceGovernor::new(rt_metrics::ResourceGovernorConfig::default()),
            cmd_rx,
            fx.fastresume_dir(),
            8,
            6881,
            10,
            10,
            60,
            1024 * 1024,
            io,
            false,
            OutboundEgressPolicy::default(),
            GlobalNetworkBudget::unlimited(),
            10_000,
            None,
        )
        .await;
        task.attach_crash_safety(runtime);
        (task, cmd_tx)
    }

    /// Settings for a test: defaults, except weak-mount escalation is off so
    /// the result does not depend on which filesystem the temp dir is on.
    fn settings(
        edit: impl FnOnce(&mut rt_config::CrashSafetyConfig),
    ) -> rt_config::CrashSafetyConfig {
        let mut config = rt_config::CrashSafetyConfig {
            weak_mount_escalation: false,
            ..rt_config::CrashSafetyConfig::default()
        };
        edit(&mut config);
        config
    }

    fn quiet_runtime() -> Arc<CrashSafetyRuntime> {
        let runtime = CrashSafetyRuntime::inert();
        runtime.apply_settings(settings(|_| {}), false);
        runtime
    }

    fn mark_all_have(task: &mut TorrentTask) {
        for piece in 0..task.piece_map.piece_count {
            task.picker.mark_have(piece as usize);
        }
    }

    async fn registry_entry(fx: &CrashFixture) -> TorrentEntry {
        fx.registry.read().await.get(&fx.info_hash).unwrap()
    }

    #[tokio::test]
    async fn completion_gate_holds_until_the_state_is_durable_then_releases() {
        let fx = crash_fixture(vec![7u8; 8], 4, 71).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);

        // Break persistence: a file where the fastresume directory should be.
        std::fs::write(fx.fastresume_dir(), b"in the way").unwrap();

        task.on_download_complete().await;

        // Held: still downloading, one byte remaining, no completion stamp.
        assert!(task.completion_gate.is_some());
        assert_eq!(task.reported_bytes_left(), 1);
        let entry = registry_entry(&fx).await;
        assert_eq!(entry.state, TorrentState::Downloading);
        assert_eq!(entry.amount_left, 1, "API must not see a finished torrent");
        assert!(entry.finalizing, "the hold is published explicitly");
        assert_eq!(entry.completed_at, None);
        assert_eq!(runtime.counters().completions_pending, 1);
        assert!(fx.event_kinds().contains(&"completion_deferred".to_owned()));

        // Storage recovers; the next attempt releases the completion.
        std::fs::remove_file(fx.fastresume_dir()).unwrap();
        task.completion_gate.as_mut().unwrap().next_attempt = Instant::now();
        assert!(matches!(
            task.advance_completion_gate().await,
            GateStep::Released
        ));
        let entry = registry_entry(&fx).await;
        assert_eq!(entry.state, TorrentState::Seeding);
        assert_eq!(entry.amount_left, 0);
        assert!(!entry.finalizing, "released torrents are not finalizing");
        assert!(entry.completed_at.is_some());
        let counters = runtime.counters();
        assert_eq!(counters.completions_pending, 0);
        assert_eq!(counters.completions_released, 1);
        assert!(counters.completion_gate_retries >= 1);
        assert!(fx.event_kinds().contains(&"completion_released".to_owned()));
    }

    #[tokio::test]
    async fn gate_retry_is_rate_limited_by_its_backoff() {
        let fx = crash_fixture(vec![7u8; 8], 4, 72).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        std::fs::write(fx.fastresume_dir(), b"in the way").unwrap();
        task.on_download_complete().await;
        let first_retry = task.completion_gate.as_ref().unwrap().next_attempt;
        assert!(
            first_retry > Instant::now(),
            "backoff must be in the future"
        );

        // Called again before the deadline: no new attempt is made.
        assert!(matches!(
            task.advance_completion_gate().await,
            GateStep::Pending
        ));
        assert_eq!(task.completion_gate.as_ref().unwrap().attempts, 1);
    }

    #[tokio::test]
    async fn gate_is_dropped_when_the_torrent_stops_being_complete() {
        let fx = crash_fixture(vec![7u8; 8], 4, 73).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        std::fs::write(fx.fastresume_dir(), b"in the way").unwrap();
        task.on_download_complete().await;
        assert_eq!(runtime.counters().completions_pending, 1);

        task.picker.reject_piece(0);
        task.completion_gate.as_mut().unwrap().next_attempt = Instant::now();
        assert!(matches!(
            task.advance_completion_gate().await,
            GateStep::Dropped
        ));
        assert!(task.completion_gate.is_none());
        assert_eq!(runtime.counters().completions_pending, 0);
        assert_ne!(task.reported_bytes_left(), 1 - 1, "real bytes remain");
    }

    #[tokio::test]
    async fn disabling_the_gate_restores_immediate_completion() {
        let fx = crash_fixture(vec![7u8; 8], 4, 74).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        runtime.apply_settings(settings(|c| c.completion_gate = false), true);
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        // Even with persistence broken, the historical behavior completes.
        std::fs::write(fx.fastresume_dir(), b"in the way").unwrap();
        task.on_download_complete().await;
        assert!(task.completion_gate.is_none());
        let entry = registry_entry(&fx).await;
        assert_eq!(entry.state, TorrentState::Seeding);
        assert_eq!(entry.amount_left, 0);
        assert_eq!(runtime.counters().completions_gated, 0);
    }

    #[tokio::test]
    async fn fast_mode_state_is_unsynced_and_discarded_only_after_a_host_crash() {
        let fx = crash_fixture(vec![9u8; 8], 4, 75).await;
        fx.write_payload();
        let fast = StorageIoConfig {
            durability_mode: rt_storage::DurabilityMode::Fast,
            ..StorageIoConfig::default()
        };
        let mut writer = crash_task(&fx, quiet_runtime(), fast.clone()).await;
        mark_all_have(&mut writer);
        writer.save_fastresume(false).await;
        let saved = FastresumeStore::new(fx.fastresume_dir())
            .load(&fx.info_hash)
            .unwrap();
        assert!(saved.clean_shutdown);
        assert!(
            !saved.durability.synced,
            "fast mode must not claim a data sync"
        );

        for (verdict, trusted) in [
            (PreviousRun::Clean, true),
            (PreviousRun::NoRecord, true),
            (PreviousRun::ProcessCrash, true),
            (PreviousRun::HostCrash, false),
            (PreviousRun::UncleanUnknownCause, false),
        ] {
            let runtime = CrashSafetyRuntime::for_test(
                rt_config::CrashSafetyConfig::default(),
                verdict,
                Some(crash_safety::unix_seconds()),
                42,
            );
            let mut reader = crash_task(&fx, runtime, fast.clone()).await;
            assert_eq!(
                reader.restore_fastresume().await,
                trusted,
                "fast-mode state after {verdict:?}"
            );
        }
    }

    #[tokio::test]
    async fn orderly_shutdown_makes_fast_mode_state_durable() {
        // Fast mode never syncs between saves, but a clean exit must still
        // leave a record backed by durable data: the run marker will call the
        // exit clean, so nothing would recheck it after a power cut a moment
        // later.
        let fx = crash_fixture(vec![9u8; 8], 4, 131).await;
        fx.write_payload();
        let fast = StorageIoConfig {
            durability_mode: rt_storage::DurabilityMode::Fast,
            ..StorageIoConfig::default()
        };
        // An earlier run left an unsynced fast-mode record.
        let mut earlier = crash_task(&fx, quiet_runtime(), fast.clone()).await;
        mark_all_have(&mut earlier);
        earlier.save_fastresume(false).await;
        let store = FastresumeStore::new(fx.fastresume_dir());
        assert!(!store.load(&fx.info_hash).unwrap().durability.synced);

        // This run restores it, then shuts down in an orderly way.
        let (task, cmd_tx) = crash_task_with_mailbox(&fx, quiet_runtime(), fast).await;
        let handle = tokio::spawn(task.run());
        // Let it reach steady state before asking it to stop.
        timeout(Duration::from_secs(2), async {
            loop {
                if registry_entry(&fx).await.state == TorrentState::Seeding {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("torrent did not start seeding");
        cmd_tx.send(TorrentCmd::Shutdown).await.unwrap();
        timeout(Duration::from_secs(2), handle)
            .await
            .expect("task did not stop")
            .unwrap();

        let after = store.load(&fx.info_hash).unwrap();
        assert!(after.clean_shutdown);
        assert!(
            after.durability.synced,
            "an orderly exit must run a real barrier even in fast mode"
        );
    }

    #[tokio::test]
    async fn a_forced_barrier_makes_fast_mode_state_synced() {
        let fx = crash_fixture(vec![9u8; 8], 4, 76).await;
        fx.write_payload();
        let fast = StorageIoConfig {
            durability_mode: rt_storage::DurabilityMode::Fast,
            ..StorageIoConfig::default()
        };
        let mut task = crash_task(&fx, quiet_runtime(), fast).await;
        mark_all_have(&mut task);
        let outcome = task.save_fastresume_with(false, true).await;
        assert_eq!(outcome.barrier, BarrierOutcome::Synced);
        assert!(outcome.persisted);
        assert!(
            FastresumeStore::new(fx.fastresume_dir())
                .load(&fx.info_hash)
                .unwrap()
                .durability
                .synced
        );
    }

    #[tokio::test]
    async fn recent_write_window_rechecks_only_torrents_written_shortly_before_the_crash() {
        let fx = crash_fixture(vec![3u8; 8], 4, 77).await;
        fx.write_payload();
        let crash_at = 1_000_000u64;
        for (last_write, expect_trusted) in [
            (crash_at - 60, false),        // a minute before the crash
            (crash_at - 86_400 - 1, true), // just outside the 24 h window
            (0, true),                     // undatable: not treated as recent
        ] {
            let mut writer = crash_task(&fx, quiet_runtime(), StorageIoConfig::default()).await;
            mark_all_have(&mut writer);
            writer
                .last_data_write_unix
                .store(last_write, std::sync::atomic::Ordering::Relaxed);
            writer.save_fastresume(false).await;

            let runtime = CrashSafetyRuntime::for_test(
                settings(|_| {}),
                PreviousRun::HostCrash,
                Some(crash_at),
                42,
            );
            let mut reader =
                crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
            assert_eq!(
                reader.restore_fastresume().await,
                expect_trusted,
                "last write {last_write}"
            );
            if !expect_trusted {
                assert_eq!(runtime.counters().rechecks_recent_write, 1);
                assert!(fx
                    .event_kinds()
                    .contains(&"crash_recovery_recheck".to_owned()));
            }
        }
    }

    #[tokio::test]
    async fn full_policy_and_weak_mounts_recheck_regardless_of_write_time() {
        let fx = crash_fixture(vec![3u8; 8], 4, 78).await;
        fx.write_payload();
        let mut writer = crash_task(&fx, quiet_runtime(), StorageIoConfig::default()).await;
        mark_all_have(&mut writer);
        writer.save_fastresume(false).await; // undated: "recent" would trust it

        let full = CrashSafetyRuntime::for_test(
            settings(|c| c.host_crash_recovery = rt_config::HostCrashRecovery::Full),
            PreviousRun::HostCrash,
            Some(1_000_000),
            42,
        );
        let mut reader = crash_task(&fx, Arc::clone(&full), StorageIoConfig::default()).await;
        assert!(!reader.restore_fastresume().await);
        assert_eq!(full.counters().rechecks_full_policy, 1);

        let watermark_weak = CrashSafetyRuntime::for_test(
            settings(|c| {
                c.host_crash_recovery = rt_config::HostCrashRecovery::Watermark;
                c.weak_mount_escalation = true;
                c.weak_mount_paths = vec![fx.temp.path().to_path_buf()];
            }),
            PreviousRun::HostCrash,
            Some(1_000_000),
            42,
        );
        let mut reader =
            crash_task(&fx, Arc::clone(&watermark_weak), StorageIoConfig::default()).await;
        assert!(!reader.restore_fastresume().await);
        assert_eq!(watermark_weak.counters().rechecks_weak_mount, 1);
    }

    fn location_policy(
        path: &std::path::Path,
        edit: impl FnOnce(&mut rt_config::PathPolicy),
    ) -> rt_config::PathPolicy {
        let mut policy = rt_config::PathPolicy {
            path: path.to_path_buf(),
            ..rt_config::PathPolicy::default()
        };
        edit(&mut policy);
        policy
    }

    #[tokio::test]
    async fn a_location_policy_can_turn_the_gate_off_for_that_location_only() {
        // Global gate stays on; the matching location opts out.
        let fx = crash_fixture(vec![7u8; 8], 4, 90).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        runtime.apply_settings(
            settings(|c| {
                c.path_policies = vec![location_policy(fx.temp.path(), |p| {
                    p.completion_gate = Some(false);
                })];
            }),
            true,
        );
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        std::fs::write(fx.fastresume_dir(), b"in the way").unwrap();
        task.on_download_complete().await;
        assert!(task.completion_gate.is_none());
        assert_eq!(registry_entry(&fx).await.state, TorrentState::Seeding);

        // A policy for some other location leaves this torrent gated.
        let fx = crash_fixture(vec![7u8; 8], 4, 91).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        runtime.apply_settings(
            settings(|c| {
                c.path_policies = vec![location_policy(
                    std::path::Path::new("/srv/elsewhere"),
                    |p| {
                        p.completion_gate = Some(false);
                    },
                )];
            }),
            true,
        );
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        std::fs::write(fx.fastresume_dir(), b"in the way").unwrap();
        task.on_download_complete().await;
        assert!(task.completion_gate.is_some(), "still held");
        assert_eq!(registry_entry(&fx).await.amount_left, 1);
    }

    #[tokio::test]
    async fn a_location_policy_can_require_read_back_where_the_default_does_not() {
        let fx = crash_fixture((0..32u8).collect(), 8, 92).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        runtime.apply_settings(
            settings(|c| {
                c.completion_verify = rt_config::CompletionVerifyMode::Off;
                c.path_policies = vec![location_policy(fx.temp.path(), |p| {
                    p.completion_verify = Some(rt_config::CompletionVerifyMode::Full);
                })];
            }),
            true,
        );
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        task.on_download_complete().await;
        assert_eq!(task.completion_verify_plan, Some(VerifyPlan::Full));
    }

    #[tokio::test]
    async fn a_location_policy_sets_its_own_sample_size() {
        let fx = crash_fixture((0..64u8).collect(), 8, 93).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        runtime.apply_settings(
            settings(|c| {
                c.completion_verify = rt_config::CompletionVerifyMode::Sample;
                c.completion_verify_sample_percent = 1;
                c.path_policies = vec![location_policy(fx.temp.path(), |p| {
                    p.completion_verify_sample_percent = Some(100);
                })];
            }),
            true,
        );
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        task.on_download_complete().await;
        let (_tx, mut cmd_rx) = mpsc::channel(4);
        let mut pending = None;
        assert!(task.drive_crash_safety(&mut cmd_rx, &mut pending).await);
        assert_eq!(
            runtime.counters().completion_verify_pieces,
            8,
            "the location's 100% sample covers every piece, not the global 1%"
        );
    }

    #[tokio::test]
    async fn a_location_policy_can_demand_full_recovery_under_a_watermark_default() {
        let fx = crash_fixture(vec![3u8; 8], 4, 94).await;
        fx.write_payload();
        let mut writer = crash_task(&fx, quiet_runtime(), StorageIoConfig::default()).await;
        mark_all_have(&mut writer);
        writer.save_fastresume(false).await;

        let host_crash = |policies: Vec<rt_config::PathPolicy>| {
            CrashSafetyRuntime::for_test(
                settings(|c| {
                    c.host_crash_recovery = rt_config::HostCrashRecovery::Watermark;
                    c.path_policies = policies;
                }),
                PreviousRun::HostCrash,
                Some(1_000_000),
                42,
            )
        };

        let strict = host_crash(vec![location_policy(fx.temp.path(), |p| {
            p.host_crash_recovery = Some(rt_config::HostCrashRecovery::Full);
        })]);
        let mut reader = crash_task(&fx, Arc::clone(&strict), StorageIoConfig::default()).await;
        assert!(!reader.restore_fastresume().await);
        assert_eq!(strict.counters().rechecks_full_policy, 1);

        let unrelated = host_crash(vec![location_policy(
            std::path::Path::new("/srv/elsewhere"),
            |p| {
                p.host_crash_recovery = Some(rt_config::HostCrashRecovery::Full);
            },
        )]);
        let mut reader = crash_task(&fx, Arc::clone(&unrelated), StorageIoConfig::default()).await;
        assert!(
            reader.restore_fastresume().await,
            "the watermark default still trusts synced state here"
        );
        assert_eq!(unrelated.counters().recovery_rechecks, 0);
    }

    #[tokio::test]
    async fn state_saved_by_the_current_run_is_never_rejudged_against_an_old_crash() {
        let fx = crash_fixture(vec![3u8; 8], 4, 79).await;
        fx.write_payload();
        let runtime = CrashSafetyRuntime::for_test(
            settings(|c| c.host_crash_recovery = rt_config::HostCrashRecovery::Full),
            PreviousRun::HostCrash,
            Some(1_000_000),
            555,
        );
        let mut writer = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut writer);
        writer.save_fastresume(false).await;
        let mut reader = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        assert!(
            reader.restore_fastresume().await,
            "a record written this run post-dates the crash"
        );
        assert_eq!(runtime.counters().recovery_rechecks, 0);
    }

    #[tokio::test]
    async fn watermark_policy_trusts_synced_state_after_a_host_crash() {
        let fx = crash_fixture(vec![3u8; 8], 4, 80).await;
        fx.write_payload();
        let mut writer = crash_task(&fx, quiet_runtime(), StorageIoConfig::default()).await;
        mark_all_have(&mut writer);
        writer
            .last_data_write_unix
            .store(999_990, std::sync::atomic::Ordering::Relaxed);
        writer.save_fastresume(false).await;
        let runtime = CrashSafetyRuntime::for_test(
            settings(|c| c.host_crash_recovery = rt_config::HostCrashRecovery::Watermark),
            PreviousRun::HostCrash,
            Some(1_000_000),
            42,
        );
        let mut reader = crash_task(&fx, runtime, StorageIoConfig::default()).await;
        assert!(reader.restore_fastresume().await);
        assert!(reader.picker.is_complete());
    }

    /// The scenario that motivated all of this: a preallocated, never-written
    /// file whose resume state claims every piece is valid.
    #[cfg(target_os = "linux")]
    #[tokio::test]
    async fn allocation_audit_distrusts_valid_pieces_over_unwritten_preallocation() {
        use std::os::fd::AsRawFd;

        // Use the working directory's filesystem; /tmp is often tmpfs.
        let data = vec![0xC3u8; 4 << 20];
        let mut fx = crash_fixture(data, 1 << 20, 81).await;
        fx.temp = tempfile::Builder::new()
            .prefix("crash-audit-")
            .tempdir_in(std::env::current_dir().unwrap())
            .unwrap();
        let fs_type = rt_storage::detect_storage_topology(fx.temp.path()).fs_type;
        if !matches!(fs_type.as_deref(), Some("ext4" | "xfs" | "btrfs")) {
            eprintln!("fs {fs_type:?} does not expose unwritten extents; skipping");
            return;
        }
        // Full-size file reserved with fallocate but never written.
        let file = std::fs::File::create(fx.payload_path()).unwrap();
        let rc = unsafe { libc::fallocate(file.as_raw_fd(), 0, 0, fx.data.len() as libc::off_t) };
        assert_eq!(rc, 0);
        file.sync_all().unwrap();
        drop(file);

        // A resume record that claims everything is valid, with matching file
        // hints so the hint check alone cannot save us.
        let mut state = FastresumeState::new_empty(
            &fx.meta.info_hash,
            fx.meta.pieces.len() as u32,
            ImportPolicy::RequireVerification,
        );
        state.clean_shutdown = true;
        state.pieces = vec![PieceState::Valid; fx.meta.pieces.len()];
        state.file_hints = collect_file_hints(fx.temp.path(), &fx.meta);
        FastresumeStore::new(fx.fastresume_dir())
            .save(&state)
            .unwrap();

        // Audit on: the claim is rejected without reading any payload.
        let runtime =
            CrashSafetyRuntime::for_test(settings(|_| {}), PreviousRun::ProcessCrash, None, 42);
        let mut reader = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        assert!(reader.restore_fastresume().await);
        assert_eq!(
            (0..fx.meta.pieces.len())
                .filter(|p| reader.picker.have_piece(*p))
                .count(),
            0,
            "unwritten preallocation must not be trusted as valid data"
        );
        assert_eq!(runtime.counters().audit_pieces_downgraded, 4);
        assert!(fx
            .event_kinds()
            .contains(&"allocation_audit_downgraded".to_owned()));

        // Audit off: the historical behavior trusts the record (documenting
        // exactly what the audit prevents).
        let off = CrashSafetyRuntime::for_test(
            settings(|c| c.structural_audit = rt_config::StructuralAuditMode::Off),
            PreviousRun::ProcessCrash,
            None,
            43,
        );
        let mut reader = crash_task(&fx, off, StorageIoConfig::default()).await;
        assert!(reader.restore_fastresume().await);
        assert!(reader.picker.is_complete());

        // A clean previous run skips the on-unclean audit.
        let clean = CrashSafetyRuntime::for_test(settings(|_| {}), PreviousRun::Clean, None, 44);
        let mut reader = crash_task(&fx, clean, StorageIoConfig::default()).await;
        assert!(reader.restore_fastresume().await);
        assert!(reader.picker.is_complete());

        // `always` audits even a clean start.
        let always = CrashSafetyRuntime::for_test(
            settings(|c| c.structural_audit = rt_config::StructuralAuditMode::Always),
            PreviousRun::Clean,
            None,
            45,
        );
        let mut reader = crash_task(&fx, always, StorageIoConfig::default()).await;
        assert!(reader.restore_fastresume().await);
        assert!(!reader.picker.is_complete());
    }

    #[cfg(target_os = "linux")]
    #[tokio::test]
    async fn allocation_audit_leaves_fully_written_files_alone() {
        let fx = crash_fixture(vec![0x5Au8; 1 << 20], 1 << 18, 82).await;
        fx.write_payload();
        std::fs::File::open(fx.payload_path())
            .unwrap()
            .sync_all()
            .unwrap();
        let mut state = FastresumeState::new_empty(
            &fx.meta.info_hash,
            fx.meta.pieces.len() as u32,
            ImportPolicy::RequireVerification,
        );
        state.clean_shutdown = true;
        state.pieces = vec![PieceState::Valid; fx.meta.pieces.len()];
        state.file_hints = collect_file_hints(fx.temp.path(), &fx.meta);
        FastresumeStore::new(fx.fastresume_dir())
            .save(&state)
            .unwrap();
        let runtime = CrashSafetyRuntime::for_test(
            settings(|c| c.structural_audit = rt_config::StructuralAuditMode::Always),
            PreviousRun::HostCrash,
            None,
            46,
        );
        // Watermark keeps the recovery decision out of the way so only the
        // audit is under test.
        runtime.apply_settings(
            settings(|c| {
                c.structural_audit = rt_config::StructuralAuditMode::Always;
                c.host_crash_recovery = rt_config::HostCrashRecovery::Watermark;
            }),
            true,
        );
        let mut reader = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        assert!(reader.restore_fastresume().await);
        assert!(reader.picker.is_complete());
        assert_eq!(runtime.counters().audit_pieces_downgraded, 0);
    }

    #[test]
    fn completion_sample_always_covers_file_boundaries_and_is_deterministic() {
        let files = vec![
            rt_piece_map::FileSpan {
                file_index: 0,
                path: rt_path::SafeRelPath::from_name("a.bin", false).unwrap(),
                content_offset: 0,
                length: 100 * 64,
            },
            rt_piece_map::FileSpan {
                file_index: 1,
                path: rt_path::SafeRelPath::from_name("b.bin", false).unwrap(),
                content_offset: 100 * 64,
                length: 100 * 64,
            },
        ];
        let map = PieceMap::new(64, files).unwrap();
        assert_eq!(map.piece_count, 200);
        let meta_files = [(0u32, 100u64 * 64, false), (1u32, 100u64 * 64, false)];

        let a = select_completion_sample(&map, &meta_files, 5, 1234).unwrap();
        let b = select_completion_sample(&map, &meta_files, 5, 1234).unwrap();
        assert_eq!(a, b, "same seed, same sample");
        assert_ne!(
            a,
            select_completion_sample(&map, &meta_files, 5, 999).unwrap()
        );
        for boundary in [0u32, 99, 100, 199] {
            assert!(
                a.contains(&boundary),
                "boundary piece {boundary} missing: {a:?}"
            );
        }
        assert!(a.len() >= 10 && a.len() < 200);
        assert!(a.windows(2).all(|w| w[0] < w[1]), "sorted and distinct");

        assert_eq!(select_completion_sample(&map, &meta_files, 100, 1), None);
        // 99% of 200 pieces is still a sample (198 pieces), not everything.
        assert_eq!(
            select_completion_sample(&map, &meta_files, 99, 1).map(|s| s.len()),
            Some(198)
        );

        // A sample that would cover every piece degrades to a full check.
        let small = vec![rt_piece_map::FileSpan {
            file_index: 0,
            path: rt_path::SafeRelPath::from_name("s.bin", false).unwrap(),
            content_offset: 0,
            length: 10 * 64,
        }];
        let small_map = PieceMap::new(64, small).unwrap();
        assert_eq!(
            select_completion_sample(&small_map, &[(0, 10 * 64, false)], 95, 1),
            None
        );
    }

    #[test]
    fn completion_sample_skips_pad_files_and_respects_the_cap() {
        let files = vec![
            rt_piece_map::FileSpan {
                file_index: 0,
                path: rt_path::SafeRelPath::from_name("real.bin", false).unwrap(),
                content_offset: 0,
                length: 64,
            },
            rt_piece_map::FileSpan {
                file_index: 1,
                path: rt_path::SafeRelPath::from_name("pad.bin", false).unwrap(),
                content_offset: 64,
                length: 64,
            },
        ];
        let map = PieceMap::new(64, files).unwrap();
        let meta_files = [(0u32, 64u64, false), (1u32, 64u64, true)];
        let sample = select_completion_sample(&map, &meta_files, 1, 5).unwrap();
        assert_eq!(sample, vec![0], "pad file boundaries are not sampled");

        let big = vec![rt_piece_map::FileSpan {
            file_index: 0,
            path: rt_path::SafeRelPath::from_name("huge.bin", false).unwrap(),
            content_offset: 0,
            length: 64 * 200_000,
        }];
        let map = PieceMap::new(64, big).unwrap();
        let sample = select_completion_sample(&map, &[(0, 64 * 200_000, false)], 90, 1).unwrap();
        assert!(sample.len() <= MAX_COMPLETION_SAMPLE_PIECES);
    }

    #[tokio::test]
    async fn sample_verification_releases_a_download_that_reads_back_clean() {
        let fx = crash_fixture((0..64u8).collect(), 8, 83).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        runtime.apply_settings(
            settings(|c| {
                c.completion_verify = rt_config::CompletionVerifyMode::Sample;
                c.completion_verify_sample_percent = 25;
            }),
            true,
        );
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);

        task.on_download_complete().await;
        // Barrier done; verification is queued, completion still held back.
        assert_eq!(task.completion_verify_plan, Some(VerifyPlan::Sample));
        assert_eq!(registry_entry(&fx).await.state, TorrentState::Downloading);
        assert_eq!(registry_entry(&fx).await.amount_left, 1);
        assert!(registry_entry(&fx).await.finalizing);

        let (_tx, mut cmd_rx) = mpsc::channel(4);
        let mut pending = None;
        assert!(task.drive_crash_safety(&mut cmd_rx, &mut pending).await);

        let entry = registry_entry(&fx).await;
        assert_eq!(entry.state, TorrentState::Seeding);
        assert_eq!(entry.amount_left, 0);
        assert!(entry.completed_at.is_some());
        assert!(fx.event_kinds().contains(&"completion_verified".to_owned()));
        let counters = runtime.counters();
        assert!(counters.completion_verify_pieces > 0);
        assert!(
            counters.completion_verify_pieces < 8,
            "a sample, not everything"
        );
        assert_eq!(counters.completion_verify_failures, 0);
        assert_eq!(task.reported_bytes_left(), 0);
    }

    #[tokio::test]
    async fn sample_verification_catches_corruption_and_escalates_to_a_full_recheck() {
        let fx = crash_fixture((0..64u8).collect(), 8, 84).await;
        // The bytes on disk differ from what the metainfo hashes describe:
        // the first piece was "written" but never reached the platter.
        let mut on_disk = fx.data.clone();
        on_disk[..8].fill(0);
        std::fs::write(fx.payload_path(), &on_disk).unwrap();
        let runtime = quiet_runtime();
        runtime.apply_settings(
            settings(|c| {
                c.completion_verify = rt_config::CompletionVerifyMode::Sample;
                c.completion_verify_sample_percent = 10;
            }),
            true,
        );
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);

        task.on_download_complete().await;
        let (_tx, mut cmd_rx) = mpsc::channel(4);
        let mut pending = None;
        assert!(task.drive_crash_safety(&mut cmd_rx, &mut pending).await);

        // Piece 0 is a file-boundary piece, so it is always sampled.
        let entry = registry_entry(&fx).await;
        assert_eq!(entry.state, TorrentState::Downloading, "not handed to arr");
        assert_eq!(entry.completed_at, None);
        assert!(!task.picker.have_piece(0));
        assert!(fx
            .event_kinds()
            .contains(&"completion_verify_failed".to_owned()));
        assert_eq!(runtime.counters().completion_verify_failures, 1);
        assert!(
            task.escalate_full_recheck,
            "a failed sample proves storage lied"
        );

        // The escalation runs the full recheck and finds the same single hole.
        assert!(task.drive_crash_safety(&mut cmd_rx, &mut pending).await);
        assert!(!task.escalate_full_recheck);
        assert!(!task.picker.have_piece(0));
        assert!((1..8).all(|p| task.picker.have_piece(p)));
    }

    #[tokio::test]
    async fn full_verification_rereads_every_piece() {
        let fx = crash_fixture((0..32u8).collect(), 8, 85).await;
        fx.write_payload();
        let runtime = quiet_runtime();
        runtime.apply_settings(
            settings(|c| c.completion_verify = rt_config::CompletionVerifyMode::Full),
            true,
        );
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        task.on_download_complete().await;
        assert_eq!(task.completion_verify_plan, Some(VerifyPlan::Full));
        let (_tx, mut cmd_rx) = mpsc::channel(4);
        let mut pending = None;
        assert!(task.drive_crash_safety(&mut cmd_rx, &mut pending).await);
        assert_eq!(registry_entry(&fx).await.state, TorrentState::Seeding);
        assert_eq!(runtime.counters().completion_verify_pieces, 4);
    }

    #[tokio::test]
    async fn recheck_of_an_already_completed_torrent_reports_an_integrity_regression() {
        let fx = crash_fixture((0..32u8).collect(), 8, 86).await;
        let mut on_disk = fx.data.clone();
        on_disk[8..16].fill(0); // piece 1 lost its data
        std::fs::write(fx.payload_path(), &on_disk).unwrap();
        {
            let mut registry = fx.registry.write().await;
            let mut entry = registry.get_mut(&fx.info_hash).unwrap();
            entry.state = TorrentState::Seeding;
            entry.completed_at = Some(1_700_000_000);
            entry.amount_left = 0;
        }
        let runtime = quiet_runtime();
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);

        assert!(matches!(
            task.run_recheck(None).await,
            RecheckOutcome::Complete
        ));

        assert_eq!(registry_entry(&fx).await.state, TorrentState::Downloading);
        assert_eq!(runtime.counters().integrity_regressions, 1);
        let payload = fx
            .event_payload("integrity_regression")
            .expect("event recorded");
        assert_eq!(payload["invalid_pieces"], 1);
        assert_eq!(payload["sample_pieces"], serde_json::json!([1]));
        assert_eq!(payload["trigger"], "recheck");
        let files = payload["affected_files"].as_array().unwrap();
        assert_eq!(files.len(), 1);
        assert!(files[0].as_str().unwrap().ends_with("crash-86.bin"));
    }

    #[tokio::test]
    async fn recheck_of_a_torrent_never_reported_complete_is_not_a_regression() {
        let fx = crash_fixture((0..32u8).collect(), 8, 87).await;
        let mut on_disk = fx.data.clone();
        on_disk[8..16].fill(0);
        std::fs::write(fx.payload_path(), &on_disk).unwrap();
        let runtime = quiet_runtime();
        let mut task = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        mark_all_have(&mut task);
        assert!(matches!(
            task.run_recheck(None).await,
            RecheckOutcome::Complete
        ));
        assert_eq!(runtime.counters().integrity_regressions, 0);
        assert!(!fx
            .event_kinds()
            .contains(&"integrity_regression".to_owned()));
    }

    #[tokio::test]
    async fn dormant_promotion_after_recovery_does_not_recheck_again() {
        // A torrent recovered at startup re-saves its state during this run.
        // Promoting it again later must trust that record, not repeat the
        // crash recovery.
        let fx = crash_fixture(vec![3u8; 8], 4, 88).await;
        fx.write_payload();
        let runtime = CrashSafetyRuntime::for_test(
            settings(|c| c.host_crash_recovery = rt_config::HostCrashRecovery::Full),
            PreviousRun::HostCrash,
            Some(1_000_000),
            700,
        );
        // Stale record from the crashed run (run id 1, not synced).
        let mut old =
            FastresumeState::new_empty(&fx.meta.info_hash, 2, ImportPolicy::RequireVerification);
        old.clean_shutdown = true;
        old.pieces = vec![PieceState::Valid; 2];
        old.durability.saved_by_run_id = 1;
        FastresumeStore::new(fx.fastresume_dir())
            .save(&old)
            .unwrap();

        let mut first = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        assert!(!first.restore_fastresume().await, "recovery rechecks it");
        assert_eq!(runtime.counters().recovery_rechecks, 1);

        // The recheck completes and re-saves under this run's id.
        mark_all_have(&mut first);
        first.save_fastresume(true).await;

        let mut promoted = crash_task(&fx, Arc::clone(&runtime), StorageIoConfig::default()).await;
        assert!(promoted.restore_fastresume().await);
        assert_eq!(runtime.counters().recovery_rechecks, 1, "no second recheck");
    }

    // ---- power-cut model ----------------------------------------------------
    //
    // A userspace test cannot drop the page cache, so it models it. `DiskModel`
    // tracks two images of the payload file: `live` (what a running process
    // reads, page cache included) and `durable` (what survives a power cut).
    // A write updates only `live`; a *successful payload barrier* copies `live`
    // into `durable`. After every step of a randomized walk the test "cuts the
    // power": it rebuilds the data file from `durable`, keeps the fastresume
    // record exactly as it was on disk (records are fsynced atomically), lets
    // the loader decide what to trust, and checks that every piece the loader
    // would serve really hashes correctly against the durable bytes.

    const MODEL_PIECE_LEN: usize = 8;
    const MODEL_PIECES: usize = 8;

    struct DiskModel {
        live: Vec<u8>,
        durable: Vec<u8>,
    }

    impl DiskModel {
        fn new() -> Self {
            DiskModel {
                live: vec![0; MODEL_PIECE_LEN * MODEL_PIECES],
                durable: vec![0; MODEL_PIECE_LEN * MODEL_PIECES],
            }
        }

        fn write_piece(&mut self, piece: usize, data: &[u8]) {
            let start = piece * MODEL_PIECE_LEN;
            self.live[start..start + MODEL_PIECE_LEN].copy_from_slice(data);
        }

        fn barrier(&mut self) {
            self.durable = self.live.clone();
        }
    }

    fn model_payload() -> Vec<u8> {
        (0..(MODEL_PIECE_LEN * MODEL_PIECES) as u32)
            .map(|i| (i * 31 + 7) as u8 | 1) // never zero: a lost write is visible
            .collect()
    }

    /// Cut the power: rebuild the payload from the durable image, keep the
    /// fastresume record, and return the pieces the loader would still trust
    /// even though their durable bytes are wrong.
    async fn cut_power_and_count_bad_trusted_pieces(
        fx: &CrashFixture,
        durable: &[u8],
        crash_verdict: PreviousRun,
        crash_settings: rt_config::CrashSafetyConfig,
        io: StorageIoConfig,
    ) -> Vec<usize> {
        // The post-crash machine: same metainfo, the durable payload, and the
        // fastresume file exactly as the process left it.
        let crashed = crash_fixture(
            fx.data.clone(),
            MODEL_PIECE_LEN as u64,
            fx.meta.info_hash[0],
        )
        .await;
        std::fs::write(crashed.payload_path(), durable).unwrap();
        std::fs::create_dir_all(crashed.fastresume_dir()).unwrap();
        if let Ok(dir) = std::fs::read_dir(fx.fastresume_dir()) {
            for entry in dir.flatten() {
                std::fs::copy(
                    entry.path(),
                    crashed.fastresume_dir().join(entry.file_name()),
                )
                .unwrap();
            }
        }
        // Adversarial: let the size/mtime/inode hints match the rebuilt file,
        // as they can by coincidence. The loader must be right regardless.
        let store = FastresumeStore::new(crashed.fastresume_dir());
        if let Ok(mut state) = store.load(&crashed.info_hash) {
            state.file_hints = collect_file_hints(crashed.temp.path(), &crashed.meta);
            store.save(&state).unwrap();
        }
        let runtime = CrashSafetyRuntime::for_test(
            crash_settings,
            crash_verdict,
            Some(crash_safety::unix_seconds()),
            9_999,
        );
        let mut reader = crash_task(&crashed, runtime, io).await;
        let mut bad = Vec::new();
        if reader.restore_fastresume().await {
            for (piece, expected) in crashed.meta.pieces.iter().enumerate() {
                if !reader.picker.have_piece(piece) {
                    continue;
                }
                let start = piece * MODEL_PIECE_LEN;
                let on_disk: [u8; 20] =
                    Sha1::digest(&durable[start..start + MODEL_PIECE_LEN]).into();
                if &on_disk != expected {
                    bad.push(piece);
                }
            }
        }
        bad
    }

    /// One randomized walk: write pieces, occasionally save, and cut the power
    /// after every step. Returns how many (step, piece) pairs the loader
    /// trusted although the durable bytes were wrong.
    async fn power_cut_walk(
        seed: u64,
        io: StorageIoConfig,
        crash_verdict: PreviousRun,
        crash_settings: rt_config::CrashSafetyConfig,
    ) -> usize {
        let payload = model_payload();
        let fx = crash_fixture(
            payload.clone(),
            MODEL_PIECE_LEN as u64,
            90 + (seed % 100) as u8,
        )
        .await;
        // Preallocated: full size, all zeros, exactly the failure's start state.
        std::fs::write(fx.payload_path(), vec![0u8; payload.len()]).unwrap();
        let mut task = crash_task(&fx, quiet_runtime(), io.clone()).await;
        let mut model = DiskModel::new();
        let mut rng = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) ^ 0xD1B5_4A32_D192_ED03;
        let mut violations = 0usize;

        for _ in 0..40 {
            match splitmix64(&mut rng) % 5 {
                // Receive and verify a piece: bytes reach the page cache only.
                0..=2 => {
                    let piece = (splitmix64(&mut rng) as usize) % MODEL_PIECES;
                    let start = piece * MODEL_PIECE_LEN;
                    let bytes = payload[start..start + MODEL_PIECE_LEN].to_vec();
                    task.write_block(&BlockEvent {
                        piece: piece as u32,
                        offset: 0,
                        data: bytes::Bytes::from(bytes.clone()),
                    })
                    .await
                    .unwrap();
                    model.write_piece(piece, &bytes);
                    task.picker.mark_have(piece);
                    task.dirty_pieces_since_barrier.insert(piece as u32);
                }
                // Periodic progress save (barrier depends on the durability mode).
                3 => {
                    let outcome = task.save_fastresume(false).await;
                    if outcome.barrier == BarrierOutcome::Synced {
                        model.barrier();
                    }
                }
                // Idle tick.
                _ => {}
            }
            violations += cut_power_and_count_bad_trusted_pieces(
                &fx,
                &model.durable,
                crash_verdict,
                crash_settings.clone(),
                io.clone(),
            )
            .await
            .len();
        }
        violations
    }

    #[tokio::test]
    async fn power_cut_after_a_synced_save_never_trusts_missing_data() {
        // Checkpoint mode: the barrier precedes every record, so whatever a
        // record claims was durable when it was written.
        for seed in 0..12 {
            let violations = power_cut_walk(
                seed,
                StorageIoConfig::default(),
                PreviousRun::HostCrash,
                settings(|c| c.host_crash_recovery = rt_config::HostCrashRecovery::Watermark),
            )
            .await;
            assert_eq!(
                violations, 0,
                "seed {seed}: trusted pieces missing from disk"
            );
        }
    }

    #[tokio::test]
    async fn power_cut_after_fast_mode_saves_is_safe_because_the_loader_discards_them() {
        // Fast mode never fsyncs, so records claim more than the disk holds.
        // Host-crash detection is what keeps that from being trusted.
        let fast = StorageIoConfig {
            durability_mode: rt_storage::DurabilityMode::Fast,
            ..StorageIoConfig::default()
        };
        for seed in 0..12 {
            let violations = power_cut_walk(
                seed,
                fast.clone(),
                PreviousRun::HostCrash,
                settings(|c| c.host_crash_recovery = rt_config::HostCrashRecovery::Watermark),
            )
            .await;
            assert_eq!(violations, 0, "seed {seed}");
        }
    }

    /// The harness must be able to fail. With crash detection disabled (the
    /// loader sees `NoRecord`) and Fast mode, this is exactly the behavior of
    /// a client that trusts its own resume state after a host crash: pieces the
    /// record claims but the disk never received are served as valid.
    #[tokio::test]
    async fn power_cut_model_detects_the_failure_when_protection_is_off() {
        let fast = StorageIoConfig {
            durability_mode: rt_storage::DurabilityMode::Fast,
            ..StorageIoConfig::default()
        };
        let mut total = 0;
        for seed in 0..12 {
            total +=
                power_cut_walk(seed, fast.clone(), PreviousRun::NoRecord, settings(|_| {})).await;
        }
        assert!(
            total > 0,
            "an unprotected client must trip the model, or the model proves nothing"
        );
    }

    #[tokio::test]
    async fn completion_is_never_reported_before_the_data_is_durable() {
        // Gate on (default): by the time the torrent is `Seeding` the
        // completing barrier has made every byte durable.
        for (gate, fast_mode, expect_durable) in [
            (true, false, true),
            (true, true, true), // the gate forces a real barrier even in fast mode
            (false, true, false), // historical behavior: reported complete, not durable
        ] {
            let payload = model_payload();
            let fx = crash_fixture(payload.clone(), MODEL_PIECE_LEN as u64, 120).await;
            std::fs::write(fx.payload_path(), vec![0u8; payload.len()]).unwrap();
            let io = StorageIoConfig {
                durability_mode: if fast_mode {
                    rt_storage::DurabilityMode::Fast
                } else {
                    rt_storage::DurabilityMode::Checkpoint
                },
                ..StorageIoConfig::default()
            };
            let runtime = CrashSafetyRuntime::inert();
            runtime.apply_settings(settings(|c| c.completion_gate = gate), true);
            let mut task = crash_task(&fx, runtime, io).await;
            let mut model = DiskModel::new();
            for piece in 0..MODEL_PIECES {
                let start = piece * MODEL_PIECE_LEN;
                let bytes = payload[start..start + MODEL_PIECE_LEN].to_vec();
                task.write_block(&BlockEvent {
                    piece: piece as u32,
                    offset: 0,
                    data: bytes::Bytes::from(bytes.clone()),
                })
                .await
                .unwrap();
                model.write_piece(piece, &bytes);
                task.picker.mark_have(piece);
                task.dirty_pieces_since_barrier.insert(piece as u32);
            }
            // The completion path's own barrier is what must make it durable.
            // Mirror the task's real barrier into the model.
            let before = task.storage.stats().sync_ops;
            task.on_download_complete().await;
            if task.storage.stats().sync_ops > before {
                model.barrier();
            }
            let entry = registry_entry(&fx).await;
            assert_eq!(
                entry.state,
                TorrentState::Seeding,
                "gate={gate} fast={fast_mode}"
            );
            assert_eq!(
                model.durable == model.live,
                expect_durable,
                "gate={gate} fast={fast_mode}: data durable when completion was reported"
            );
        }
    }
}
